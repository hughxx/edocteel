package kemu;

import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * @author : hu
 **/
public class CycleBarrierTest {
    private final static CyclicBarrier CYCLIC_BARRIER = new CyclicBarrier(2);

    public static void main(String[] args) throws InterruptedException{
        ExecutorService executorService = Executors.newFixedThreadPool(2);
        executorService.submit(()-> {
            try {
                System.out.println("Thread 1 : step 1");
                CYCLIC_BARRIER.await();
                System.out.println("Thread 1 : step 2");
                CYCLIC_BARRIER.await();
                System.out.println("Thread 1 : step 3");
            } catch (Exception e) {

            }
        });

        executorService.submit(()-> {
            try {
                System.out.println("Thread 2 : step 1");
                CYCLIC_BARRIER.await();
                System.out.println("Thread 2 : step 2");
                CYCLIC_BARRIER.await();
                System.out.println("Thread 2 : step 3");
            } catch (Exception e) {

            }
        });

        executorService.shutdown();
        executorService.awaitTermination(30, TimeUnit.SECONDS);
    }
}
