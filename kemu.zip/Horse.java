package kemu;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;

/**
 * @author : hu
 **/
public class Horse {
    public static void race(String name, int rate1, int rate2) {
        System.out.println(String.format("Horse name=%s  rate1=%d, rate2=%d", name, rate1, rate2));
    }

    public static void main(String[] args) {
        MethodHandles.Lookup lookup = MethodHandles.lookup();
        MethodType methodType = MethodType.methodType(void.class, String.class, int.class, int.class);
        MethodHandle baseHandle = null;
        try {
            baseHandle = lookup.findStatic(Horse.class, "race", methodType);
        } catch (NoSuchMethodException | IllegalAccessException ignore) {

        }

        MethodHandle handle = MethodHandles.dropArguments(baseHandle, 2, int.class);
        try {
            handle.invoke("test", 1, 2, 3);
        } catch (Throwable throwable) {
            System.out.println("invoke fail");
        }
    }
}
