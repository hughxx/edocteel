package kemu;

/**
 * @author : hu
 **/
public class Dog extends Animal {
    private static int x2 = Animal.show("static Dog.x2 initialized");
    private int third = Animal.show("Dog.third init");
    public Dog() {
        System.out.println("third" + third);
        System.out.println("second = " + third);
    }

    public static void main(String[] args) {
        System.out.println("dog construcot");
        Dog dog = new Dog();
        System.out.println("Main left");
    }
}
