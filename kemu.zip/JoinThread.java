package kemu;

/**
 * @author : hu
 **/
public class JoinThread extends Thread{
    static volatile int count = 0;
    public void run() {
        for (int i = 0; i < 10; i++) {
            try {
                count = count + 1;
                sleep(3);
            } catch (Exception e) {

            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Thread[] threads = new Thread[100];
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new JoinThread();
        }
        for (int i = 0; i < threads.length; i++) {
            threads[i].start();
        }
        for (int i = 0; i < threads.length; i++) {
            threads[i].join();
        }
        System.out.println("n=" + JoinThread.count);
    }

}
