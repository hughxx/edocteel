package kemu;

/**
 * @author : hu
 **/
public class Bytee {
    public static void main(String[] args) {
        //byte b = 128;
        int a = 0, b = 0;


    }
}
