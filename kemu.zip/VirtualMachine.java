package kemu;

/**
 * @author : hu
 **/
public class VirtualMachine {
    public static void main(String[] args) {
        try {
            System.out.println("Try to do something");
            throw new RuntimeException("RuntimeException");
        } catch (Exception e) {
            System.out.println("catch Exception ->" + e.getMessage());
            System.exit(1);
        } finally {
            System.out.println("Finally");
        }
        System.out.println("-=====-");
    }
}
