package kemu;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hu
 **/
public class Fruit {
}
class Apple extends Fruit {}
class Jonathan extends Apple {}
class Orange extends Fruit {}
class Test {
    public static void main(String[] args) {
        List<? extends  Fruit> flist = new ArrayList<>();

    }

}
