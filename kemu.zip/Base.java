package kemu;

/**
 * @author : hu
 **/
public class Base {
    public int id = 100;
    public void doSomething() {
        System.out.println("Base");
    }
}
