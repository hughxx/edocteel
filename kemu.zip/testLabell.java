package kemu;

/**
 * @author : hu
 **/
public class testLabell {
    public static void main(String[] args) {
        testLable(5);
    }

    public static void testLable(int flag) {
        LOOP1:
        for (int i = 0; i < 2; i++) {
            LOOP2:
            for (int j = 0; j < 2; j++) {
                switch (flag) {
                    case 0:
                        System.out.println("A");
                        break;
                    case 1:
                        System.out.println("B");
                        continue;
                    case 2:
                        System.out.println("C");
                        break LOOP2;
                    case 3:
                        System.out.println("D");
                        continue LOOP2;
                    case 4:
                        System.out.println("E");
                        break LOOP1;
                    case 5:
                        System.out.println("F");
                        continue LOOP1;
                    default:
                        System.out.println("R");
                        break;
                }
                System.out.println(2);
            }
            System.out.println(1);
        }
    }
}
