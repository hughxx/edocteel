package kemu;

/**
 * @author : hu
 **/
public class BaseClass {
    static String name = "Base";
    public String getName() {
        return name;
    }
}

class ChildClassA extends BaseClass {
    public void setName(String inputname) {
        name = inputname;
    }
}

class ChildClassB extends BaseClass {
    public void setName(String inputname) {
        name = inputname;
    }
}

class TestCALSS {
    public static void main(String[] args) {
        ChildClassA child1 = new ChildClassA();
        child1.setName("child A");
        ChildClassB child2 = new ChildClassB();
        child2.setName("child B");
        ChildClassA child3 = new ChildClassA();
        child3.setName("child C");

        System.out.println(child2.getName());
    }
}
