package kemu;

/**
 * @author : hu
 **/
public class Testt {
//    public static void main(String[] args) {
//        int n1 = 11;
//        int n2 = 5;
//        switch (n1 / n2) {
//            case 3:
//                n2 += 6;
//            case 2:
//                n2 += 4;
//            case 4:
//                n2 += 5;
//            case 1:
//                n2 += 1;
//                break;
//        }
//        System.out.println(n2);
//    }

    public static void main(String[] args) {
        int count = 0;
        for (int i = 0; i < 100; i++) {
            count = count++;
        }
        System.out.println(count);
    }
}
