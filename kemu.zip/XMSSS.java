package kemu;

import java.io.IOException;
import java.util.concurrent.Exchanger;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author : hu 输出结果不确定
 **/
public class XMSSS {
    public static void main(String[] args) throws InterruptedException, IOException {
        ExecutorService service = Executors.newCachedThreadPool();
        final Exchanger<String> exchanger = new Exchanger<>();
        service.execute(() -> {
            try {
                String data = exchanger.exchange("XMSSS");
                System.out.println("data1:" + data);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        service.execute(() -> {
            try {
                String data = exchanger.exchange("GRXXX");
                System.out.println("data2:" + data);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        service.shutdown();
    }
}
