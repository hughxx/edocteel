package kemu;

/**
 * @author : hu
 **/
public class Swan {
    static String msg = "swan can fly ...";
    public static void fly() {
        String msg = "swan can not fly";
        System.out.println(msg);
    }

}

class UglyDuck extends Swan {
    static String msg = "ugly duck can fly ...";
    public static void fly() {
        String msg = "ugly duck can't fly ...";
        System.out.println(msg);
    }
}

class TestFly {
    public static void main(String[] args) {
        Swan swan = new Swan();
        Swan uglyDuck = new UglyDuck();
        swan.fly();
        uglyDuck.fly();

    }
}
