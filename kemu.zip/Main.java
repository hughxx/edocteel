package kemu;

public class Main {

    public static class ResourceFile {
        public static void extract() {
            System.out.println("ResourceFile extract");
        }
    }

    public static class PptFile extends ResourceFile {
        public static void extract() {
            System.out.println("PPTFile extract");
        }
    }



    public static void main(String[] args) {

        ResourceFile file = new PptFile();
        file.extract();
        PptFile ppt = (PptFile) file;
        ppt.extract();

        //这道题错了
//        int[][][] a1 = new int[5][6][7];
//        int[][] a2 = new int[20][10];
//        Integer[][][] b1 = new Integer[5][6][7];
//        a1[1][1][1] = b1[1][1][1];
//        a1[5] = a2;


//        String s = "a..b..c";
//        String replace = s.replace("..", "|");
//        String s1 = s.replaceAll("..", "|");
//        System.out.println(replace);
//        System.out.println(s1);

    }

    public String replace(String s) {
        return s.replace("..", "|");
    }

    public String replaceAll(String s) {
        return s.replaceAll("..", "|");
    }


}


