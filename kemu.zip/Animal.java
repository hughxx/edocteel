package kemu;

/**
 * @author : hu
 **/
public class Animal {
    private static int x1 = show("static Animal.x1 in");

    private int first = 9;

    protected int second;

    public Animal() {
        System.out.println("first = " + first + ", second =" + second);
        second = 39;
    }

    static int show(String str) {
        System.out.println(str);
        return 47;
    }
}


