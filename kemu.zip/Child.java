package kemu;

/**
 * @author : hu
 **/
public class Child extends Base{
    public int id = 101;
    @Override
    public void doSomething() {
        System.out.println("CHild");
    }

    public static void main(String[] args) {
        Base base = new Child();
        System.out.println(base.id);
        base.doSomething();
    }
}
