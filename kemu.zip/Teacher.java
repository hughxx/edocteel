package kemu;

/**
 * @author : hu
 **/
public class Teacher {
    private String name;
    public Teacher(String name) {
        this.name = name;
    }

    public static void main(String[] args) {
        Teacher teacher = new Teacher("Miss Gao");
        Student student = new Student(teacher);
//        Student cloneStu = student.clone();
//        System.out.println(cloneStu.getTeacher() == teacher);

    }
}

class Student implements Cloneable {
    public Teacher teacher;
    public Teacher getTeacher() {
        return teacher;
    }

    public Student(Teacher teacher) {
        this.teacher = teacher;
    }

    public Student clone() throws CloneNotSupportedException {
        return (Student)super.clone();
    }
}
