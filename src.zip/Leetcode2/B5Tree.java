package Leetcode2;

import java.util.HashMap;
import java.util.HashSet;

/**
 * @author : hu
 * @since : 2023/7/16
 **/
public class B5Tree {


    //已知父节点速求
    class SolutionAs{
        //give parent, find next node
        class Node {
            public int val;
            public Node left;
            public Node right;
            public Node parent;

            public Node(int x) {
                val = x;
            }
        }

        public Node getSuccessorNode(Node node) {
            if (node == null) return null;

            if (node.right != null) {
                return getLeftMost(node.right);
            } else {
                Node parent = node.parent;
                while (parent != null && parent.left != node) {
                    node = parent;
                    parent = parent.parent;
                }
                return parent;
            }
        }

        public Node getLeftMost(Node node) {
            if (node == null) {
                return node;
            }
            while (node.left != null) {
                node = node.left;
            }
            return node;
        }
    }

    //morris
    void morris(TreeNode root) {
        if (root == null) return;
        TreeNode cur = root;
        TreeNode mostRight = root;
        while (cur != null) {
            mostRight = cur.left;
            if (mostRight != null) {
                while (mostRight.right != null && mostRight.right != cur) {
                    mostRight = mostRight.right;
                }
                if (mostRight.right == null) {
                    mostRight.right = cur;
                    cur = cur.left;
                    continue;
                } else {
                    mostRight.right = null;
                }
            }
            cur = cur.right;
        }
    }

    void morrisPre(TreeNode root) {
        if (root == null) return;
        TreeNode cur = root;
        TreeNode mostRight = root;
        while (cur != null) {
            mostRight = cur.left;
            if (mostRight != null) {
                while (mostRight.right != null && mostRight.right != cur) {
                    mostRight = mostRight.right;
                }
                if (mostRight.right == null) {
                    System.out.println(cur.val);
                    mostRight.right = cur;
                    cur = cur.left;
                    continue;
                } else {
                    mostRight.right = null;
                }
            } else {
                System.out.println(cur.val);
            }
            cur = cur.right;
        }
    }

    void morrisIn(TreeNode root) {
        if (root == null) return;
        TreeNode cur = root;
        TreeNode mostRight = root;
        while (cur != null) {
            mostRight = cur.left;
            if (mostRight != null) {
                while (mostRight.right != null && mostRight.right != cur) {
                    mostRight = mostRight.right;
                }
                if (mostRight.right == null) {
                    mostRight.right = cur;
                    cur = cur.left;
                    continue;
                } else {
                    mostRight.right = null;
                }
            }
            System.out.println(cur.val);
            cur = cur.right;
        }
    }

    void morrisPost(TreeNode root) {
        if (root == null) return;
        TreeNode cur = root;
        TreeNode mostRight = root;
        while (cur != null) {
            mostRight = cur.left;
            if (mostRight != null) {
                while (mostRight.right != null && mostRight.right != cur) {
                    mostRight = mostRight.right;
                }
                if (mostRight.right == null) {
                    mostRight.right = cur;
                    cur = cur.left;
                    continue;
                } else {
                    mostRight.right = null;
                    printEdge(cur.left);
                }
            }
            cur = cur.right;
        }
        printEdge(root);
    }

    void printEdge(TreeNode x) {
        TreeNode tail = reverseEdge(x);
        TreeNode cur = tail;
        while (cur != null) {
            System.out.println(cur.val);
            cur = cur.right;
        }
    }

    TreeNode reverseEdge(TreeNode from) {
        TreeNode pre = null;
        TreeNode next = null;
        while (from != null) {
            next = from.right;
            from.right = pre;
            pre = from;
            from = next;
        }
        return pre;
    }

    //树形dp：需要左右信息，然后在自己整合
    //morris：单纯遍历， 不需要三次回到自己



}
