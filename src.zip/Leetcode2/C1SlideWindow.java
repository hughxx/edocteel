package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/20
 **/
public class C1SlideWindow {
    //给定一些点， 还有一根L的绳子， 最多覆盖几个点


}
