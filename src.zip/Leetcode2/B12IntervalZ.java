package Leetcode2;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/8/1
 **/
public class B12IntervalZ {
    //56
    public int[][] merge(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> a[0] - b[0]);

        LinkedList<int[]> list = new LinkedList<>();
        int left = intervals[0][0], right = intervals[0][1];
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] > right) {
                list.add(new int[]{left, right});
                left = intervals[i][0];
                right = intervals[i][1];
            } else if (intervals[i][1] > right) {//if代替max
                right = intervals[i][1];
            }
        }
//        for (int[] interval : intervals) {
//            if (interval[0] > right) {
//                list.add(new int[]{left, right});
//                left = interval[0];
//                right = interval[1];
//            } else if (interval[1] > right) {
//                right = interval[1];
//            }
//        }
        list.add(new int[]{left, right});

        int[][] res = new int[list.size()][];
        for (int i = 0; i < list.size(); i++) {
            res[i] = list.get(i);
        }
        return res;
    }

    //--------------------------------

    //435
    public int eraseOverlapIntervals(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> a[0] - b[0]);
        int right = intervals[0][1] ,res = 1;
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] >= right) {
                right = intervals[i][1];
                res++;
            } else if(intervals[i][1] < right){//if代替max
                right = intervals[i][1];
            }
        }
        return intervals.length - res;
    }

    // 1.435/452/会议室独属
    // 按end排和按start排区别在于：当一个区间可以【起点一样覆盖和正常覆盖】一个区间时，这两个区间的顺序【短压长】；
    // 只对435,452,会议室I有效，可以省去贪心判断。但对合并区间和1288来说一点也没用，不仅省不了判断，反而会出错！！
    // 2.1288独属
    // 而comparator部分加东西的意义在于：如何定义两个开始节点一样时排序的规则【起点一样的覆盖：长压短，反而违背了end题目的要求！！】，即1288不能用end
    // 即使不违背，对于【正常覆盖】还得手动作贪心判断。
    // 而对于合并区间来说，省的也只是【起点一样的覆盖】，对于其他【正常覆盖/相交/相离】没用一点用，所以可以把1288看成独立的题
    // 3.总结
    // 一般分两块做就够了，【正常覆盖/覆盖/相交】【相离】，对于前者根据题目要求适应一下就行
    // 而且正常覆盖也就1288要考虑，而且他的角度还不太一样，所以【覆盖/相交】【相离】就够handle很多了
    // end应该没必要吧

//    static bool cmp(vector<int>& a,vector<int>& b){
//        return a[1]<b[1];
//    }
//    int eraseOverlapIntervals(vector<vector<int>>& intervals) {
//        sort(intervals.begin(),intervals.end(),cmp);
//        int lastEnd=0;
//        int result=1;
//        for(int i=1;i<intervals.size();i++){
//            if(intervals[i][0]>=intervals[lastEnd][1]){
//                result++;
//                lastEnd=i;
//            }
//        }
//        return intervals.size()-result;
//    }

    //452
    public int findMinArrowShots(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> {
            if (a[0] > b[0]) return 1;
            else return -1;
        });
        int right = intervals[0][1] ,res = 1;
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] > right) {
                right = intervals[i][1];
                res++;
            } else if(intervals[i][1] < right){//if代替max
                right = intervals[i][1];
            }
        }
        return res;
    }

    //--------------------------------

    //1288
    public int removeCoveredIntervals(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> a[0] == b[0] ? b[1] - a[1] : a[0] - b[0]);
//        int right = -1, res = 0;
//        for (int i = intervals)
//        for (int[] interval : intervals) {
//            if(interval[1] <= right) continue;
//            right = interval[1];
//            res++;
//        }
        //统一化先锁住第一个
        int right = intervals[0][1], res = 1;
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][1] <= right) {
                continue;
            } else {
                right = intervals[i][1];
                res++;
            }
        }
        return res;
    }

    //-----------------------------------------------------------------------------

    //986
    public int[][] intervalIntersection(int[][] firstList, int[][] secondList) {
        LinkedList<int[]> list = new LinkedList<>();
        int i = 0, j = 0;
        while (i < firstList.length && j < secondList.length) {
            int[] a = firstList[i], b = secondList[j];
            if (a[0] <= b[1] && b[0] <= a[1]) {
                list.add(new int[]{Math.max(a[0], b[0]), Math.min(a[1], b[1])});
            }
            if (a[1] > b[1]) j++;
            else i++;
        }

        int[][] res= new int[list.size()][];
        for (int k = 0; k < list.size(); k++) {
            res[k] = list.get(k);
        }
        return res;
    }

    //1024
    public int videoStitching(int[][] clips, int time) {
        Arrays.sort(clips, (a, b) -> a[0] == b[0] ? b[1] - a[1] : a[0]- b[0]);

        int i = 0, right = 0, max = 0, res = 0;
        while (i < clips.length && clips[i][0] <= right) {
            while (i < clips.length && clips[i][0] <= right) {
                max = Math.max(max, clips[i][1]);
                i++;
            }
            res++;
            right = max;
            if (right >= time) return res;
        }
        return -1;
    }

    //--------------------------------------------------------------
    class Interval {
        int start, end;

        Interval(int start, int end) {
            this.start = start;
            this.end = end;
        }
    }

    //会议室1
//    public boolean canAttendMeetings(List<Interval> intervals) {
//        if (intervals.size() == 0) return false;
//        // Write your code here
//        Collections.sort(intervals, (a, b) -> {
//            return a.end - b.end;
//        });
//        int lastEnd = 0, result = 1;
//        for (int i = 1; i < intervals.size(); i++) {
//            if (intervals.get(i).start >= intervals.get(lastEnd).end) {
//                result++;
//                lastEnd = i;
//            }
//        }
//        return result == intervals.size();
//    }
}
