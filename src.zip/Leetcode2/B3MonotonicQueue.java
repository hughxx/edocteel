package Leetcode2;

import java.util.LinkedList;

/**
 * @author : hu
 * @since : 2023/7/15
 **/
public class B3MonotonicQueue {
    //239
    public int[] maxSlidingWindow(int[] nums, int k) {
        int n = nums.length;

        int[] res = new int[n - k + 1];
        MonotonicQueue monotonicQueue = new MonotonicQueue();
        for (int i = 0; i < n; i++) {
            if (i < k - 1) {
                monotonicQueue.push(nums[i]);
            } else {
                monotonicQueue.push(nums[i]);
                res[i - k + 1] = monotonicQueue.max();
                monotonicQueue.pop(nums[i - k + 1]);
            }
        }
        return res;
    }

    private class MonotonicQueue {
        LinkedList<Integer> list = new LinkedList<>();

        void push(int n) {
            while (!list.isEmpty() && n > list.getLast()) {
                list.removeLast();
            }
            list.addLast(n);
        }

        void pop(int n) {
            if (n == list.getFirst()) {
                list.removeFirst();
            }
        }

        int max() {
            return list.peekFirst();
        }
    }
}
