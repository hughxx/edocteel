package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/20
 **/
public class C6Yewu {
    //magic操作，使得平均值都变大

    //栈排序

    //洗衣机

    //p25任意三根木棍不能组成三角形

    //有效数字字符串
}
