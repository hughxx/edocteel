package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/20
 **/
public class C3Precess {

    //本质空间换时间？

    //RGGRGG

    //boder all 1 第5个维度预处理一遍 降到四维

    //Leetcode85 预处理了两遍， 有一遍是【最后一个维度当做算法看的】里用到的预处理

    //面试17.24 最后一个维度是当做一维算法看的

    //压缩数组 上面某一道 子数组->子矩阵
}
