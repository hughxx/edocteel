package Leetcode2;

import java.util.Stack;

/**
 * @author : hu
 * @since : 2023/7/15
 **/
public class A5Tree {
    public void preOrderUnRecur(TreeNode root) {
        Stack<TreeNode> stack = new Stack<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            TreeNode cur = stack.pop();
            System.out.println(cur.val + " ");
            if (cur.right != null) stack.push(cur.right);
            if (cur.left != null) stack.push(cur.left);

        }
        System.out.println();
    }

    public void postOrderUnRecur(TreeNode root) {
        Stack<TreeNode> stack1 = new Stack<>();
        Stack<TreeNode> stack2 = new Stack<>();
        stack1.push(root);
        while (!stack1.isEmpty()) {
            TreeNode cur = stack1.pop();
            stack2.push(cur);
            if (cur.left != null) stack1.push(cur.left);
            if (cur.right != null) stack1.push(cur.right);
        }
        while (!stack2.isEmpty()) {
            TreeNode cur = stack2.pop();
            System.out.println(cur.val + " ");
        }
        System.out.println();
    }

    public void postOrderUnRecur2(TreeNode root) {
        Stack<TreeNode> stack = new Stack<>();
        TreeNode p = root, r = null;
        //框架
        while (!stack.isEmpty() || p != null) {
            if (p != null) {
                stack.push(p);
                p = p.left;
            } else {
                p = stack.peek();
                if (p.right != null && p.right != r) {
                    p = p.right;
                } else {
                    p = stack.pop();
                    System.out.println(p.val + " ");
                    r = p;
                    p = null;
                }
            }
        }
    }

    public void inOrerUnRecur(TreeNode root) {
        Stack<TreeNode> stack = new Stack<>();
        TreeNode p = root;
        while (!stack.isEmpty() || p != null) {
            if (p != null) {
                stack.push(p);
                p = p.left;
            } else {
               p = stack.pop();
               System.out.println(p.val + " ");
               p = p.right;
            }
        }
    }
}
