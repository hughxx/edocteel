package Leetcode2;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @author : hu
 * @since : 2023/7/15
 **/
public class A2Bit {
    //136 只出现一次的数I
    public int singleNumber(int[] nums) {
        int res = 0;
        for (int i = 0; i < nums.length; i++) {
            res ^= nums[i];
        }
        return res;
    }

    //136 只出现一次的数I
    public int singleNumber1(int[] nums) {
        int ans = 0;
        for (int i = 0; i < 32; ++i) {
            int total = 0;
            for (int num: nums) {
                total += ((num >> i) & 1);
            }
            if (total % 2 != 0) {
                ans |= (1 << i);
            }
        }
        return ans;
    }

    //137 只出现一次的数II
    public int singleNumber2(int[] nums) {
        int ans = 0;
        for (int i = 0; i < 32; ++i) {
            int total = 0;
            for (int num: nums) {
                total += ((num >> i) & 1);
            }
            if (total % 3 != 0) {
                ans |= (1 << i);
            }
        }
        return ans;
    }

    //260 只出现一次的数III
    public int[] singleNumber3(int[] nums) {
        int xorsum = 0;
        for (int num : nums) {
            xorsum ^= num;
        }
        // 防止溢出
        // 左神是：int lsb = xorsum & (~xorsum + 1); 等价于这个，这个版本java不用考虑溢出应该
        int lsb = (xorsum == Integer.MIN_VALUE ? xorsum : xorsum & (-xorsum));
        //左神是：先求一个再用lsb异或，不如这个版本
        int type1 = 0, type2 = 0;
        for (int num : nums) {
            if ((num & lsb) != 0) {
                type1 ^= num;
            } else {
                type2 ^= num;
            }
        }
        return new int[]{type1, type2};
    }

    //N皇后


}
