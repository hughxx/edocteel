package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/20
 **/
public class C8Matrix {
    //返回最多1的行号

    // 498zigzag
    void printMatrixZigZag(int[][] matrix) {
        int ar = 0;//右上角
        int ac = 0;
        int br = 0;//左下角
        int bc = 0;
        int endR = matrix.length - 1;
        int endC = matrix[0].length - 1;
        boolean fromUp = false;
        while (ar != endR + 1) {
            //printLevel();
            ar = ac == endC ? ar + 1 : ar;
            ac = ac == endC ? ac : ac + 1;
            bc = br == endR ? bc + 1 : bc;
            br = br == endR ? br : br + 1;
            fromUp = !fromUp;
        }
    }

}
