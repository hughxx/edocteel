package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/22
 **/
public class Z {
}
