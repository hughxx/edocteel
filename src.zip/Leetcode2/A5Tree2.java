package Leetcode2;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;

/**
 * @author : hu
 * @since : 2023/7/15
 **/
public class A5Tree2 {

    //二叉树直径
    class Solution543 {

        int res = 0;

        int depth(TreeNode root) {
            if (root == null) return 0;

            int left = depth(root.left);
            int right = depth(root.right);
            res = Math.max(left + right, res);
            return Math.max(left, right) + 1;
        }
    }

    //是否二叉搜索树 或者中序
    class Solution98 {
        boolean isValidBST(TreeNode root) {
            return isValidBST(root, null, null);
        }

        /* 限定以 root 为根的子树节点必须满足 max.val > root.val > min.val */
        boolean isValidBST(TreeNode root, TreeNode min, TreeNode max) {
            // base case
            if (root == null) return true;
            // 若 root.val 不符合 max 和 min 的限制，说明不是合法 BST
            if (min != null && root.val <= min.val) return false;
            if (max != null && root.val >= max.val) return false;
            // 限定左子树的最大值是 root.val，右子树的最小值是 root.val
            return isValidBST(root.left, min, root)
                    && isValidBST(root.right, root, max);
        }
    }

    class ReturnData {
        boolean isBST;
        int min;
        int max;
        ReturnData(boolean isBST, int min, int max) {
            this.isBST = isBST;
            this.min = min;
            this.max = max;
        }
    }

    ReturnData process(TreeNode x) {
        if (x == null) return null;
        ReturnData leftData = process(x.left);
        ReturnData rightData = process(x.right);
        int min = x.val;
        int max = x.val;
        if (leftData != null) {
            min = Math.min(min, leftData.min);
            max = Math.max(max, leftData.max);
        }
        if (rightData != null) {
            min = Math.min(min, rightData.min);
            max = Math.max(max, rightData.max);
        }
        boolean isBST = true;
        if (leftData != null && (!leftData.isBST || leftData.max >= x.val)) {
            isBST = false;
        }
        if (rightData != null && (!rightData.isBST || rightData.min <= x.val)) {
            isBST = false;
        }
        return new ReturnData(isBST, min, max);
    }

    boolean isBst(TreeNode root) {
        if (root == null) return true;
        TreeNode cur = root;
        TreeNode mostRight = root;
        int preValue = Integer.MIN_VALUE;
        while (cur != null) {
            mostRight = cur.left;
            if (mostRight != null) {
                while (mostRight.right != null && mostRight.right != cur) {
                    mostRight = mostRight.right;
                }
                if (mostRight.right == null) {
                    mostRight.right = cur;
                    cur = cur.left;
                    continue;
                } else {
                    mostRight.right = null;
                }
            }
            if (cur.val <= preValue) return false;
            preValue = cur.val;
            cur = cur.right;
        }
        return true;
    }

    //是否完全二叉树
    class Solutionsdag {
        //Full Binary Tree -> Complete Binary Tree -> Perfect Binary Tree
        public boolean isCBT(TreeNode root) {
            if (root == null) return true;

            Queue<TreeNode> queue = new LinkedList<>();
            boolean leaf = false;

            queue.offer(root);
            while (!queue.isEmpty()) {
                TreeNode cur = queue.poll();
                TreeNode l = cur.left;
                TreeNode r = cur.right;

                //框架
                if ((leaf && (l != null || r != null)) || (l == null && r != null)) return false;

                if (l != null) queue.offer(l);
                if (r != null) queue.offer(r);
                if (l == null || r == null) leaf = true;
            }

            return true;
        }
    }




    //公共祖先
    //暴力
    class Solution {
        public TreeNode lca(TreeNode root, TreeNode p, TreeNode q) {
            HashMap<TreeNode, TreeNode> fatherMap = new HashMap<>();
            fatherMap.put(root, root);
            process(root, fatherMap);

            HashSet<TreeNode> set1 = new HashSet<>();
            TreeNode cur = p;
            while (cur != fatherMap.get(cur)) {
                set1.add(cur);
                cur = fatherMap.get(cur);
            }
            set1.add(root);

            //while o2 省略


            return null;
        }

        public void process(TreeNode root, HashMap<TreeNode, TreeNode> fatherMap) {
            if (root == null) return;
            if (root.left != null) {
                fatherMap.put(root.left, root);
                process(root.left, fatherMap);
            }
            if (root.right != null) {
                fatherMap.put(root.right, root);
                process(root.right, fatherMap);
            }
        }
    }

    //236.一定存在
    class Solution235 {
        TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
            if (root == null) return null;

            if (root.val == p.val || root.val == q.val) return root;
            TreeNode left = lowestCommonAncestor(root.left, p, q);
            TreeNode right = lowestCommonAncestor(root.right, p, q);
            if (left != null & right != null) return root;
            return left != null ? left : right;
        }

        //利用的抽象的方法 or 抽象出的方法
        TreeNode find(TreeNode root, int val) {
            if (root == null) return null;

            if (root.val == val) return root;
            TreeNode left = find(root.left, val) ;
            TreeNode right = find(root.right, val);
            return left != null ? left : right;
        }
    }
    //1676.一定存在
    class Solution1676 {
        TreeNode lowestCommonAncestor(TreeNode root, TreeNode[] nodes) {
            // 将列表转化成哈希集合，便于判断元素是否存在
            HashSet<Integer> values = new HashSet<>();
            for (TreeNode node : nodes) {
                values.add(node.val);
            }

            return find(root, values);
        }

        // 在二叉树中寻找 values 的最近公共祖先节点
        TreeNode find(TreeNode root, HashSet<Integer> values) {
            if (root == null) {
                return null;
            }
            // 前序位置
            if (values.contains(root.val)){
                return root;
            }

            TreeNode left = find(root.left, values);
            TreeNode right = find(root.right, values);
            // 后序位置，已经知道左右子树是否存在目标值
            if (left != null && right != null) {
                // 当前节点是 LCA 节点
                return root;
            }

            return left != null ? left : right;
        }
    }


    boolean findP = false, findQ = false;
    TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        if (root == null) return null;


        TreeNode left = lowestCommonAncestor(root.left, p, q);
        TreeNode right = lowestCommonAncestor(root.right, p, q);
        // 后序位置，已经知道左右子树是否存在目标值
        if (left != null && right != null) {
            // 当前节点是 LCA 节点
            return root;
        }
        if (root.val == p.val || root.val == q.val) {
            if (root.val == p.val) findP = true;
            if (root.val == q.val) findQ = true;
            return root;
        }


        return left != null ? left : right;
    }
}
