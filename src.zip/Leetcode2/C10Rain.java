package Leetcode2;

import java.util.HashMap;

/**
 * @author : hu
 * @since : 2023/7/21
 **/
public class C10Rain {

    //容器

    //max 类似斗地主？

}
