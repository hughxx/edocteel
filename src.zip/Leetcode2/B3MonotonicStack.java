package Leetcode2;

import java.util.*;

/**
 * @author : hu
 * @since : 2023/7/14
 **/
public class B3MonotonicStack {
    //入栈时知道左边第一个，出栈时知道右边第一个
    //

    //739
    public int[] dailyTemperatures(int[] arr) {
        int n = arr.length;
        Stack<Integer> stack = new Stack<>();
        int[] res = new int[n];
        for (int i = n - 1; i >= 0; i --) {
            while (!stack.isEmpty() && arr[stack.peek()] <= arr[i]) {
                stack.pop();
            }
            res[i] = stack.isEmpty() ? 0 : stack.peek() - i;
            stack.push(i);
        }
        return res;
    }

    //42
    public int trap(int[] height) {
        int ans = 0;
        Deque<Integer> stack = new LinkedList<Integer>();
        int n = height.length;
        for (int i = 0; i < n; ++i) {
            while (!stack.isEmpty() && height[i] > height[stack.peek()]) {
                int top = stack.pop();
                if (stack.isEmpty()) {
                    break;
                }
                int left = stack.peek();
                int currWidth = i - left - 1;
                int currHeight = Math.min(height[left], height[i]) - height[top];
                ans += currWidth * currHeight;
            }
            stack.push(i);
        }
        return ans;
    }


    //496 II
    public int[] nextGreaterElement(int[] nums1, int[] nums2) {
        LinkedList<Integer> list = new LinkedList<>();
        int[] record = new int[nums2.length];
        for (int i = nums2.length - 1; i >= 0; i--) {
            while (!list.isEmpty() && list.getLast() <= nums2[i]) {
                list.removeLast();
            }
            record[i] = list.isEmpty() ? -1 : list.getLast();
            list.add(nums2[i]);
        }

        HashMap<Integer, Integer> valToIndex = new HashMap<>();
        int[] res = new int[nums1.length];
        for (int i = 0; i < nums2.length; i++) {
            valToIndex.put(nums2[i], i);
        }
        for (int i = 0; i < nums1.length; i++) {
            res[i] = record[valToIndex.get(nums1[i])];
        }
        return res;
    }

    //503 I
    public int[] nextGreaterElements(int[] nums) {
        int n = nums.length;

        LinkedList<Integer> list = new LinkedList<>();
        int[] res = new int[n];
        for (int i = 2 * n - 1; i >= 0; i--) {
            while (!list.isEmpty() && list.getLast() <= nums[i % n]) {
                list.removeLast();
            }
            if (i < n) {
                res[i] = list.isEmpty() ? -1 : list.getLast();
            }
            list.add(nums[i % n]);
        }
        return res;
    }

    //2454 IV 正向，上面都是逆向
    public int[] secondGreaterElement(int[] nums) {
        Stack<Integer> stack1 = new Stack<>();
        Stack<Integer> stack2 = new Stack<>();
        int[] res = new int[nums.length];
        Arrays.fill(res, -1);
        for (int i = 0; i < nums.length; i++) {
            while (!stack2.isEmpty() && nums[stack2.peek()] < nums[i]) {
                res[stack2.pop()] = nums[i];
            }
            LinkedList<Integer> list = new LinkedList<>();
            while (!stack1.isEmpty() && nums[stack1.peek()] < nums[i]) {
                list.add(stack1.pop());
            }
            while (!list.isEmpty()) {
                stack2.add(list.removeLast());
            }
            stack1.add(i);
        }
        return res;
    }
}
