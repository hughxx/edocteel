package Leetcode2;

import java.util.*;

/**
 * @author : hu
 * @since : 2023/7/15
 **/
public class A6Graph2 {

    class S1 {
        class Node {
            Edge[] edges;
        }

        class Edge {
            Node to;
            int weight;
        }

        public HashMap<Node, Integer> dijkstra(Node head) {
            HashMap<Node, Integer> distanceMap = new HashMap<>();
            distanceMap.put(head, 0);

            HashSet<Node> selectedNodes = new HashSet<>();
            Node minNode = getMinDistanceAndUnselectedNode(distanceMap, selectedNodes);
            while (minNode != null) {
                int distance = distanceMap.get(minNode);
                //O(E)*O(1) for this code -> todo
                for (Edge edge : minNode.edges) {
                    Node toNode = edge.to;
                    if (!distanceMap.containsKey(toNode)) {
                        distanceMap.put(toNode, distance + edge.weight);
                    }
                    distanceMap.put(toNode, Math.min(distanceMap.get(toNode), distance + edge.weight));
                }
                //O(v)*O(1) for this code -> todo
                selectedNodes.add(minNode);
                //O(v)*O(v) for this code -> todo
                minNode = getMinDistanceAndUnselectedNode(distanceMap, selectedNodes);
            }
            return distanceMap;
            //O(V2 + E) for this code, which E is at most V2 -> O(Vlogv + E) -> O(Vlogv + Elogv)
        }

        private Node getMinDistanceAndUnselectedNode(HashMap<Node, Integer> distanceMap, HashSet<Node> selectedNodes) {
            Node minNode = null;
            int minDistance = Integer.MAX_VALUE;
            for (Map.Entry<Node, Integer> entry : distanceMap.entrySet()) {
                Node node = entry.getKey();
                int distance = entry.getValue();
                if (!selectedNodes.contains(node) && distance < minDistance) {
                    minNode = node;
                    minDistance = distance;
                }
            }
            return minNode;
        }

        class NodeHeap {
            int size;
            Node[] nodes;
            HashMap<Node, Integer> iMap;
            HashMap<Node, Integer> dMap;

            NodeHeap(int size) {
                nodes = new Node[size];
                iMap = new HashMap<>();
                dMap = new HashMap<>();
                this.size = 0;
            }

            boolean isEmpty() { return size == 0;}

            void addOrUpdateOrIgnore(Node node, int val) {
                if (inHeap(node)) {
                    dMap.put(node, Math.min(dMap.get(node), val));
                    swim(node, iMap.get(node));
                }
                if (!isEntered(node)) {
                    nodes[size] = node;
                    iMap.put(node, size);
                    dMap.put(node, val);
                    swim(node, size++);
                }
            }

            NodeRecord pop() {
                NodeRecord nodeRecord = new NodeRecord(nodes[0], dMap.get(nodes[0]));
                swap(0, size - 1);
                iMap.put(nodes[size - 1], -1);
                dMap.remove(nodes[size - 1]);
                nodes[size - 1] = null;
                sink(0, --size);
                return nodeRecord;
            }

            private void sink(int k, int limit) {
                while (2 * k + 1 < limit) {
                    int i = 2 * k + 1;
                    if (i + 1 < limit && dMap.get(nodes[i]) < dMap.get(nodes[i + 1 ])) {
                        i++;
                    }
                    if (dMap.get(nodes[k]) > dMap.get(nodes[i])) break;
                    swap(k, i);
                    k = i;
                }
            }

            private void swim(Node node, int index) {
                while (dMap.get(nodes[index]) < dMap.get(nodes[(index - 1) / 2])) {
                    swap(index, (index - 1) / 2);
                    index = (index - 1) / 2;
                }
            }

            private boolean isEntered(Node node) {
                return iMap.containsKey(node);
            }

            private boolean inHeap(Node node) {
                return isEntered(node) && iMap.get(node) != 1;
            }

            private void swap(int i, int j) {
                iMap.put(nodes[i], j);
                iMap.put(nodes[j], i);
                Node tmp = nodes[i];
                nodes[i] = nodes[j];
                nodes[j] = tmp;
            }
        }

        class NodeRecord {
            Node node;
            int distance;

            public NodeRecord(Node node, int distance) {
                this.node = node;
                this.distance = distance;
            }
        }

        public HashMap<Node, Integer> dijkstra2(Node head, int size) {
            NodeHeap nodeHeap = new NodeHeap(size);
            nodeHeap.addOrUpdateOrIgnore(head, 0);
            HashMap<Node, Integer> result = new HashMap<>();
            while (!nodeHeap.isEmpty()) {
                NodeRecord record = nodeHeap.pop();
                Node cur = record.node;
                int distance = record.distance;
                for (Edge edge : cur.edges) {
                    nodeHeap.addOrUpdateOrIgnore(edge.to, edge.weight + distance);
                }
                result.put(cur, distance);
            }
            return result;
        }
    }

    class S2 {
        class State {
            // 图节点的 id
            int id;
            // 从 start 节点到当前节点的距离
            int distFromStart;

            State(int id, int distFromStart) {
                this.id = id;
                this.distFromStart = distFromStart;
            }
        }

        // 返回节点 from 到节点 to 之间的边的权重
        int weight(int from, int to) {
            return -1;
        }

        // 输入节点 s 返回 s 的相邻节点
        List<Integer> adj(int s) {
            return null;
        }

        // 扩散 队列有重复所以Elogv -> ElogE 点的角度邻边 + visited
        int[] dijkstra(int start, List<Integer>[] graph) {
            // 图中节点的个数
            int V = graph.length;
            // 记录最短路径的权重，你可以理解为 dp table
            // 定义：distTo[i] 的值就是节点 start 到达节点 i 的最短路径权重
            int[] distTo = new int[V];
            // 求最小值，所以 dp table 初始化为正无穷
            Arrays.fill(distTo, Integer.MAX_VALUE);
            // base case，start 到 start 的最短距离就是 0
            distTo[start] = 0;

            // 优先级队列，distFromStart 较小的排在前面
            Queue<State> pq = new PriorityQueue<>((a, b) -> {
                return a.distFromStart - b.distFromStart;
            });

            // 从起点 start 开始进行 BFS
            pq.offer(new State(start, 0));

            while (!pq.isEmpty()) {
                State curState = pq.poll();
                int curNodeID = curState.id;
                int curDistFromStart = curState.distFromStart;

                if (curDistFromStart > distTo[curNodeID]) {
                    // 已经有一条更短的路径到达 curNode 节点了
                    continue;
                }
                // 将 curNode 的相邻节点装入队列
                for (int nextNodeID : adj(curNodeID)) {
                    // 看看从 curNode 达到 nextNode 的距离是否会更短
                    int distToNextNode = distTo[curNodeID] + weight(curNodeID, nextNodeID);
                    if (distTo[nextNodeID] > distToNextNode) {
                        // 更新 dp table
                        distTo[nextNodeID] = distToNextNode;
                        // 将这个节点以及距离放入队列
                        pq.offer(new State(nextNodeID, distToNextNode));
                    }
                }
            }
            return distTo;
        }
    }


}
