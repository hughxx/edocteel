package Leetcode2;

import java.util.Stack;

/**
 * @author : hu
 * @since : 2023/7/16
 **/
public class A9Recursive {
    class Solutionasdf {
        //左右拾子
        int win1(int[] arr) {
            if (arr == null || arr.length == 0) {
                return 0;
            }
            return Math.max(f(arr, 0, arr.length - 1), s(arr, 0, arr.length - 1));
        }

        //先手
        int f(int[] arr, int i, int j) {
            if (i == j) return arr[i];
            return Math.max(arr[i] + s(arr, i + 1, j), arr[j] + s(arr, i, j - 1));
        }
        //后手
        int s(int[] arr, int i, int j) {
            if (i == j) return 0;
            return Math.min(f(arr, i + 1, j), f(arr, i, j - 1));
        }
    }


    class Solution486_877{
        class Solution {
            public boolean PredictTheWinner(int[] nums) {
                int length = nums.length;
                int[][] dp = new int[length][length];
                for (int i = 0; i < length; i++) {
                    dp[i][i] = nums[i];
                }
                for (int i = length - 2; i >= 0; i--) {
                    for (int j = i + 1; j < length; j++) {
                        dp[i][j] = Math.max(nums[i] - dp[i + 1][j], nums[j] - dp[i][j - 1]);
                    }
                }
                return dp[0][length - 1] >= 0;
            }
        }
    }

    //不同于上面dp，下面的递归会改动不只是求值
    //逆序栈
    void reverse(Stack<Integer> stack) {
        if (stack.isEmpty()) return;
        int i = f(stack);
        reverse(stack);
        stack.push(i);
    }

    int f(Stack<Integer> stack) {
        int i = stack.pop();
        if (stack.isEmpty()) return i;
        int last = f(stack);
        stack.push(i);
        return last;
    }
}
