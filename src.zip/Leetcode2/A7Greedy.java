package Leetcode2;

import java.util.PriorityQueue;

/**
 * @author : hu
 * @since : 2023/7/16
 **/
public class A7Greedy {
    //会议室

    //127513->753211

    // 一块金条切成两半，是需要花费和长度数值一样的铜板的。比如长度20的金条，不管切成长度多大的两半，都需要花费20个铜板。
    // 给定数组[10,20,30]，代表一共三个人。
    // 整块金条长度为10+20+30=60. 金条要分为10,20,30三个部分。
    // 如果先把长度60的金条分成10+50，花费60；再把长度50的金条分为20和30，花费50；一共花费110铜板。
    // 但是如果先把长度60的金条分成30和30，花费60；再把长度30金条分成10和20，花费30；一共花费90铜板。
    // 输入一个数组，返回分割的最小代价
    public int lessMoney(int[] arr) {
        PriorityQueue<Integer> pq = new PriorityQueue<>();
        for (int i = 0; i < arr.length; i++) {
            pq.add(arr[i]);
        }
        int sum = 0;
        int cur = 0;
        while (pq.size() > 1) {
            cur = pq.poll() + pq.poll();
            sum += cur;
            pq.add(cur);
        }
        return sum;
    }

    //costs[i]表示i号项目的花费，profits[i]表示i号项目在扣除花费之后还能挣到的钱
    //k表示你只能串行的最多做k个项目
    //m表示你的初始资金
    //做完一个项目，可以拿收益去做下一个项目。
    //求获得的最大钱数
    public int findMaximizedCapital(int k, int m, int[]profits, int[]costs) {
        PriorityQueue<int[]> minCostQ = new PriorityQueue<>( (a,b) -> a[1] - b[1]);
        PriorityQueue<int[]> maxProfitQ = new PriorityQueue<>( (a,b) -> b[0] - a[0]);
        for (int i = 0; i < profits.length; i++) {
            minCostQ.add(new int[]{profits[i], costs[i]});
        }
        for (int i = 0; i < k; i++) {
            while (!minCostQ.isEmpty() && minCostQ.peek()[1] <= m) {
                maxProfitQ.add(minCostQ.poll());
            }
            if (maxProfitQ.isEmpty()) {
                return m;
            }
            m += maxProfitQ.poll()[0];
        }
        return m;
    }
}
