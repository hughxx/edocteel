package Leetcode2;



import java.util.*;

/**
 * @author : hu
 * @since : 2023/7/16
 **/
public class A8Backtrack {
    class Solution {
        List<List<String>> res = new ArrayList<>();

        public List<List<String>> solveNQueens(int n) {
            char[][] board = new char[n][n];
            for (int i = 0; i < n; i++) {
                Arrays.fill(board[i], '.');
            }
            backtrack(board, 0);
            return res;
        }

        void backtrack(char[][] board, int row) {
            int n = board.length;

            if (row == board.length) {
                List<String> track = new ArrayList<>();
                for (int i = 0; i < n; i++) {
                    track.add(new String(board[i]));
                }
                res.add(track);
                return;
            }

            for (int i = 0; i < n; i++) {
                if (isValid(board, row, i)) {
                    if (!isValid(board, row, i)) continue;
                    board[row][i] = 'Q';
                    backtrack(board, row + 1);
                    board[row][i] = '.';
                }
            }
        }

        boolean isValid(char[][] board, int row, int col) {
            int n = board.length;
            for (int i = 0; i < row; i++) {
                if (board[i][col] == 'Q') return false;
                if (col - i - 1>= 0 && board[row - i - 1][col - i - 1] == 'Q') return false;
                if (col + i + 1< n && board[row - i - 1][col + i + 1] == 'Q') return false;
            }
            return true;
        }

        boolean isValid(char[] record, int row, int col) {
            for (int i = 0; i < row; i++) {
                if (record[i] == col || Math.abs(row - i) == Math.abs(col - record[i])) return false;
            }
            return true;
        }
    }

    class Solution2 {
        public int num2(int n) {
            if (n < 1 || n > 32) {
                return 0;
            }
            //00001111
            int limit = n == 32 ? - 1 :(1 << n) - 1;
            return process2(limit, 0, 0, 0);
        }

        public int process2(int limit, int colLim, int leftDiaLim, int rightDiaLim) {
            if (colLim == limit) return 1;
            int mostRightOne = 0;
            //00001111 & ~00001010 -> 00000101
            int pos = limit & (~(colLim | leftDiaLim | rightDiaLim));

            int res = 0;
            while (pos != 0) {
                //00000001
                mostRightOne = pos & (~pos + 1);
                pos = pos - mostRightOne;
                res += process2(limit, colLim | mostRightOne,
                        (leftDiaLim | mostRightOne) << 1,
                        (rightDiaLim | mostRightOne) >>> 1);
            }
            return res;
        }
    }

    class Combine {
        LinkedList<List<Integer>> res = new LinkedList<>();
        LinkedList<Integer> track = new LinkedList<>();

        void backtrack(int[] nums, int start) {

            // 前序位置，每个节点的值都是一个子集
            res.add(new LinkedList<>(track));

            // 回溯算法标准框架
            for (int i = start; i < nums.length; i++) {
                // 做选择
                track.addLast(nums[i]);
                // 通过 start 参数控制树枝的遍历，避免产生重复的子集
                backtrack(nums, i + 1);
                // 撤销选择
                track.removeLast();
            }
        }

        void process(char[] str, int i, List<Character> res) {
            if (i == str.length) {
                System.out.println(res);
                return;
            }

            List<Character> resKeep = new LinkedList<>();
            Collections.copy(resKeep, res);//TODO have bug
            resKeep.add(str[i]);
            process(str, i + 1, resKeep);

            List<Character> resNoInclude = new LinkedList<>();
            Collections.copy(resNoInclude, res);//TODO have bug
            process(str, i + 1, resNoInclude);
        }

        void process(char[] str, int i) {
            if (i == str.length) {
                System.out.println();
            }
            process(str, i + 1);
            char tmp = str[i];
            str[i] = 0;
            process(str, i + 1);
            str[i] = tmp;
        }
    }

    class Permute {
        LinkedList<List<Integer>> res = new LinkedList<>();
        LinkedList<Integer> track = new LinkedList<>();

        void backtrack(int[] nums, boolean[] used) {

            // 回溯算法标准框架
            for (int i = 0; i < nums.length; i++) {
                if (used[i]) continue;
                // 做选择
                used[i] = true;
                track.addLast(nums[i]);
                // 通过 start 参数控制树枝的遍历，避免产生重复的子集
                backtrack(nums, used);
                // 撤销选择
                track.removeLast();
                used[i] = false;
            }
        }

        void process(char[] str, int i, ArrayList<String> res) {
            if (i == str.length) {
                res.add(String.valueOf(str));
            }

            //boolean[] visited = new boolean[26];
            for (int j = i; j < str.length; j++) {
//                if (visited[str[j] - 'a']) continue;
//                visited[str[j] - 'a'] = true;
                swap(str, i, j);
                process(str, i + 1, res);
                swap(str, i, j);
            }
        }

        void swap(char[] str, int i, int j) {}
    }

    public static void main(String[] args) {
        System.out.println(14 / 5);
    }

}
