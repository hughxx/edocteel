package Leetcode2;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/7/15
 **/
public class A1SortM {

    class Solution912 {
        int[] temp;

        public int[] sortArray(int[] nums) {
            temp = new int[nums.length];
            sort(nums, 0, nums.length - 1);
            return nums;
        }

        void sort(int[] nums, int lo, int hi) {
            if (lo == hi) return;

            int mid = lo + (hi - lo) / 2;
            sort(nums, lo, mid);
            sort(nums, mid + 1, hi);
            merge(nums, lo, mid, hi);
        }

        void merge(int[] nums, int lo, int mid, int hi) {
            for (int i = lo; i <= hi; i++) {
                temp[i] = nums[i];
            }
            int i = lo, j = mid + 1;
            for (int p = lo; p <= hi; p++) {
                if (i > mid) {
                    nums[p] = temp[j++];
                } else if (j > hi) {
                    nums[p] = temp[i++];
                } else if (temp[i] < temp[j]) {
                    nums[p] = temp[i++];
                } else {
                    nums[p] = temp[j++];
                }
            }
        }
    }

    class Solution315 {
        private class Pair {
            int val, id;
            Pair(int val, int id) {
                // 记录数组的元素值
                this.val = val;
                // 记录元素在数组中的原始索引
                this.id = id;
            }
        }

        // 归并排序所用的辅助数组
        private Pair[] temp;
        // 记录每个元素后面比自己小的元素个数
        private int[] count;

        // 主函数
        public List<Integer> countSmaller(int[] nums) {
            int n = nums.length;
            count = new int[n];
            temp = new Pair[n];
            Pair[] arr = new Pair[n];
            // 记录元素原始的索引位置，以便在 count 数组中更新结果
            for (int i = 0; i < n; i++)
                arr[i] = new Pair(nums[i], i);

            // 执行归并排序，本题结果被记录在 count 数组中
            sort(arr, 0, n - 1);

            List<Integer> res = new LinkedList<>();
            for (int c : count) res.add(c);
            return res;
        }

        // 归并排序
        private void sort(Pair[] arr, int lo, int hi) {
            if (lo == hi) return;
            int mid = lo + (hi - lo) / 2;
            sort(arr, lo, mid);
            sort(arr, mid + 1, hi);
            merge(arr, lo, mid, hi);
        }

        // 合并两个有序数组
        private void merge(Pair[] arr, int lo, int mid, int hi) {
            for (int i = lo; i <= hi; i++) {
                temp[i] = arr[i];
            }

            int i = lo, j = mid + 1;
            for (int p = lo; p <= hi; p++) {
                if (i == mid + 1) {
                    arr[p] = temp[j++];
                } else if (j == hi + 1) {
                    arr[p] = temp[i++];
                    // 更新 count 数组
                    count[arr[p].id] += j - mid - 1;
                } else if (temp[i].val > temp[j].val) {
                    arr[p] = temp[j++];
                } else {
                    arr[p] = temp[i++];
                    // 更新 count 数组
                    count[arr[p].id] += j - mid - 1;
                }
            }
        }
        //  111122335 11122667
        //  ↑            ↑
        //  ·         ···

    }

    //左神小和
    class Solution315p {
        //  111122335 11122667
        //  ↑           ↑     (right first)
        //  ↑            ↑
        //  ·            ·····

        //  else if (temp[i].val >= temp[j].val) { // >=
        //      arr[p] = temp[j++];
        //  } else {
        //      arr[p] = temp[i++];
        //      count += arr[p] * (hi - j + 1);
        //  }
    }
}
