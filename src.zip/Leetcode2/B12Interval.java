package Leetcode2;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/8/1
 **/
public class B12Interval {
    //56
    public int[][] merge(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> a[0] - b[0]);

        LinkedList<int[]> list = new LinkedList<>();
        int left = intervals[0][0], right = intervals[0][1];
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] > right) {
                list.add(new int[]{left, right});
                left = intervals[i][0];
                right = intervals[i][1];
            } else if (intervals[i][1] > right) {
                right = intervals[i][1];
            }
        }

        list.add(new int[]{left, right});

        int[][] res = new int[list.size()][];
        for (int i = 0; i < list.size(); i++) {
            res[i] = list.get(i);
        }
        return res;
    }

    //435
    public int eraseOverlapIntervals(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> a[0] - b[0]);
        int right = intervals[0][1] ,res = 1;
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] >= right) {
                right = intervals[i][1];
                res++;
            } else if(intervals[i][1] < right){
                right = intervals[i][1];
            }
        }
        return intervals.length - res;
    }

    //452
    public int findMinArrowShots(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> {
            if (a[0] > b[0]) return 1;
            else return -1;
        });
        int right = intervals[0][1] ,res = 1;
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] > right) {
                right = intervals[i][1];
                res++;
            } else if(intervals[i][1] < right){
                right = intervals[i][1];
            }
        }
        return res;
    }

    //会议室1
    public boolean canAttendMeetings(List<Interval> intervals) {
        if (intervals.size() == 0) return true;

        Collections.sort(intervals, (a, b) -> a.start - b.start);
        int right = intervals.get(0).end, result = 1;
        for (int i = 1; i < intervals.size(); i++) {
            if (intervals.get(i).start >= right) {
                continue;
            } else {
                return false;
            }
        }
        return true;
    }

    //1288
    public int removeCoveredIntervals(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> a[0] == b[0] ? b[1] - a[1] : a[0] - b[0]);

        int right = intervals[0][1], res = 1;
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][1] <= right) {
                continue;
            } else {
                right = intervals[i][1];
                res++;
            }
        }
        return res;
    }

    //986
    public int[][] intervalIntersection(int[][] firstList, int[][] secondList) {
        LinkedList<int[]> list = new LinkedList<>();
        int i = 0, j = 0;
        while (i < firstList.length && j < secondList.length) {
            int[] a = firstList[i], b = secondList[j];
            if (a[0] <= b[1] && b[0] <= a[1]) {
                list.add(new int[]{Math.max(a[0], b[0]), Math.min(a[1], b[1])});
            }
            if (a[1] > b[1]) j++;
            else i++;
        }

        int[][] res= new int[list.size()][];
        for (int k = 0; k < list.size(); k++) {
            res[k] = list.get(k);
        }
        return res;
    }

    //1024
    public int videoStitching(int[][] clips, int time) {
        Arrays.sort(clips, (a, b) -> a[0] == b[0] ? b[1] - a[1] : a[0]- b[0]);

        int i = 0, cur = 0, max = 0, res = 0;
        while (i < clips.length && clips[i][0] <= cur) {
            while (i < clips.length && clips[i][0] <= cur) {
                max = Math.max(max, clips[i][1]);
                i++;
            }
            res++;
            cur = max;
            if (cur >= time) return res;
        }
        return -1;
    }

    class Interval {
        int start, end;

        Interval(int start, int end) {
            this.start = start;
            this.end = end;
        }
    }

    public class Solution {
        /**
         * @param intervals: an array of meeting time intervals
         * @return: the minimum number of conference rooms required
         */
        public int minMeetingRooms(List<Interval> intervals) {
            if(intervals == null || intervals.size() == 0) return 0;

            int n = intervals.size();
            int[] start = new int[n];
            int[] end = new int[n];
            for (int i = 0; i < n; i++) {
                start[i] = intervals.get(i).start;
                end[i] = intervals.get(i).end;
            }
            Arrays.sort(start);
            Arrays.sort(end);

            int i = 0, j = 0, count = 0, res = 0;
            while (i < n && j < n) {
                if (start[i] < end[j]) {
                    count++;
                    i++;
                } else {
                    count--;
                    j++;
                }
                res = Math.max(res, count);
            }
            return res;
        }

//        优化版本，没必要走完end，可以记这版
//        int room = 0, pre = 0;
//        for(int i = 0; i < n; i++){
//            room++;
//            if(start[i] >= end[pre]){
//                room--;
//                pre++;
//            }
//        }
//        return room;

//        同上，按未优化版本格式写的，方便理解
//        int i = 0, j = 0, res = 0;
//        while (i < n) {
//            if (start[i] < end[j]) {
//                res++;
//                i++;
//            } else {
//                j++;
//                i++;
//            }
//        }
//        return res;
    }



}
