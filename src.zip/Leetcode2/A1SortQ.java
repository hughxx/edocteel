package Leetcode2;

import java.util.Random;

/**
 * @author : hu
 * @since : 2023/7/15
 **/
public class A1SortQ {

    //荷兰国旗划分三块，三指针可以更快一些
    class Solution912 {
        public int[] sortArray(int[] nums) {
            shuffle(nums);
            sort(nums, 0, nums.length - 1);
            return nums;
        }

        private void sort(int[] nums, int lo, int hi) {
            if (lo >= hi) return;

            int p = partition(nums, lo, hi);
            sort(nums, lo, p - 1);
            sort(nums, p + 1, hi);
        }

        private int partition(int[] nums, int lo, int hi) {
            int pivot = nums[lo];
            int left = lo, right = hi;
            while (left <= right) {
                if (nums[left] > pivot) {
                    swap(nums, left, right);
                    right--;
                } else {
                    left++;
                }
            }
            swap(nums, lo, right);
            return right;
        }

        private void shuffle(int[] nums) {
            Random random = new Random();
            int n = nums.length;
            for (int i = 0; i < n; i++) {
                int p = random.nextInt(n - i) + i;
                swap(nums, i, p);
            }
        }

        private void swap(int[] nums, int i, int j) {
            int temp = nums[i];
            nums[i] = nums[j];
            nums[j] = temp;
        }
    }
}
