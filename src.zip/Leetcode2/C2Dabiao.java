package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/20
 **/
public class C2Dabiao {

    //
    int minBagAwesome(int apple) {
        if ((apple & 1) != 0) {
            return -1;
        }

        if (apple < 18) {
            return apple == 0 ? 0 : (apple == 6 || apple == 18) ? 1 : (apple == 12 || apple == 14 || apple == 16) ? 2 : -1;
        }
        return (apple - 18) / 8 + 3;
    }
}
