package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/15
 **/
public class A1SortB {
    private void sort(int[] array) {
        int n = array.length;
        int digit = calDigit(array);

        //框架
        int[] temp = new int[n];
        for (int d = 0; d < digit; d++) {
            int[] count = new int[10];//count is the bucket

            for (int i = 0; i < n; i++) {
                count[calNum(array[i], d)]++;
            }

            for (int r = 1; r < 10; r++) {
                count[r] += count[r - 1];
            }

            //框架
            for (int i = n - 1; i >= 0; i--) {
                int j = calNum(array[i], d);
                temp[count[j] - 1] = array[i];
                count[j]--;
            }

            for (int i = 0; i < n; i++) {
                array[i] = temp[i];
            }
        }
    }

    private int calNum(int x, int i) {
        return ((int) (x / Math.pow(10, i))) % 10;
    }

    private int calDigit(int[] array) {
        int max = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i] > max) max = array[i];
        }

        int res = 1;
        while (max / 10 != 0) {
            res++;
            max = max / 10;
        }
        return res;
    }
}
