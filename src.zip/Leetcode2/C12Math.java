package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/22
 **/
public class C12Math {
    //操作1 操作2
    int[] divSumAndCount(int n) {
        int sum = 0;
        int count = 0;
        for (int i = 2; i <= n; i++) {
            while (n % i == 0) {
                sum += i;
                count++;
                n /= i;
            }
        }
        return new int[] {sum, count};
    }

    int minOps(int n) {
        if (n < 2) {
            return 0;
        }
//        if (isPrime(n)) {
//            return n - 1;
//        }
        int[] divSumAndCount = divSumAndCount(n);
        return divSumAndCount[0] - divSumAndCount[1];
    }

    //给定数组判断能否使得任意相邻两数乘积为4

    //p25 求幂 斐波那契 空间优化 时间优化

    //6
    public String convert(String s, int numRows) {
        int n = s.length(), r = numRows;
        if (r == 1 || r >= n) {
            return s;
        }
        int t = r * 2 - 2;
        StringBuffer ans = new StringBuffer();
        for (int i = 0; i < r; i++) {
            for(int j = 0;i + j < n; j += t) {
                ans.append(s.charAt(i + j));
                if(0 < i && i < r - 1 && j + t - i < n) {
                    ans.append(s.charAt(t - i + j));
                }
            }

        }
        return ans.toString();
    }

    //完美洗牌 空间复杂度o1 3^k - 1
    void shuffle(int[] arr) {
        if (arr != null && arr.length != 0 && (arr.length & 1) == 0) {
            shuffle(arr, 0, arr.length - 1);
        }
    }
    void shuffle(int[] arr, int L, int R) {
        while (R - L + 1 > 0) {
            int len = R - L + 1;
            int base = 3;
            int k = 1;
            while (base <= (len + 1) / 3) {
                base *= 3;
                k++;
            }
            int half = (base - 1) / 2;
            int mid = (L + R) / 2;
            //rotate(arr, L + half, mid, mid + half);
            //cycles(arr, L, base - 1, k);
            L = L + base - 1;
        }
    }
}
