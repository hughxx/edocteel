package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/21
 **/
public class C9DataStruc {
    //前k个

    //在线前k个，随时会调整，动态维护

    //最小栈
}
