package Leetcode2;

/**
 * @author : hu
 * @since : 2023/8/1
 **/
public class B11Jump {

    //55 跳跃游戏
    public boolean canJump(int[] nums) {
        int max = 0;
        for (int i = 0; i < nums.length; i++) {
            if (i > max) return false;
            max = Math.max(max, i + nums[i]);
        }
        return true;
    }

    //45 跳跃游戏II
    public int jump(int[] nums) {
        int max = 0, cur = 0, res = 0;
        for(int i = 0; i < nums.length; i++) {
            if(i > cur) {
                res++;
                cur = max;
            }
            max = Math.max(max, i + nums[i]);
        }
        return res;
    }

    //-----------------------------------------------------//

    //403 青蛙跳1
    public boolean canCross(int[] stones) {
        int n = stones.length;
        boolean[][] dp = new boolean[n][n];
        dp[0][0] = true;
        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                int k = stones[i] - stones[j];
                if(k - 1 <= j) {
                    dp[i][k] = dp[j][k - 1] || dp[j][k] || dp[j][k + 1];
                }
            }
        }
        for (int j = 0; j < n; j++) {
            if (dp[n - 1][j]) return true;
        }
        return false;
    }

    //2498 青蛙跳II
    public int maxJump(int[] stones) {
        int res = stones[1] - stones[0];
        for(int i = 2; i < stones.length; i++) {
            res = Math.max(res, stones[i] - stones[i - 2]);
        }
        return res;
    }
}
