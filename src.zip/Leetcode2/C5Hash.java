package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/20
 **/
public class C5Hash {
    //差值为2的
}
