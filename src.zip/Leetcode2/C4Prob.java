package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/20
 **/
public class C4Prob {
    //重做

    int f() {
        return (int) (Math.random() * 5) + 1;
    }

    int r01() {
        int res = 0;
        do {
            res = f();
        } while (res == 3);
        return res < 3 ? 0 : 1;
    }

    int g() {
        int res = 0;
        do {
            res = (r01() << 2) + (r01() << 1) + r01();
        } while (res == 7);
        return res + 1;
    }

    // more general

    // p 0 1-p 1
}
