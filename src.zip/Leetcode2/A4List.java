package Leetcode2;

import java.util.HashMap;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/7/15
 **/
public class A4List {

    public class Solution234I {
        // 左侧指针
        ListNode left;

        boolean isPalindrome(ListNode head) {
            left = head;
            return traverse(head);
        }

        boolean traverse(ListNode right) {
            if (right == null) return true;
            boolean res = traverse(right.next);
            // 后序遍历代码
            res = res && (right.val == left.val);
            left = left.next;
            return res;
        }
    }

    public class Solution234II {
        boolean isPalindrome(ListNode head) {
            ListNode slow, fast;
            slow = fast = head;
            while (fast != null && fast.next != null) {
                slow = slow.next;
                fast = fast.next.next;
            }

            if (fast != null)
                slow = slow.next;

            ListNode left = head;
            ListNode right = reverse(slow);
            while (right != null) {
                if (left.val != right.val)
                    return false;
                left = left.next;
                right = right.next;
            }

            return true;
        }

        ListNode reverse(ListNode head) {
            ListNode pre = null, cur = head;
            while (cur != null) {
                ListNode next = cur.next;
                cur.next = pre;
                pre = cur;
                cur = next;
            }
            return pre;
        }

    }


    //回文链表 栈->快慢指针折半栈->原地
    public boolean isPalindrome(ListNode head) {
        if (head == null || head.next == null) {
            return true;
        }

        //find mid
        ListNode n1 = head;//slow
        ListNode n2 = head;//fast
        while (n2.next != null && n2.next.next != null) {
            n1 = n1.next;
            n2 = n2.next.next;
        }

        //reverse
        n2 = n1.next;//n1 mid; n2 mid next, i.e. reverse begin
        n1.next = null;
        ListNode n3;//temp
        while (n2 != null) {
            n3 = n2.next;
            n2.next = n1;
            n1 = n2;
            n2 = n3;
        }

        //check
        n3 = n1;//last node
        n2 = head;
        boolean res = true;
        while (n1 != null && n2 != null) {
            if (n1.val != n2.val) {
                res = false;
                break;
            }
            n1 = n1.next;
            n2 = n2.next;
        }

        //reverse
        n2 = null;
        while (n3 != null) {
            n1 = n3.next;
            n3.next = n2;
            n2 = n3;
            n3 = n1;
        }

        //reverse
//        n1 = n3.next;
//        n3.next = null;
//        while (n1 != null) {
//            n2 = n1.next;
//            n1.next = n3;
//            n3 = n1;
//            n1 = n2;
//        }
        return res;

    }

    public ListNode listPartition(ListNode head, int pivot) {
        ListNode sH = null, sT = null;
        ListNode eH = null, eT = null;
        ListNode mH = null, mT = null;
        ListNode next = null;

        while (head != null) {
            next = head.next;
            head.next = null;
            if (head.val < pivot) {
                if (sH == null) {
                    sH = head;
                    sT = head;
                } else {
                    sT.next = head;
                    sT = head;
                }
            } else if (head.val == pivot){
                if (eH == null) {
                    eH = head;
                    eT = head;
                } else {
                    eT.next = head;
                    eT = head;
                }
            } else {
                if (mH == null) {
                    mH = head;
                    mT = head;
                } else {
                    mT.next = head;
                    mT = head;
                }
            }
            head = next;//head 只是引用
        }

        //框架
        if (sT != null) {
            sT.next = eH;
            eT = eT == null ? sT : eT;
        }
        if (eT != null) {
            eT.next = mH;
        }
        return sH != null ? sH : (eH != null ? eH : mH);
    }

    class Node {
        int val;
        Node next;
        Node random;

        public Node(int val) {
            this.val = val;
            this.next = null;
            this.random = null;
        }
    }

    public Node copyRandomList1(Node head) {
        HashMap<Node, Node> map = new HashMap<Node, Node>();
        Node cur = head;
        while (cur != null) {
            map.put(cur, new Node(cur.val));
            cur = cur.next;
        }
        cur = head;
        while (cur != null) {
            map.get(cur).next = map.get(cur.next);
            map.get(cur).random = map.get(cur.random);
            cur = cur.next;
        }
        return map.get(head);
    }

    public Node copyRandomList(Node head) {
        if (head == null) return null;
        Node p = head;
        while (p != null) {
            Node temp = p.next;
            p.next = new Node(p.val);
            p.next.next = temp;
            p = temp;
        }

        Node res = head.next;
        Node q = null;
        p = head;
        while (p != null) {
            q = p.next;
            q.random = p.random == null ? null : p.random.next;
            p = p.next.next;
        }
        p = head;
        while (p != null) {
            q = p.next;
            p.next = q.next;
            q.next = q.next == null ? null : q.next.next;
            p = p.next;
        }

        return res;
    }
}
