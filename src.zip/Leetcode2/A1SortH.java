package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/15
 **/
public class A1SortH {
    //T(N) = a*T(N/b) + O(N^d)
    //log(b,a) > d  ==> O(N^log(b,a))
    //log(b,a) = d  ==> O(N^d * logN)
    //log(b,a) < d  ==> O(N^d)

    //      时间      空间       稳定

    //选择   n2       1         ×
    //冒泡   n2       1         √
    //插入   n2       1         √

    //归并   nlogn    n         √       稳定  内部缓存法退化为不稳定，原地归并排序时间n2
    //快排   nlogn    logn      ×       时间  稳定快排空间n
    //堆排   nlogn    1         ×       空间

    //桶排                      √

    public class Solution912 {
        public int[] sortArray(int[] nums) {
            int n = nums.length;
            for (int i = n / 2; i >= 0; i--) {
                sink(nums, i, n - 1);
            }
            for (int i = n - 1; i >= 1; i--) {
                int tmp = nums[0];
                nums[0] = nums[i];
                nums[i] = tmp;
                sink(nums, 0, i - 1);
            }
            return nums;
        }

        private void sink(int[] nums, int k, int limit) {
            int temp = nums[k];
            while (2 * k + 1 <= limit) {
                int i = 2 * k + 1;
                if (i + 1 <= limit && nums[i] < nums[i + 1]) {
                    i++;
                }
                if (temp > nums[i]) break;
                nums[k] = nums[i];
                k = i;
            }
            nums[k] = temp;
        }

//    private void sink(int[] nums, int k, int limit) {
//        int temp = nums[k];
//        for (int i = 2 * k + 1; i <= limit; i = 2 * i + 1) {
//            if (i < limit && nums[i] < nums[i + 1]) {
//                i++;
//            }
//            if (temp > nums[i]) break;
//            nums[k] = nums[i];
//            k = i;
//        }
//        nums[k] = temp;
//    }

    }

    //已知一个几乎有序的数组，几乎有序是指，如果把数组排好顺序的话，每个元素移动的距离可以不超过k，并且k相对于数组来说比较小。
    //请选择一个合适的排序算法对这个数据进行排序
}
