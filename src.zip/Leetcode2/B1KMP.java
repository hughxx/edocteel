package Leetcode2;

/**
 * @author : hu
 * @since : 2023/7/14
 **/
public class B1KMP {
    //28
    public int strStr(String s, String target) {
        int[] next = new int[target.length()];
        next[0] = -1;
        int j = -1;
        for (int i = 1; i < target.length(); i++) {
            while (j >= 0 && target.charAt(i) != target.charAt(j + 1)){
                j = next[j];
            }
            if (target.charAt(i) == target.charAt(j+ 1)) {
                j++;
            }
            next[i] = j;
        }

        j = -1;
        for (int i = 0; i < s.length(); i++) {
            while (j >= 0 && s.charAt(i) != target.charAt(j + 1)) {
                j = next[j];
            }
            if (s.charAt(i) == target.charAt(j + 1)) {
                j++;
            }
            if (j == target.length() - 1) {
                return i - target.length() + 1;
            }
        }

        return -1;
    }

    //旋转字符串
}
