package X.LeetcodeOut;

/**
 * @author : hu
 **/
public class APalindrome {

    class Solution647 {
        public int countSubstrings(String s) {
            int n = s.length();
            StringBuilder sb = new StringBuilder("$#");
            for (int i = 0; i < n; ++i) {
                sb.append(s.charAt(i));
                sb.append('#');
            }
            n = sb.length();
            sb.append('!');

            int[] f = new int[n];
            int iMax = 0, rMax = 0, ans = 0;
            for (int i = 1; i < n; ++i) {
                // 初始化 f[i]
                f[i] = i <= rMax ? Math.min(rMax - i + 1, f[2 * iMax - i]) : 1;
                // 中心拓展
                while (sb.charAt(i + f[i]) == sb.charAt(i - f[i])) {
                    ++f[i];
                }
                // 动态维护 iMax 和 rMax
                if (i + f[i] - 1 > rMax) {
                    iMax = i;
                    rMax = i + f[i] - 1;
                }
                // 统计答案
                ans += f[i] / 2;
            }

            return ans;
        }
    }

    class Solution {
        public String longestPalindrome(String s) {
            String res = "";
            for (int i = 0; i < s.length(); i++) {
                String s1 = palindrome(s, i, i);
                String s2 = palindrome(s, i, i + 1);
                res = res.length() > s1.length() ? res : s1;
                res = res.length() > s2.length() ? res : s2;
            }
            return res;
        }

        private String palindrome(String s, int i, int j) {
            while (i >= 0 && j < s.length() && s.charAt(i) == s.charAt(j)) {
                i--;
                j++;
            }
            return s.substring(i + 1, j);
        }
    }
}
