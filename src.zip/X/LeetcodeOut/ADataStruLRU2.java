package X.LeetcodeOut;

import java.util.HashMap;

/**
 * @author : hu
 **/
public class ADataStruLRU2 {
    class LRUCache {

        class LRUNode {
            int key, val;
            LRUNode prev, next;
            LRUNode(int key, int val) {
                this.key = key;
                this.val = val;
            }
        }

        class LRUList {
            LRUNode head, tail;
            LRUList() {
                head = new LRUNode(-1,-1);
                tail = new LRUNode(-1, -1);
                head.next = tail;
                tail.prev = head;
            }

            void addLast(LRUNode node) {
                node.next = tail;
                node.prev = tail.prev;
                tail.prev.next = node;
                tail.prev = node;
            }

            void remove(LRUNode node) {
                node.prev.next = node.next;
                node.next.prev = node.prev;
            }

            void moveToLast(LRUNode node) {
                remove(node);
                addLast(node);
            }

            LRUNode removeFirst() {
                LRUNode old = head.next;
                remove(old);
                return old;
            }
        }

        HashMap<Integer, LRUNode> map;
        LRUList list;
        int size;
        int cap;

        public LRUCache(int capacity) {
            map = new HashMap<>();
            list = new LRUList();
            cap = capacity;
        }

        public int get(int key) {
            if (!map.containsKey(key)) return -1;
            LRUNode node = map.get(key);
            list.moveToLast(node);
            return node.val;
        }

        public void put(int key, int val) {
            LRUNode node = map.get(key);
            if (node != null) {
                node.val = val;
                list.moveToLast(node);
            } else {
                if (size == cap) {
                    LRUNode old = list.removeFirst();
                    map.remove(old.key);
                    size--;
                }
                node = new LRUNode(key, val);
                list.addLast(node);
                map.put(key, node);
                size++;
            }
        }
    }
}
