package X.LeetcodeOut;

import java.util.LinkedList;

/**
 * @author : hu
 **/
public class ACalculator {
    class Solution394 {
        public String decodeString(String s) {
            LinkedList<Character> list = new LinkedList<>();
            for (int i = 0; i < s.length(); i++) {
                list.add(s.charAt(i));
            }
            return helper(list);
        }

        String helper(LinkedList<Character> list) {
            StringBuilder sb = new StringBuilder();
            int num = 0;
            while(!list.isEmpty()) {
                char c = list.removeFirst();
                if(Character.isDigit(c)) {
                    num = 10 * num + (c - '0');
                }
                if(c == '[') {
                    String s = helper(list);
                    for(int i = 0; i < num; i++) {
                        sb.append(s);
                    }
                    num = 0;
                }
                if (c == ']') {
                    break;
                }
                if (Character.isLetter(c)) {
                    sb.append(c);
                }
            }
            return sb.toString();
        }
    }

    class Solution224 {
        class Solution {
            public int calculate(String s) {
                LinkedList<Character> list = new LinkedList<>();
                for (int i = 0; i < s.length(); i++) {
                    list.add(s.charAt(i));
                }
                return helper(list);
            }

            int helper(LinkedList<Character> list) {
                LinkedList<Integer> stack = new LinkedList<>();
                int num = 0;
                char sign = '+';
                while(!list.isEmpty()) {
                    char c = list.removeFirst();
                    if(Character.isDigit(c)) {
                        num = num * 10 + (c - '0');
                    }
                    if(c == '(') {
                        num = helper(list);
                    }
                    if((!Character.isDigit(c) && c != ' ') || list.isEmpty()) {
                        switch (sign) {
                            case '+' :
                                stack.add(num);
                                break;
                            case '-' :
                                stack.add(-num);
                                break;
                            case '*' :
                                stack.add(stack.removeLast() * num);
                                break;
                            case '/' :
                                stack.add(stack.removeLast() / num);
                                break;
                        }
                        sign = c;
                        num = 0;
                    }
                    if (c == ')') {
                        break;
                    }
                }
                int ret = 0;
                while(!stack.isEmpty()) {
                    ret += stack.removeLast();
                }
                return ret;
            }
        }
    }
}
