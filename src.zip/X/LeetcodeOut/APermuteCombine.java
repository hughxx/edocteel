package X.LeetcodeOut;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @author : hu
 **/
public class APermuteCombine {
    //排列
    class Solution46 {
        List<List<Integer>> res = new ArrayList<>();
        List<Integer> track = new ArrayList<>();

        public List<List<Integer>> permute(int[] nums) {
            backtrack(nums, new boolean[nums.length]);
            return res;
        }

        private void backtrack(int[] nums, boolean[] used) {
            if (track.size() == nums.length) {
                res.add(new ArrayList<>(track));
                return;
            }

            for (int i = 0; i < nums.length; i++) {
                if (used[i]) continue;
                used[i] = true;
                track.add(nums[i]);
                backtrack(nums, used);
                used[i] = false;
                track.remove(track.size() - 1);
            }
        }
    }

    //组合
    class Solution77 {
        LinkedList<Integer> track = new LinkedList<>();
        List<List<Integer>> res = new LinkedList<>();

        public List<List<Integer>> combine(int n, int k) {
            backtrack(n, k, 1);
            return res;
        }

        void backtrack(int n, int k, int start) {
            if (track.size() == k) {
                res.add(new LinkedList<>(track));
                return;
            }

            for (int i = start; i <= n; i++) {
                track.add(i);
                backtrack(n, k, i + 1);
                track.removeLast();
            }
        }
    }
}
