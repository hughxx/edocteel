package X.LeetcodeOut;

/**
 * @author : hu
 **/
public class ADataStruc {
    // 栈 队列 堆
}
