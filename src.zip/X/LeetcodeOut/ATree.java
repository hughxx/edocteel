package X.LeetcodeOut;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @author : hu
 **/
public class ATree {
    //队列
    class Solution101 {
        public boolean isSymmetric(TreeNode root) {
            Queue<TreeNode> q = new LinkedList<>();
            q.offer(root.left);
            q.offer(root.right);
            while (!q.isEmpty()) {
                TreeNode l = q.poll(), r = q.poll();
                if (l == null && r == null) continue;
                if (l == null || r == null || l.val != r.val) return false;
                q.offer(l.left);
                q.offer(r.right);
                q.offer(l.right);
                q.offer(r.left);
            }
            return true;
        }
    }

    //递归
    class Solution226 {
        public TreeNode invertTree(TreeNode root) {
            if(root == null) return null;

            TreeNode left = invertTree(root.left);
            TreeNode right = invertTree(root.right);
            root.left = right;
            root.right = left;

            return root;
        }
    }
}
