package X.LeetcodeOut;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hu
 **/
public class AMatrix {
    //旋转
    class Solution48 {
        public void rotate(int[][] matrix) {
            int m = matrix.length, n = matrix[0].length;
            int up = 0, down = m - 1, left = 0, right = n - 1;
            while(up <= down && left <= right) {
                traverse(matrix, up++, down--, left++, right--);
            }
        }

        void traverse(int[][] matrix, int up, int down, int left, int right) {
            if(up == down) return;

            for(int i = 0; i < right - left; i++) {
                int temp = matrix[up][left + i];
                matrix[up][left + i] = matrix[down - i][left];
                matrix[down - i][left] = matrix[down][right - i];
                matrix[down][right - i] = matrix[up + i][right];
                matrix[up + i][right] = temp;
            }
        }
    }

    //螺旋
    class Solution54 {
        public List<Integer> spiralOrder(int[][] matrix) {
            int m = matrix.length, n = matrix[0].length;
            int left = 0, right = n - 1, up = 0, down = m - 1;
            List<Integer> res = new ArrayList<>();
            while (res.size() < m * n) {
                if (up <= down) {
                    for (int i = left; i <= right; i++) {
                        res.add(matrix[up][i]);
                    }
                    up++;
                }
                if (left <= right) {
                    for (int i = up; i <= down; i++) {
                        res.add(matrix[i][right]);
                    }
                    right--;
                }
                if (up <= down) {
                    for (int i = right; i >= left; i--) {
                        res.add(matrix[down][i]);
                    }
                    down--;
                }
                if (left <= right) {
                    for (int i = down; i >= up; i--) {
                        res.add(matrix[i][left]);
                    }
                    left++;
                }
            }
            return res;
        }
    }

    //zigzag
    void printMatrixZigZag(int[][] matrix) {
        int ar = 0;//右上角
        int ac = 0;
        int br = 0;//左下角
        int bc = 0;
        int endR = matrix.length - 1;
        int endC = matrix[0].length - 1;
        boolean fromUp = false;
        while (ar != endR + 1) {
            //printLevel();
            ar = ac == endC ? ar + 1 : ar;
            ac = ac == endC ? ac : ac + 1;
            bc = br == endR ? bc + 1 : bc;
            br = br == endR ? br : br + 1;
            fromUp = !fromUp;
        }
    }
}
