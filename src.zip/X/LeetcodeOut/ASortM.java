package X.LeetcodeOut;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hu
 **/
public class ASortM {
    class Solution912 {
        int[] temp;

        public int[] sortArray(int[] nums) {
            temp = new int[nums.length];
            sort(nums, 0, nums.length - 1);
            return nums;
        }

        void sort(int[] nums, int left, int right) {
            if (left >= right) return;

            int mid = left + (right - left) / 2;
            sort(nums,left, mid);
            sort(nums, mid + 1, right);
            merge(nums, left, mid, right);
        }

        void merge(int[] nums, int left, int mid, int right) {
            for (int i = left; i <= right; i++) {
                temp[i] = nums[i];
            }
            int i = left, j = mid + 1;
            for (int p = left; p <= right; p++) {
                if (i > mid) {
                    nums[p] = temp[j++];
                } else if (j > right) {
                    nums[p] = temp[i++];
                } else if (temp[i] <= temp[j]) {
                    nums[p] = temp[i++];
                } else {
                    nums[p] = temp[j++];
                }
            }
        }
    }

    class Solution315 {
        int[][] temp;
        int[] counts;

        public List<Integer> countSmaller(int[] nums) {
            int n = nums.length;
            temp = new int[n][2];
            counts = new int[n];

            int[][] arr = new int[n][2];
            for (int i = 0; i < n; i++) {
                arr[i][0] = nums[i];
                arr[i][1] = i;
            }
            sort(arr, 0, n - 1);

            List<Integer> res = new ArrayList<>();
            for(int count : counts) res.add(count);
            return res;
        }

        void sort(int[][] nums, int left, int right) {
            if (left >= right) return;

            int mid = left + (right - left) / 2;
            sort(nums, left, mid);
            sort(nums, mid + 1, right);
            merge(nums, left, mid, right);
        }

        void merge(int[][] nums, int left, int mid, int right) {
            for (int i = left; i <= right; i++) {
                temp[i] = nums[i];
            }
            int i = left, j = mid + 1;
            for (int p = left; p <= right; p++) {
                if (i > mid) {
                    nums[p] = temp[j++];
                } else if (j > right) {
                    counts[temp[i][1]] += j - mid - 1;
                    nums[p] = temp[i++];
                } else if (temp[i][0] <= temp[j][0]) {
                    counts[temp[i][1]] += j - mid - 1;
                    nums[p] = temp[i++];
                } else {
                    nums[p] = temp[j++];
                }
            }
        }
    }

    // 327 493 不用看困难
}
