package X.LeetcodeOut;

/**
 * @author : hu
 **/
public class AKMP {
    int kmp(String s, String t) {
        int[] next = new int[t.length()];
        next[0] = -1;
        int j = -1;
        for (int i = 1; i < t.length(); i++) {
            while (j >= 0 && t.charAt(i) != t.charAt(j + 1)) {
                j = next[j];
            }
            if (t.charAt(i) == t.charAt(j + 1)) {
                j++;
            }
            next[i] = j;
        }


        j = -1;
        for (int i = 0; i < s.length(); i++) {
            while (j >= 0 && s.charAt(i) != t.charAt(j + 1)) {
                j = next[j];
            }
            if (s.charAt(i) == t.charAt(j + 1)) {
                j++;
            }
            if (j == t.length() - 1) {
                return i - t.length() + 1;
            }
        }

        return -1;
    }
}
