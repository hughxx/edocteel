package X.LeetcodeOut;

/**
 * @author : hu
 **/
public class AListReverse {
    // 指针反转：反转全部，反转前n个，反转任意区间

    // 反转任意部分
    class Solution92 {
        public ListNode reverseBetween(ListNode head, int left, int right) {
            ListNode dummy = new ListNode(-1);
            dummy.next = head;

            ListNode pre = null, p = dummy;
            for (int i = 0; i < left; i++) {
                pre = p;
                p = p.next;;
            }
            ListNode start = pre;
            for (int i = left; i <= right; i++) {
                ListNode tmp = p.next;
                p.next = pre;
                pre = p;
                p = tmp;
            }
            start.next.next = p;
            start.next = pre;
            return dummy.next;
        }
    }
    // 反转任意部分
    class Solution25 {
        public ListNode reverse(ListNode start, ListNode end) {
            ListNode pre = null, p = start;
            while (p != end) {
                ListNode tmp = p;
                p = p.next;
                tmp.next = pre;
                pre = tmp;
            }
            return pre;
        }
    }

    // 递归反转：反转全部，反转前n个，反转任意区间
}
