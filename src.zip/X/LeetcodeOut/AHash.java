package X.LeetcodeOut;

/**
 * @author : hu
 **/
public class AHash {
    //128 -> 523/560/974
}
