package X.LeetcodeOut;

/**
 * @author : hu
 **/
public class ARotateArray {
    //旋转数组189 旋转链表61

    //无重复旋转数组最小值153
    class Solution153 {
        public int findMin(int[] nums) {
            int left = 0, right = nums.length - 1;
            while (left <= right) {
                int mid = left + (right - left) / 2;
                if (nums[mid] > nums[right]) {
                    left = mid + 1;
                } else if (nums[mid] < nums[right]) {
                    right = mid;
                } else {
                    right--;
                }
            }
            return nums[left];
        }
    }

    //有重复最小值154
    class Solution154 {
        public int findMin(int[] nums) {
            int left = 0, right = nums.length - 1;
            while (left <= right) {
                int mid = left + (right - left) / 2;
                if (nums[mid] > nums[right]) {
                    left = mid + 1;
                } else if (nums[mid] < nums[right]) {
                    right = mid;
                } else {
                    right--;
                }
            }
            return nums[left];
        }
    }


    //-----------------------------------------------------//

    //33无重复返回一个target
    class Solution33 {
        public int search(int[] nums, int target) {
            int left = 0, right = nums.length - 1;
            while (left <= right) {
                int mid = (left + right) >>> 1;
                if (nums[mid] == target) {
                    return mid;
                }
                if (nums[mid] > nums[right]) {
                    if (nums[left] <= target && target < nums[mid]) {
                        right = mid - 1;
                    } else {
                        left = mid + 1;
                    }
                } else if (nums[mid] < nums[right]) {
                    if (nums[mid] < target && target <= nums[right]) {
                        left = mid + 1;
                    } else {
                        right = mid - 1;
                    }
                } else {
                    right--;
                }
            }
            return -1;
        }
    }


    //81有重复看target在不在
    class Solution81 {
        public boolean search(int[] nums, int target) {
            int left = 0, right = nums.length - 1;
            while (left <= right) {
                int mid = (left + right) >>> 1;
                if (nums[mid] == target) {
                    return true;
                }
                if (nums[mid] > nums[right]) {
                    if (nums[left] <= target && target < nums[mid]) {
                        right = mid - 1;
                    } else {
                        left = mid + 1;
                    }
                } else if (nums[mid] < nums[right]) {
                    if (nums[mid] < target && target <= nums[right]) {
                        left = mid + 1;
                    } else {
                        right = mid - 1;
                    }
                } else {
                    right--;
                }
            }
            return false;
        }
    }


    //面试10.03有重复返回target中索引最小的
    class Solution1003 {
        public int search(int[] arr, int target) {
            if (arr[0] == target) {
                return 0;
            }

            int left = 0, right = arr.length - 1;
            while (left <= right) {
                int mid = (left + right) >>> 1;
                if (arr[mid] == target) {
                    while (mid > 1 && arr[mid - 1] == arr[mid]) {
                        mid--;
                    }
                    return mid;
                }
                if (arr[mid] > arr[right]) {
                    if (arr[left] <= target && target < arr[mid]) {
                        right = mid - 1;
                    } else {
                        left = mid + 1;
                    }
                } else if (arr[mid] < arr[right]) {
                    if (arr[mid] < target && target <= arr[right]) {
                        left = mid + 1;
                    } else {
                        right = mid - 1;
                    }
                } else {
                    right--;
                }
            }
            return -1;
        }
    }
}
