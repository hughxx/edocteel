package X.LeetcodeOut;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

/**
 * @author : hu
 **/
public class ADataStrucStackQueue {
    //先刷LRULFU 再刷栈

    //155 最小栈
    class Solution155 {
        class MinStack {

            Stack<Integer> minStack = new Stack<>();
            Stack<Integer> stack = new Stack<>();

            public MinStack() {

            }

            public void push(int val) {
                if (stack.isEmpty()) {
                    minStack.push(val);
                } else if (val < minStack.peek()) {
                    minStack.push(val);
                } else {
                    minStack.push(minStack.peek());
                }
                stack.push(val);
            }

            public void pop() {
                minStack.pop();
                stack.pop();
            }

            public int top() {
                return stack.peek();
            }

            public int getMin() {
                return minStack.peek();
            }
        }
    }

    // 中位数
    class Solution295 {
        class MedianFinder {

            PriorityQueue<Integer> pq1 = new PriorityQueue<>((a, b) -> b - a);
            PriorityQueue<Integer> pq2 = new PriorityQueue<>((a, b) -> a - b);

            public MedianFinder() {

            }

            public void addNum(int num) {
                if (pq1.size() == pq2.size()) {
                    pq1.offer(num);
                    pq2.offer(pq1.poll());
                } else {
                    pq2.offer(num);
                    pq1.offer(pq2.poll());
                }
            }

            public double findMedian() {
                if (pq1.size() == pq2.size()) return (pq1.peek() + pq2.peek()) / 2.0;
                return pq2.peek();
            }
        }
    }

    // 栈实现队列
    class Solution232 {
        class MyQueue {

            Stack<Integer> stack1 = new Stack<>();
            Stack<Integer> stack2 = new Stack<>();

            public MyQueue() {

            }

            public void push(int x) {
                stack1.push(x);
            }

            public int pop() {
                peek();
                return stack2.pop();
            }

            public int peek() {
                if (!stack2.isEmpty()) return stack2.peek();
                int size = stack1.size();
                while (size > 0) {
                    stack2.push(stack1.pop());
                    size--;
                }
                return stack2.peek();
            }

            public boolean empty() {
                return stack1.empty() && stack2.empty();
            }
        }
    }

    // 队列实现栈
    class Solution225 {
        class MyStack {

            Queue<Integer> q;
            int top_elem;

            public MyStack() {
                q = new LinkedList<>();
            }

            public void push(int x) {
                q.offer(x);
                top_elem = x;
            }

            public int pop() {
                int size = q.size();
                while (size > 2) {
                    q.offer(q.poll());
                    size--;
                }
                top_elem = q.peek();
                q.offer(q.poll());
                return q.poll();
            }

            public int top() {
                return top_elem;
            }

            public boolean empty() {
                return q.isEmpty();
            }
        }
    }
}
