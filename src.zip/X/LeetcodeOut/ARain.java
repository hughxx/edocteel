package X.LeetcodeOut;

/**
 * @author : hu
 **/
public class ARain {
    //11
    public int maxArea(int[] height) {
        int res = 0;
        int left = 0, right = height.length - 1;
        while (left < right) {
            int area = (right - left) * Math.min(height[right], height[left]);
            res = Math.max(res, area);
            if (height[right] > height[left]) left++;
            else right--;
        }
        return res;
    }

    //42
    public int trap(int[] height) {
        int n = height.length;
        int left = 0, right = n - 1;
        int leftMax = 0, rightMax = 0;
        int ans = 0;
        while(left < right) {
            leftMax = Math.max(height[left], leftMax);
            rightMax = Math.max(height[right], rightMax);
            if(leftMax < rightMax) {
                ans += leftMax - height[left];
                ++left;
            } else {
                ans += rightMax - height[right];
                right--;
            }
        }
        return ans;
    }
}
