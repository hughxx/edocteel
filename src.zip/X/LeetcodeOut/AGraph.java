package X.LeetcodeOut;

import javafx.util.Pair;

import java.util.*;

/**
 * @author : hu
 **/
public class AGraph {

    class Solution207TopoD {
        List<Integer>[] graph;
        boolean[] visited;
        boolean[] onPath;
        boolean hasCycle;

        public boolean canFinish(int numCourses, int[][] prerequisites) {
            graph = buildGraph(numCourses, prerequisites);
            visited = new boolean[numCourses];
            onPath = new boolean[numCourses];
            for (int i = 0; i < numCourses; i++) {
                dfs(i);
            }
            return !hasCycle;
        }

        void dfs(int i) {
            for (int neighbor : graph[i]) {
                if (hasCycle) return;
                if (onPath[neighbor]) {
                    hasCycle = true;
                    return;
                }
                if (visited[neighbor]) continue;
                visited[neighbor] = true;
                onPath[neighbor] = true;
                dfs(neighbor);
                onPath[neighbor] = false;
            }
        }

        List<Integer>[] buildGraph(int numCourses, int[][] prerequisites) {
            List<Integer>[] graph = new List[numCourses];
            for (int i = 0; i < numCourses; i++) {
                graph[i] = new LinkedList<>();
            }
            for (int[] prerequisite : prerequisites) {
                int to = prerequisite[0], from = prerequisite[1];
                graph[from].add(to);
            }
            return graph;
        }
    }

    class Solution210TopoB {
        public int[] findOrder(int numCourses, int[][] prerequisites) {
            int[] indegree = new int[numCourses];
            List<Integer>[] graph = new List[numCourses];
            for (int i = 0; i < numCourses; i++) {
                graph[i] = new ArrayList<>();
            }
            for (int[] pre : prerequisites) {
                int u = pre[0];
                int v = pre[1];
                graph[v].add(u);
                indegree[u]++;
            }

            Queue<Integer> q = new LinkedList<>();
            int count = 0;
            int[] res = new int[numCourses];
            for (int i = 0; i < numCourses; i++) {
                if (indegree[i] == 0) {
                    q.offer(i);
                    res[count] = i;
                    count++;
                }
            }
            while (!q.isEmpty()) {
                int cur = q.poll();
                for (int neighbor : graph[cur]) {
                    indegree[neighbor]--;
                    if (indegree[neighbor] == 0) {
                        q.offer(neighbor);
                        res[count] = neighbor;
                        count++;
                    }
                }
            }
            return count == numCourses ? res : new int[]{};
        }
    }

    class Solution1584K {
        public int minCostConnectPoints(int[][] points) {
            int n = points.length;
            List<int[]> edges = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                for (int j = i + 1; j < n; j++) {
                    int[] x = points[i];
                    int[] y = points[j];
                    int d = Math.abs(x[0] - y[0]) + Math.abs(x[1] - y[1]);
                    edges.add(new int[]{i, j, d});
                }
            }
            Collections.sort(edges, (a, b) -> a[2] - b[2]);

            UF uf = new UF(n);
            int res = 0;
            for (int[] edge : edges) {
                if (uf.isConnected(edge[0], edge[1])) continue;
                uf.connect(edge[0], edge[1]);
                res += edge[2];
            }
            return res;
        }

        class UF {
            int count;
            int[] parent;

            UF(int n) {
                count = n;
                parent = new int[n];
                for (int i = 0; i < n; i++) {
                    parent[i] = i;
                }
            }

            boolean isConnected(int p, int q) {
                int rootP = find(p);
                int rootQ = find(q);
                return rootP == rootQ;
            }

            void connect(int p, int q) {
                int rootP = find(p);
                int rootQ = find(q);
                if (rootP == rootQ) return;
                parent[rootP] = rootQ;
                count--;
            }

            int count() {
                return count;
            }

            int find(int p) {
                if (parent[p] != p) {
                    parent[p] = find(parent[p]);
                }
                return parent[p];
            }
        }
    }

    class Solution1584P {
        public int minCostConnectPoints(int[][] points) {
            int n = points.length;
            List<int[]>[] graph = buildGraph(n, points);
            boolean[] visited = new boolean[n];

            PriorityQueue<int[]> pq = new PriorityQueue<>((a, b) -> a[2] - b[2]);
            visited[0] = true;
            for (int[] edge: graph[0]) {
                pq.offer(edge);
            }

            int res = 0;
            while (!pq.isEmpty()) {
                int[] edge = pq.poll();
                if (visited[edge[1]]) continue;
                visited[edge[1]] = true;
                res += edge[2];
                for (int[] neighbor : graph[edge[1]]) {
                    //可以小做一下visited的操作，为了清晰，可以不写
                    pq.add(neighbor);
                }
            }
            return res;
        }

        List<int[]>[] buildGraph(int n, int[][] points) {
            List<int[]>[] graph = new LinkedList[n];
            for (int i = 0; i < n; i++) {
                graph[i] = new LinkedList<>();
            }
            // 生成所有边及权重
            for (int i = 0; i < n; i++) {
                for (int j = i + 1; j < n; j++) {
                    int xi = points[i][0], yi = points[i][1];
                    int xj = points[j][0], yj = points[j][1];
                    int weight = Math.abs(xi - xj) + Math.abs(yi - yj);
                    // 用 points 中的索引表示坐标点
                    graph[i].add(new int[]{i, j, weight});
                    graph[j].add(new int[]{j, i, weight});
                }
            }
            return graph;
        }
    }

    class Solution1514Dij {
        public double maxProbability(int n, int[][] edges, double[] succProb, int start, int end) {
            List<Pair<Integer, Double>>[] graph = buildGraph(n, edges, succProb);
            Queue<Pair<Integer, Double>> q = new LinkedList<>();
            double[] distTo = new double[n];
            Arrays.fill(distTo, 0);
            q.offer(new Pair<>(start, 1.0));
            while (!q.isEmpty()) {
                Pair<Integer, Double> cur = q.poll();
                int i = cur.getKey();
                double d = cur.getValue();
                if (d < distTo[i]) continue;
                for (Pair<Integer, Double> neighbor : graph[i]) {
                    double curDistTo = d * neighbor.getValue();
                    if (curDistTo > distTo[neighbor.getKey()]) {
                        distTo[neighbor.getKey()] = curDistTo;
                        q.offer(new Pair<>(neighbor.getKey(), curDistTo));
                    }
                }
            }
            return distTo[end];
        }

        private List<Pair<Integer, Double>>[] buildGraph(int n, int[][] edges, double[] succProb) {
            List<Pair<Integer, Double>>[] graph = new List[n];
            for (int i = 0; i < n; i++) {
                graph[i] = new ArrayList<>();
            }
            for (int i = 0; i < edges.length; i++) {
                int u = edges[i][0];
                int v = edges[i][1];
                graph[u].add(new Pair<>(v, succProb[i]));
                graph[v].add(new Pair<>(u, succProb[i]));
            }
            return graph;
        }
    }
}
