package X.LeetcodeOut;

/**
 * @author : hu
 **/
public class ABinarySearch {
    // 大于等于某值的最小索引
    // 多维： 4 二维矩阵两道 赛马
    // 问题出发： 162

    class Solution34 {
        public int[] searchRange(int[] nums, int target) {
            int left = leftBound(nums, target);
            int right = rightBound(nums, target);
            return new int[] {left, right};
        }

        private int leftBound(int[] nums, int target) {
            int left = 0, right = nums.length - 1;
            while (left <= right) {
                int mid = left + (right - left) / 2;
                if (nums[mid] < target) {
                    left = mid + 1;
                } else {
                    right = mid - 1;
                }
            }
            if (right + 1 == nums.length) return -1;
            return nums[right + 1] == target ? right + 1 : -1;
        }

        private int rightBound(int[] nums, int target) {
            int left = 0, right = nums.length;
            while (left < right) {
                int mid = left + (right - left) / 2;
                if (nums[mid] <= target) {
                    left = mid + 1;
                } else {
                    right = mid;
                }
            }
            if (left - 1 < 0) return -1;
            return nums[left - 1] == target ? left - 1 : -1;
        }
    }
}
