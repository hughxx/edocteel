package X.LeetcodeOut;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;

/**
 * @author : hu
 **/
public class ADataStrucLRULFU {
    // 先刷这个 再刷栈

    class Solution146 {

        class LRUCache {

            private HashMap<Integer, LRUNode> map;
            private LRULinkedList list;
            private int cap;
            private int size;


            public LRUCache(int capacity) {
                map = new HashMap<>();
                list = new LRULinkedList();
                cap = capacity;
            }

            public int get(int key) {
                if (!map.containsKey(key)) return -1;
                LRUNode node = map.get(key);
                list.moveToLast(node);
                return node.val;
            }

            public void put(int key, int value) {
                LRUNode node = map.get(key);
                if (node != null) {
                    node.val = value;
                    list.moveToLast(node);
                } else {
                    if (size == cap) {
                        LRUNode old = list.removeFirst();
                        map.remove(old.key);
                        size--;
                    }
                    node = new LRUNode(key, value);
                    list.addLast(node);
                    map.put(key, node);
                    size++;
                }
            }

            class LRUNode {
                int key, val;
                LRUNode next, prev;

                LRUNode(int key, int val) {
                    this.key = key;
                    this.val = val;
                }
            }

            class LRULinkedList {

                LRUNode head, tail;

                LRULinkedList() {
                    head = new LRUNode(-1, -1);
                    tail = new LRUNode(-1, -1);
                    head.next = tail;
                    tail.prev = head;
                }

                void moveToLast(LRUNode node) {
                    remove(node);
                    addLast(node);
                }

                LRUNode removeFirst() {
                    if (head.next == tail) return null;
                    LRUNode node = head.next;
                    remove(node);
                    return node;
                }

                void addLast(LRUNode node) {
                    node.next = tail;
                    node.prev = tail.prev;
                    tail.prev.next = node;
                    tail.prev = node;
                }

                void remove(LRUNode node) {
                    node.prev.next = node.next;
                    node.next.prev = node.prev;
                }
            }
        }
    }

    class Solution460 {
        class LFUCache {

            HashMap<Integer, Integer> keyToVal;
            HashMap<Integer, Integer> keyToFreq;
            HashMap<Integer, LinkedHashSet<Integer>> freqToKey;
            int cap;
            int minFreq;

            public LFUCache(int capacity) {
                keyToVal = new HashMap<>();
                keyToFreq = new HashMap<>();
                freqToKey = new HashMap<>();
                cap = capacity;
            }

            public int get(int key) {
                if (!keyToVal.containsKey(key)) return -1;
                incrementFreq(key);
                return keyToVal.get(key);
            }


            public void put(int key, int value) {
                if (keyToVal.containsKey(key)) {
                    keyToVal.put(key, value);
                    incrementFreq(key);
                } else {
                    if (keyToVal.size() == cap) {
                        removeMinFreq();
                    }
                    keyToVal.put(key, value);
                    keyToFreq.put(key, 1);
                    minFreq = 1;
                    freqToKey.putIfAbsent(1, new LinkedHashSet<>());
                    LinkedHashSet<Integer> set = freqToKey.get(1);
                    set.add(key);
                }
            }

            private void removeMinFreq() {
                LinkedHashSet<Integer> set = freqToKey.get(minFreq);
                Iterator<Integer> iterator = set.iterator();
                int key = iterator.next();
                set.remove(key);
                if (set.isEmpty()) freqToKey.remove(minFreq);
                keyToVal.remove(key);
                keyToFreq.remove(key);
            }

            private void incrementFreq(int key) {
                int freq = keyToFreq.getOrDefault(key, 0);
                keyToFreq.put(key, freq + 1);
                LinkedHashSet<Integer> oldSet = freqToKey.get(freq);
                oldSet.remove(key);
                if (oldSet.isEmpty()) {
                    if (freq == minFreq) minFreq = freq + 1;
                    freqToKey.remove(freq);
                }
                freqToKey.putIfAbsent(freq + 1, new LinkedHashSet<>());
                LinkedHashSet<Integer> newSet = freqToKey.get(freq + 1);
                newSet.add(key);
            }
        }
    }
}
