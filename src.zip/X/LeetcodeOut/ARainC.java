package X.LeetcodeOut;

import java.util.PriorityQueue;

/**
 * @author : hu
 **/
public class ARainC {
    public int trapRainWater(int[][] heightMap) {
        int m = heightMap.length, n = heightMap[0].length;

        boolean[][] visited = new boolean[m][n];
        PriorityQueue<int[]> pq = new PriorityQueue<>((a, b) -> a[1] - b[1]);
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (i == 0 || i == m - 1 || j == 0 || j == n - 1) {
                    pq.offer(new int[]{i * n + j, heightMap[i][j]});
                    visited[i][j] = true;
                }
            }
        }

        int[] dirs = new int[]{-1, 0, 1, 0, -1};
        int res = 0;
        while (!pq.isEmpty()) {
            int[] cur = pq.poll();
            for (int i = 0; i < 4; i++) {
                int x = cur[0] / n + dirs[i];
                int y = cur[0] % n + dirs[i + 1];
                if (!visited[x][y] || x < 0 || x >= m || y < 0 || y >= n) continue;
                if (heightMap[x][y] < cur[1]) {
                    res += heightMap[x][y] - cur[1];
                }
                visited[x][y] = true;
                pq.offer(new int[]{x * n + y, Math.max(heightMap[x][y], cur[1])});
            }
        }
        return res;
    }
}
