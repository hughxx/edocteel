package X.LeetcodeOut;

import java.util.Deque;
import java.util.LinkedList;

/**
 * @author : hu
 **/
public class AMissDuplicate {
    //442/448/645(easy) -> 287不允许修改(hard) ->剑指03从0开始(hard) -> 41有负数和零(hard)
    public String removeKdigits(String num, int k) {
        Deque<Integer> deque = new LinkedList<>();
        for (int i = 0; i < num.length(); i++) {
            int x = num.charAt(i) - '0';
            while (k > 0 && !deque.isEmpty() && x < deque.peekLast()) {
                deque.pollLast();
                k--;
            }
            deque.offerLast(x);
        }

        while (!deque.isEmpty() && deque.peek() == 0) {
            deque.pollLast();
        }
        StringBuilder sb = new StringBuilder();
        while (!deque.isEmpty()) {
            sb.append(deque.pollFirst());
        }
        return sb.toString();
    }
}
