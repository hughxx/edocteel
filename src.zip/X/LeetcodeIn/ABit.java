package X.LeetcodeIn;

/**
 * @author : hu
 **/
public class ABit {
    class Solution338 {
        //最高有效位：去掉第一个1
        public int[] countBits0(int n) {
            int[] res = new int[n + 1];
            int x = 1;
            for(int i = 1; i <= n; i++) {
                if((i & (i - 1)) == 0) x = i;
                res[i] = 1 + res[i - x];
            }
            return res;
        }

        //最低有效位：去掉最后一位
        public int[] countBits1(int n) {
            int[] bits = new int[n + 1];
            for (int i = 1; i <= n; i++) {
                bits[i] = bits[i >> 1] + (i & 1);
            }
            return bits;
        }

        //最低设置位：去掉最后一个1
        public int[] countBits2(int n) {
            int[] bits = new int[n + 1];
            for (int i = 1; i <= n; i++) {
                bits[i] = bits[i & (i - 1)] + 1;
            }
            return bits;
        }

    }
}
