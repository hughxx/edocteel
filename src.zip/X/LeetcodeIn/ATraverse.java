package X.LeetcodeIn;

import java.util.HashMap;
import java.util.Stack;

/**
 * @author : hu
 **/
public class ATraverse {
    public boolean isValid(String s) {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '[' || c  == '{') {
                stack.push(c);
            } else {
                if (!stack.isEmpty() && stack.pop() == leftOf(c)) {
                    continue;
                } else {
                    return false;
                }
            }
        }
        return stack.isEmpty();
    }

    private char leftOf(char c) {
        if (c == ']') return '[';
        if (c == ')') return '(';
        else return '{';
    }

    public int[] twoSum(int[] nums, int target) {
        HashMap<Integer, Integer> map = new HashMap<>();

        for(int i = 0; i < nums.length; i++) {
            if(map.containsKey(target - nums[i])) {
                return new int[] {i, map.get(target - nums[i])};
            }
            map.put(nums[i], i);
        }

        return new int[]{};
    }
}
