package X.LeetcodeIn;

/**
 * @author : hu
 **/
public class ALoopN {

    public int hammingDistance(int x, int y) {
        int bit = x ^ y, res = 0;
        while(bit != 0) {
            res++;
            bit -= (bit & -bit);
            //or res++ here
        }
        return res;
    }

    public int hammingDistance2(int x, int y) {
        int s = x ^ y, ret = 0;
        while (s != 0) {
            //or ret++ here
            s &= s - 1;
            ret++;
        }
        return ret;
    }

    class Solution556 {
        //循环看x是什么条件。比如第一个循环停止，就意味着：x<10 或者 x的最后一位大于前一位了；又比如第二个循环停止，意味着：x的最后一位大于target
        public int nextGreaterElement(int n) {
            int x = n, cnt = 1;
            for (; x >= 10 && x / 10 % 10 >= x % 10; x /= 10) {
                ++cnt;
            }
            x /= 10;
            if (x == 0) {
                return -1;
            }

            int targetDigit = x % 10;
            int x2 = n, cnt2 = 0;
            for (; x2 % 10 <= targetDigit; x2 /= 10) {
                ++cnt2;
            }
            x += x2 % 10 - targetDigit; // 把 x2 % 10 换到 targetDigit 上

            for (int i = 0; i < cnt; ++i, n /= 10) { // 反转 n 末尾的 cnt 个数字拼到 x 后
                int d = i != cnt2 ? n % 10 : targetDigit;
                if (x > Integer.MAX_VALUE / 10 || x == Integer.MAX_VALUE / 10 && d > 7) {
                    return -1;
                }
                x = x * 10 + d;
            }
            return x;
        }
    }

    class Solution9 {
        public boolean isPalindrome(int x) {
            // 省略了部分代码， 只关注下面Loop即可

            int rev = 0;
            while (x > rev) {
                rev = rev * 10 + x % 10;
                x = x / 10;
            }

            return x == rev || rev / 10 == x;
        }
    }
}
