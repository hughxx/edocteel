package X.LeetcodeIn;

/**
 * @author : hu
 **/
public class ALoopY {
    class Solution4 {
        private double findKth(int[] nums1, int[] nums2, int k) {
            int m = nums1.length, n = nums2.length;
            int start1 = 0, start2 = 0;

            while (k > 0) {
                if (start1 == m) {
                    return nums2[start2 + k - 1];
                }
                if (start2 == n) {
                    return nums1[start1 + k - 1];
                }
                if (k == 1) {
                    return Math.min(nums1[start1], nums2[start2]);
                }

                int half = k / 2;
                int end1 = Math.min(start1 + half, m) - 1;
                int end2 = Math.min(start2 + half, n) - 1;
                int pivot1 = nums1[end1];
                int pivot2 = nums2[end2];
                if (pivot1 <= pivot2) {
                    k -= (end1 - start1 + 1);
                    start1 = end1 + 1;
                } else {
                    k -= (end2 - start2 + 1);
                    start2 = end2 + 1;
                }
            }
            return -1;
        }
    }

    class SolutionQ {
        private int partition(int[] nums, int lo, int hi) {
            int pivot = nums[lo];
            int left = lo, right = hi;
            while (left <= right) {
                if (nums[left] > pivot) {
                    swap(nums, left, right);
                    right--;
                } else {
                    left++;
                }
            }
            swap(nums, lo, right);
            return right;
        }

        private void swap(int[] nums, int i, int j){}
    }

    class SolutionM {
        int[] temp;

        void merge(int[] nums, int lo, int mid, int hi) {
            for (int i = lo; i <= hi; i++) {
                temp[i] = nums[i];
            }
            int i = lo, j = mid + 1;
            for (int p = lo; p <= hi; p++) {
                if (i > mid) {
                    nums[p] = temp[j++];
                } else if (j > hi) {
                    nums[p] = temp[i++];
                } else if (temp[i] < temp[j]) {
                    nums[p] = temp[i++];
                } else {
                    nums[p] = temp[j++];
                }
            }
        }
    }

    class SolutionH {
        private void sink(int[] nums, int k, int limit) {
            int temp = nums[k];
            while (2 * k + 1 <= limit) {
                int i = 2 * k + 1;
                if (i + 1 <= limit && nums[i] < nums[i + 1]) {
                    i++;
                }
                if (temp > nums[i]) break;
                nums[k] = nums[i];
                k = i;
            }
            nums[k] = temp;
        }
    }

    class Solution31 {
        public void nextPermutation(int[] nums) {
            int i = nums.length - 1;
            while (i > 0 && nums[i] <= nums[i - 1]) {
                i--;
            }
            if (i > 0) {
                int j = nums.length - 1;
                while (j > 0 && nums[j] <= nums[i - 1]) {
                    j--;
                }
                swap(nums, i - 1, j);
            }
            reverse(nums, i);
        }

        void swap(int[] nums, int i, int j) {}
        void reverse(int[] nums, int i) {}
    }
}
