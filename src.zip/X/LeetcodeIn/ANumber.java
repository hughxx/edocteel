package X.LeetcodeIn;

/**
 * @author : hu
 **/
public class ANumber {
    //556
    class Solution556 {
        public int nextGreaterElement(int n) {
            int x = n, cnt = 1;
            for (; x >= 10 && x / 10 % 10 >= x % 10; x /= 10) {
                ++cnt;
            }
            x /= 10;
            if (x == 0) {
                return -1;
            }

            int targetDigit = x % 10;
            int x2 = n, cnt2 = 0;
            for (; x2 % 10 <= targetDigit; x2 /= 10) {
                ++cnt2;
            }
            x += x2 % 10 - targetDigit; // 把 x2 % 10 换到 targetDigit 上

            for (int i = 0; i < cnt; ++i, n /= 10) { // 反转 n 末尾的 cnt 个数字拼到 x 后
                int d = i != cnt2 ? n % 10 : targetDigit;
                if (x > Integer.MAX_VALUE / 10 || x == Integer.MAX_VALUE / 10 && d > 7) {
                    return -1;
                }
                x = x * 10 + d;
            }
            return x;
        }
    }

    //8 stoi
    class Solution {
        public int myAtoi(String s) {
            int i = 0;
            while (i < s.length() && s.charAt(i) == ' ') {
                i++;
            }
            char sign = '+';
            if (i < s.length() && s.charAt(i) == '+') {
                i++;
            } else if (i < s.length() && s.charAt(i) == '-') {
                sign = '-';
                i++;
            }

            int res = 0;
            while (i < s.length() && Character.isDigit(s.charAt(i))) {
                int x = '0' - s.charAt(i);
                if (res < Integer.MIN_VALUE / 10
                        || (res == Integer.MIN_VALUE / 10 && x < Integer.MIN_VALUE % 10)) {
                    return sign == '+' ? Integer.MAX_VALUE : Integer.MIN_VALUE;
                }
                res = res * 10 + x;
                i++;
            }
            return sign == '-' ? res : res == Integer.MIN_VALUE ? Integer.MAX_VALUE : -res;
        }
    }

    //两数相加
    //字符串相乘
}
