package X.LeetcodeIn;

/**
 * @author : hu
 **/
public class ATmp {
    public int climbStairs_tmp0(int n) {
        int r = -1, p = 0, q = 1;
        for(int i = 1; i <= n; i++) {
            r = p;
            p = q;
            q = r + q;
            //or q = r + p
        }
        return q;

    }

    public int climbStairs_tmp1(int n) {
        int p = 0, r = -1, q = 1;
        for(int i = 1; i <= n; i++) {
            r = q;
            q = p + q;
            //or q = p + r
            p = r;
        }
        return q;


    }

    public int climbStairs_tmp2(int n) {
        int p = 0, q = 1, r = -1;
        for(int i = 1; i <= n; i++) {
            r = p + q;
            p = q;
            q = r;
        }
        return q;
        //or return r
    }
}
