package Leetcode3.hard;

/**
 * @author : hu
 **/
public class Solution2296 {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder();
        sb.append("ab5cd");
        ;
        System.out.println(sb.substring(4, 5));
    }

    class TextEditor {

        StringBuilder sb = new StringBuilder();
        int pos;

        public TextEditor() {
            sb.append("|");
            pos = 0;
        }

        public void addText(String text) {
            sb.insert(pos, text);
            pos += text.length();
        }

        public int deleteText(int k) {
            int len = Math.min(pos, k);
            sb.delete(pos - len, pos);
            pos -= len;
            return len;
        }

        public String cursorLeft(int k) {
            int newPos = Math.max(0, pos - k);
            sb.insert(newPos, "|");
            sb.deleteCharAt(pos + 1);
            pos = newPos;

            return left10();
        }

        public String cursorRight(int k) {
            if (pos == sb.length() - 1) return left10();

            sb.append("#");
            int newPos = Math.min(sb.length() - 1, pos + k + 1);
            sb.insert(newPos, "|");
            sb.deleteCharAt(pos);
            pos = newPos - 1;
            sb.deleteCharAt(sb.length() - 1);

            return left10();
        }

        private String left10(){
            int len = Math.min(pos, 10);
            return sb.substring(pos - len, pos);
        }
    }
}
