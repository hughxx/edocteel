package Leetcode3.easy;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @author : hu
 * @since : 2023/7/26
 **/
public class Solution101 {
    public boolean isSymmetric(TreeNode root) {
        if (root == null) return true;

        Queue<TreeNode> q = new LinkedList<>();
        q.offer(root.left);
        q.offer(root.right);
        while (!q.isEmpty()) {
            TreeNode u = q.poll();
            TreeNode v = q.poll();
            if (u == null && v == null) continue;
            if (u == null || v == null || u.val != v.val) return false;
            q.offer(u.left);
            q.offer(v.right);
            q.offer(u.right);
            q.offer(v.left);
        }
        return true;
    }
}
