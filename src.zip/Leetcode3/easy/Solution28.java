package Leetcode3.easy;

/**
 * @author : hu
 **/
public class Solution28 {
    public int strStr(String str, String sub) {
        int n = str.length(), m = sub.length();

        int[] next = new int[m];
        next[0] = -1;
        int j = -1;
        for (int i = 1; i < m; i++) {
            while (j >= 0 && str.charAt(i) != sub.charAt(j + 1)) {
                j = next[j];
            }
            if (sub.charAt(i) == sub.charAt(j + 1)) {
                j++;
            }
            next[i] = j;
        }

        j = -1;
        for (int i = 0; i < n; i++) {
            while (j >= 0 && str.charAt(i) != sub.charAt(j + 1)) {
                j = next[j];
            }
            if (str.charAt(i) == sub.charAt(j + 1)) {
                j++;
            }
            if (j == m - 1) {
                return i - m + 1;
            }
        }

        return -1;
    }
}
