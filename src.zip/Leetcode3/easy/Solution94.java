package Leetcode3.easy;

import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

/**
 * @author : hu
 * @since : 2023/7/26
 **/
public class Solution94 {
//    List<Integer> res = new LinkedList<>();
//
//    public List<Integer> inorderTraversal(TreeNode root) {
//        traverse(root);
//        return res;
//    }
//
//    public void traverse(TreeNode root) {
//        if (root == null) return;
//
//        traverse(root.left);
//        res.add(root.val);
//        traverse(root.right);
//    }

    public List<Integer> inorderTraversal(TreeNode root) {
        List<Integer> res = new LinkedList<>();

        Stack<TreeNode> stack = new Stack<>();
        TreeNode p = root;
        while (!stack.isEmpty() || p != null) {
            if (p != null) {
                stack.push(p);
                p = p.left;
            } else {
                p = stack.pop();
                res.add(p.val);
                p = p.right;
            }
        }
        return res;
    }


}
