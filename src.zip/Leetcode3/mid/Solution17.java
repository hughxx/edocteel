package Leetcode3.mid;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @author : hu
 * @since : 2023/7/31
 **/
public class Solution17 {
    List<String> res = new LinkedList<>();
    StringBuilder track = new StringBuilder();
    Map<Character, String> phoneMap = new HashMap<Character, String>() {{
        put('2', "abc");
        put('3', "def");
        put('4', "ghi");
        put('5', "jkl");
        put('6', "mno");
        put('7', "pqrs");
        put('8', "tuv");
        put('9', "wxyz");
    }};

    public List<String> letterCombinations(String digits) {
        if(digits.length() == 0) return res;
        backtrack(digits, 0);
        return res;
    }

    void backtrack(String digits, int i) {
        if (i == digits.length()) {
            res.add(track.toString());
            return;
        }
        String s = phoneMap.get(digits.charAt(i));
        for (int j = 0; j < s.length(); j++) {
            char d = s.charAt(j);
            track.append(d);
            backtrack(digits, i + 1);
            track.deleteCharAt(track.length() - 1);
        }
    }

    public static void main(String[] args) {
        int[] arr = new int[] {1,2,3};
        int i = arr.length - 1;
        for (; i >= 0; i--) {

        }
        System.out.println(i);
    }

}
