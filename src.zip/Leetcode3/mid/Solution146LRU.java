package Leetcode3.mid;

import java.util.HashMap;

/**
 * @author : hu
 * @since : 2023/8/3
 **/
public class Solution146LRU {
    class DNode {
        public int key, val;
        public DNode next, prev;
        public DNode(int k, int v) {
            this.key = k;
            this.val = v;
        }
    }

    class LRUCache {

        private HashMap<Integer, DNode> map;
        private DLinkedList list;
        private int cap;
        private int size;

        public LRUCache(int capacity) {
            cap = capacity;
            map = new HashMap<>();
            list = new DLinkedList();
        }

        public int get(int key) {
            if (!map.containsKey(key)) return -1;
            DNode node = map.get(key);
            list.moveLast(node);
            return node.val;
        }

        public void put(int key, int value) {
            DNode node = map.get(key);
            if (node == null) {
                DNode newNode = new DNode(key, value);
                list.addLast(newNode);
                map.put(key, newNode);
                size++;
                if (size > cap) {
                    DNode oldNode = list.removeFirst();
                    map.remove(oldNode.key);
                    size--;
                }
            } else {
                node.val = value;
                list.moveLast(node);
            }
        }
    }

    class DLinkedList {
        // 头尾虚节点
        private DNode head, tail;

        public DLinkedList() {
            // 初始化双向链表的数据
            head = new DNode(0, 0);
            tail = new DNode(0, 0);
            head.next = tail;
            tail.prev = head;
        }

        // 在链表尾部添加节点 x，时间 O(1)
        public void addLast(DNode x) {
            x.prev = tail.prev;
            x.next = tail;
            tail.prev.next = x;
            tail.prev = x;
        }

        // 删除链表中的 x 节点（x 一定存在）
        // 由于是双链表且给的是目标 Node 节点，时间 O(1)
        public void remove(DNode x) {
            x.prev.next = x.next;
            x.next.prev = x.prev;
        }

        // 删除链表中第一个节点，并返回该节点，时间 O(1)
        public DNode removeFirst() {
            if (head.next == tail)
                return null;
            DNode first = head.next;
            remove(first);
            return first;
        }

        public void moveLast(DNode x) {
            remove(x);
            addLast(x);
        }
    }

}
