package Leetcode3.mid;

import java.util.*;

/**
 * @author : hu
 * @since : 2023/8/3
 **/
public class Solution347 {
    class Solution {
        public int[] topKFrequent(int[] nums, int k) {
            HashMap<Integer, Integer> map = new HashMap<>();
            for(int num : nums) {
                map.put(num, map.getOrDefault(num, 0) + 1);
            }
            int[][] arr = new int[map.size()][];
            int i = 0;
            for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
                arr[i++] = new int[]{entry.getKey(), entry.getValue()};
            }
            findKthLargest(arr, k);
            int[] res = new int[k];
            for (int j = 0; j < k; j++) {
                res[j] = arr[j][0];
            }
            return res;
        }

        public void findKthLargest(int[][] nums, int k) {
            shuffle(nums);
            int left = 0, right = nums.length - 1;
            k = nums.length - k;
            while (left <= right) {
                int p = partition(nums, left, right);
                if (p < k) {
                    left = p + 1;
                } else if (p > k) {
                    right = p - 1;
                } else {
                    return;
                }
            }
        }

        private int partition(int[][] nums, int lo, int hi) {
            int[] pivot = nums[lo];
            int left = lo, right = hi;
            while (left <= right) {
                if (nums[left][1] > pivot[1]) {
                    swap(nums, left, right);
                    right--;
                    left--;
                }
                left++;
            }
            swap(nums, lo, right);
            return right;
        }

        private void shuffle(int[][] nums) {
            int n = nums.length;
            Random random = new Random();
            for (int i = 0; i < n; i++) {
                int r = random.nextInt(n - i) + i;
                swap(nums, r, i);
            }
        }

        private void swap(int[][] nums, int i, int j) {
            int[] temp = nums[i];
            nums[i] = nums[j];
            nums[j] = temp;
        }
    }
}
