package Leetcode3.mid;

import java.util.Arrays;

/**
 * @author : hu
 * @since : 2023/8/10
 **/
public class SolutionCoin {
    // 背包版本
    class Solution322 {
        public int coinChange(int[] coins, int amount) {
            int n = coins.length, m = amount;
            int[][] dp = new int[n + 1][m + 1];
            Arrays.fill(dp[0], amount + 1);
            dp[0][0] = 0;

            for(int i = 1; i <= n; i++) {
                for(int j = 1; j <= m; j++) {
                    if(j - coins[i - 1] < 0) {
                        dp[i][j] = dp[i - 1][j];
                    }
                    else {
                        dp[i][j] = Math.min(dp[i][j - coins[i - 1]] + 1, dp[i - 1][j]);
                    }
                }
            }

            return dp[n][amount] == amount + 1 ? -1 : dp[n][amount];
        }
    }
    // naive版本
    public int coinChange(int[] coins, int amount) {
        int[] dp = new int[amount + 1];
        Arrays.fill(dp, amount + 1);
        dp[0] = 0;
        for(int coin: coins) {
            for(int i = 1; i <= amount; i++) {

                if(i - coin < 0) continue;
                dp[i] = Math.min(dp[i - coin] + 1, dp[i]);

            }
        }
        return dp[amount] == amount + 1 ? -1 : dp[amount];
    }

    // 背包版本
    class Solution518 {
        int change(int amount, int[] coins) {
            int n = coins.length;
            int[][] dp = new int[n + 1][amount + 1];
            // base case
            for (int i = 0; i <= n; i++)
                dp[i][0] = 1;

            for (int j = 1; j <= amount; j++) {
                for (int i = 1; i <= n; i++) {
                    if (j - coins[i-1] >= 0)
                        dp[i][j] = dp[i - 1][j]
                                + dp[i][j - coins[i-1]];
                    else
                        dp[i][j] = dp[i - 1][j];
                }
            }

            return dp[n][amount];
        }
    }

    // naive版本
    public int change(int amount, int[] coins) {
        int[] dp = new int[amount + 1];
        dp[0] = 1;
        for(int coin: coins) {
            for(int i = 1; i <= amount; i++) {
                if(i - coin < 0) continue;
                dp[i] += dp[i - coin];
            }
        }

        return dp[amount];
    }
}
