package Leetcode3.mid;

import java.util.*;

/**
 * @author : hu
 * @since : 2023/8/2
 **/
public class Solution139 {
    HashSet<String> wordDict;
    int[] memo;

    public boolean wordBreak(String s, List<String> wordDict) {
        this.wordDict = new HashSet<>(wordDict);
        memo = new int[s.length()];
        Arrays.fill(memo, -1);
        return backtrack(s, 0);
    }

    boolean backtrack(String s, int i) {
        if (i == s.length()) return true;
        if (memo[i] != -1) return memo[i] == 1;
        for (int len = 1; i + len <= s.length(); len++) {
            String prefix = s.substring(i, i + len);
            if (wordDict.contains(prefix)) {
                boolean sub = backtrack(s, i + len);
                if (sub) {
                    memo[i] = 1;
                    return true;
                }
            }
        }

        memo[i] = 0;
        return false;
    }



}
