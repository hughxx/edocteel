package Leetcode3.mid;

import java.util.HashMap;

/**
 * @author : hu
 * @since : 2023/8/2
 **/

// 说实话这篇文章写的有点烂，代码不够精炼，分析也不够深入，相信很多人看完很迷。说几个点吧。
// 首先，算法本身都没优化完，记忆化不彻底，而且对问题的抽象存在冗余（第二种代码不需要k，而且问题本身也不需要桶的概念）。
// 其次，第二种解法，因为记忆化不彻底，所以start剪枝是瓶颈。位图都是小优化了。当然彻底记忆化优化后start剪枝可有可无。
// 第三，时间复杂度没考虑每个状态本身复杂度，第一个要×k，第二个要×n。
// 最后，第一种解法理论上也可以记忆化。二种解法都进行彻底的记忆化后复杂度应该为：第一种解法k·2^n，第二种解法n·2^n。?[=-]
// 状态，尝试和分枝，剪枝和动规。
public class Solution698B {
    public boolean canPartitionKSubsets(int[] nums, int k) {
        // 排除一些基本情况
        if (k > nums.length) return false;
        int sum = 0;
        for (int v : nums) sum += v;
        if (sum % k != 0) return false;

        int used = 0; // 使用位图技巧
        int target = sum / k;
        // k 号桶初始什么都没装，从 nums[0] 开始做选择
        return backtrack(nums, target, 0, 0, used);
    }

    HashMap<Integer, Boolean> memo = new HashMap<>();

//        boolean backtrack(
//                int[] nums, int target, int index, int[] bucket)

    boolean backtrack(int[] nums, int target, int sum, int start, int used) {
        // base case
        if (used == (1 << nums.length) - 1) {
            // 所有桶都被装满了，而且 nums 一定全部用完了
            return true;
        }
        if (sum == target) {
            // 装满了当前桶，递归穷举下一个桶的选择
            // 让下一个桶从 nums[0] 开始选数字
            boolean res = backtrack(nums, target, 0, 0, used);
            // 缓存结果
            memo.put(used, res);
            return res;
        }

        if (memo.containsKey(used)) {
            // 避免冗余计算
            return memo.get(used);
        }

        for (int i = start; i < nums.length; i++) {
            // 剪枝
            if (((used >> i) & 1) == 1) { // 判断第 i 位是否是 1
                // nums[i] 已经被装入别的桶中
                continue;
            }
            if (nums[i] + sum > target) {
                continue;
            }
            // 做选择
            used |= 1 << i; // 将第 i 位置为 1
            sum += nums[i];
            // 递归穷举下一个数字是否装入当前桶
            if (backtrack(nums, target, sum, i + 1, used)) {
                return true;
            }
            // 撤销选择
            used ^= 1 << i; // 使用异或运算将第 i 位恢复 0
            sum -= nums[i];
        }

        return false;
    }
}
