package Leetcode1;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/15
 **/
public class Solution29 {
    public int divide(int dividend, int divisor) {
        long dend = dividend;
        long isor = divisor;

        // 一般情况，使用类二分查找
        // 将所有的正数取相反数，这样就只需要考虑一种情况
        int sign = 1;
        if (dend < 0) {
            dend = -dend;
            sign *= -1;
        }
        if (isor < 0) {
            isor = -isor;
            sign *= -1;
        }

        List<Long> candidates = new ArrayList<Long>();
        candidates.add(isor);
        int index = 0;
        // 注意溢出
        while (candidates.get(index) <= dend - candidates.get(index)) {
            candidates.add(candidates.get(index) + candidates.get(index));
            ++index;
        }
        long ans = 0;
        for (int i = candidates.size() - 1; i >= 0; --i) {
            if (candidates.get(i) <= dend) {
                ans += 1L << i;
                dend -= candidates.get(i);
            }
        }
        ans *= sign;
        if (ans > Integer.MAX_VALUE) return Integer.MAX_VALUE;
        if (ans < Integer.MIN_VALUE) return Integer.MIN_VALUE;
        return (int) ans;
    }

    public static void main(String[] args) {

        System.out.println(Integer.MIN_VALUE);
       // new Solution29().divide(-2147483648, -3);
    }
}
