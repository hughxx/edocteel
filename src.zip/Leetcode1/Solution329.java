package Leetcode1;

import javafx.util.Pair;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @author : hu
 * @since : 2023/3/17
 **/
public class Solution329 {
    int res;

    public int longestIncreasingPath(int[][] matrix) {
        int m = matrix.length, n = matrix[0].length;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                dj(matrix, i, j);
            }
        }
        return res;
    }

    private void dj(int[][] matrix, int i, int j) {
        int m = matrix.length, n = matrix[0].length;
        int[][] memo = new int[m][n];

        Queue<Pair<Integer, Integer>> q = new LinkedList<>();
        q.offer(new Pair<>(i * n + j, 1));
        res = 1;

        while (!q.isEmpty()) {
            Pair<Integer, Integer> p = q.poll();
            int node = p.getKey();
            int dist = p.getValue();
            int[][] dirs = new int[][]{{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
            for (int[] dir : dirs) {
                int x = node / n + dir[0];
                int y = node % n + dir[1];
                if (x < 0 || x >= m || y < 0 || y >= n) continue;
                if (matrix[node / n][node % n] >= matrix[x][y]) continue;
                if (dist + 1 > memo[x][y]) {
                    q.offer(new Pair<>(x * n + y, dist + 1));
                    memo[x][y] = dist + 1;
                    res = Math.max(dist + 1, res);
                }
            }
        }
    }

    public static void main(String[] args) {
//        new Solution329().longestIncreasingPath(new int[][]{{1,2}});
        new Solution329().longestIncreasingPath(new int[][]{{9,9,4},{6,6,8},{2,1,1}});

    }
}
