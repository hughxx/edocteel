package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/17
 **/
public class Solution572 {
    public boolean isSubtree(TreeNode root, TreeNode subRoot) {
        return isSubtree(root, subRoot, subRoot);
    }

    private boolean isSubtree(TreeNode root, TreeNode subRoot, TreeNode subRootCopy) {
        if (root == null && subRoot == null) return true;
        if (root == null || subRoot == null) return false;

        if (root.val == subRoot.val) {
            boolean left = isSubtree(root.left, subRoot.left, subRootCopy);
            boolean right = isSubtree(root.right, subRoot.right, subRootCopy);
            if (left && right) return true;
        }
        if (subRoot == subRootCopy) {
            boolean left = isSubtree(root.left, subRoot, subRootCopy);
            boolean right = isSubtree(root.right, subRoot, subRootCopy);
            if (left || right) return true;
        }
        return false;
    }

}
