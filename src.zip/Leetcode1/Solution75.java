package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/17
 **/
public class Solution75 {
    public void sortColors(int[] nums) {
        int n = nums.length;
        int i = 0, j = 0;
        while (j < n) {
            if (nums[j] == 0) {
                swap(nums, i, j);
                i++;
            }
            j++;
        }
        i = n - 1;
        j = n - 1;
        while (i >= 0) {
            if (nums[j] == 2) {
                swap(nums, i, j);
                j--;
            }
            i--;
        }
    }

    private void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }

    public static void main(String[] args) {
        new Solution75().sortColors(new int[] {2,0,2,1,1,0});
    }
}
