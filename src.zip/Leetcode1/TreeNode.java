package Leetcode1;

/**
 * @author : hu
 * @since : 2023/2/24
 **/
public class TreeNode {
    public int val;
    public TreeNode left;
    TreeNode right;
    public TreeNode(int x) { val = x; }
}
