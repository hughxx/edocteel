package Leetcode1;

import java.util.Random;

/**
 * @author : hu
 * @since : 2023/3/9
 **/
public class Solution912QX {
    public int[] sortArray(int[] nums) {
        shuffle(nums);
        sort(nums, 0, nums.length - 1);
        return nums;
    }

    private void sort(int[] nums, int i, int j) {
        if (i >= j) return;
        int p = partition(nums, i, j);
        sort(nums, i, p - 1);
        sort(nums, p + 1, j);
    }

    private int partition(int[] nums, int i, int j) {
        int a = i;
        int p = nums[i];
        while (i <= j) {
            if (nums[i] > p) {
                swap(nums, i, j);
                j--;
                i--;
            }
            i++;
        }
        swap(nums, a, j);
        return j;
    }

    private void shuffle(int[] nums) {
        int n = nums.length;
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            int p = random.nextInt(n - i) + i;
            swap(nums, i, p);
        }
    }

    private void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
}
