package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/4
 **/
public class Solution124 {
    private int res = Integer.MIN_VALUE;

    public int maxPathSum(TreeNode root) {
        straightSum(root);
        return res;
    }

    private int straightSum(TreeNode root) {
        if (root == null) return 0;
        int left = Math.max(straightSum(root.left), 0);
        int right = Math.max(straightSum(root.right),0);
        res = Math.max(left + right + root.val, res);
        return Math.max(left, right) + root.val;
    }
}
