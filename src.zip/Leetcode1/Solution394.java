package Leetcode1;

import java.util.LinkedList;

/**
 * @author : hu
 * @since : 2023/3/5
 **/
public class Solution394 {
    public String decodeString(String s) {
        LinkedList<Character> list = new LinkedList<>();
        for (int i = 0; i < s.length(); i++) {
            list.add(s.charAt(i));
        }
        return helper(list);
    }

    private String helper(LinkedList<Character> list) {
        StringBuilder sb = new StringBuilder();
        int num = 0;
        while (!list.isEmpty()) {
            char c = list.removeFirst();
            if (Character.isDigit(c)) {
                num = 10 * num + (c - '0');
            }
            if (c == '[') {
                String s = helper(list);
                for (int i = 0; i < num; i++) {
                    sb.append(s);
                }
                num = 0;
            }
            if (Character.isLetter(c)) {
                sb.append(c);
            }
            if (c == ']') {
                break;
            }
        }
        return sb.toString();
    }
}
