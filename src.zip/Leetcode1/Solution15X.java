package Leetcode1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/9
 **/
public class Solution15X {
    public List<List<Integer>> threeSum(int[] nums) {
        Arrays.sort(nums);
        List<List<Integer>> res = new ArrayList<>();
        int n = nums.length;
        for (int i = 0; i < nums.length - 2; i++) {
            if (i - 1 >= 0 && nums[i] == nums[i - 1]) {
                continue;
            }
            if (nums[i] + nums[i+1] + nums[i + 2] > 0) {
                break;
            }
            if (nums[i] + nums[n -2] + nums[n - 1] < 0) {
                continue;
            }
            int left = i + 1, right = n - 1;
            int target = - nums[i];
            while (left < right) {
                int sum = nums[left] + nums[right];
                int leftV = nums[left];
                int rightV = nums[right];
                if (sum == target) {
                    res.add(Arrays.asList(nums[i], nums[left], nums[right]));
                    while (left < right && nums[left] == leftV) {
                        left++;
                    }
                    while (left < right && nums[right] == rightV) {
                        right--;
                    }
                } else if (sum < target) {
                    left++;
                } else {
                    right--;
                }
            }
        }
        return res;
    }
}
