package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/9
 **/
public class Solution912HX {
    public int[] sortArray(int[] nums) {
        int n = nums.length;
        for (int i = n / 2; i >= 0; i--) {
            sink(nums, i, n - 1);
        }
        for (int i = n - 1; i > 0; i--) {
            int temp = nums[0];
            nums[0] = nums[i];
            nums[i] = temp;
            sink(nums, 0, i - 1);
        }
        return nums;
    }

    private void sink(int[] nums, int i, int limit) {
        int temp = nums[i];
        while (2 * i + 1 <= limit) {
            int j = 2 * i + 1;
            if (j + 1 <= limit && nums[j + 1] > nums[j]) j++;
            if (temp > nums[j]) break;
            nums[i] = nums[j];
            i = j;
        }
        nums[i] = temp;
    }
}
