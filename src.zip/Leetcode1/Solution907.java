package Leetcode1;

/**
 * @author : hu
 * @since : 2023/4/9
 **/
public class Solution907 {
    public int subarraySum(int[] nums, int k) {

        int left = 0, right = 0;
        int sum = 0;
        int res = 0;
        while (right < nums.length) {
            int c = nums[right];
            right++;
            sum += c;
            while (sum > k && left < right - 1) {
                int d = nums[left];
                sum -= d;
                left++;
            }
            if (sum == k) res++;
        }
        return res;
    }

    public static void main(String[] args) {
        System.out.println(new Solution907().subarraySum(new int[]{1}, 0));
    }
}
