package Leetcode1;

import java.util.HashMap;
import java.util.Map;

/**
 * @author : hu
 * @since : 2023/2/24
 **/
public class Solution560 {

    public int subarraySum(int[] nums, int k) {
        int res = 0, pre = 0;
        Map<Integer, Integer> memo = new HashMap<>();
        memo.put(0, 1);
        for (int i = 0; i < nums.length; i++) {
            pre = pre + nums[i];
            if (memo.getOrDefault(pre - k, 0) > 0) {
                res += memo.get(pre - k);
            }
            memo.put(pre, memo.getOrDefault(pre, 0) + 1);
        }
        return res;
    }
}
