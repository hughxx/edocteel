package Leetcode1;

import javafx.util.Pair;

import java.util.LinkedList;

/**
 * @author : hu
 * @since : 2023/3/3
 **/
public class Solution662 {
    public int widthOfBinaryTree(TreeNode root) {
        if (root == null) return 0;
        LinkedList<Pair<TreeNode, Integer>> q = new LinkedList<>();
        q.addLast(new Pair<>(root, 1));

        int res = 1;
        while (!q.isEmpty()) {
            int sz = q.size();
            int left = q.getFirst().getValue();
            int right = q.getLast().getValue();
            res = Math.max(res, right - left + 1);
            for (int i = 0; i < sz; i++) {
                TreeNode cur = q.getFirst().getKey();
                Integer index = q.removeFirst().getValue();
                if (cur.left != null) q.addLast(new Pair<>(cur.left, 2 * index));
                if (cur.right != null) q.addLast(new Pair<>(cur.right, 2 * index + 1));
            }
        }
        return res;
    }

    public static void main(String[] args) {
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(3);
        root.right = new TreeNode(2);
        root.left.left = new TreeNode(5);
        root.left.right = new TreeNode(3);
        root.left.right = new TreeNode(9);
        new Solution662().widthOfBinaryTree(root);
    }
}
