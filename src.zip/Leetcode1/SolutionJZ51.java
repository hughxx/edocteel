package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/16
 **/
public class SolutionJZ51 {
    int[] temp;
    int res;

    public int reversePairs(int[] nums) {
        int n = nums.length;
        temp = new int[n];
        sort(nums, 0, n - 1);
        return res;
    }

    private void sort(int[] nums, int left, int right) {
        if (left == right) return;
        int mid = left + (right - left) / 2;
        sort(nums, left, mid);
        sort(nums, mid + 1, right);
        merge(nums, left, mid, right);
    }

    private void merge(int[] nums, int left, int mid, int right) {
        for (int i = left; i <= right; i++) {
            temp[i] = nums[i];
        }
        int i = left, j = mid + 1;
        for (int p = left; p <= right; p++) {
            if (i > mid) {
                nums[p] = temp[j++];
            } else if (j > right) {
                nums[p] = temp[i++];
            } else if (temp[i] <= temp[j]) {
                nums[p] = temp[i++];
            } else {
                nums[p] = temp[j++];
                res += mid - i + 1;
            }
        }

    }
}
