package Leetcode1;

import java.util.HashMap;

/**
 * @author : hu
 * @since : 2023/3/3
 **/
class Node {
    int val;
    Node next;
    Node random;

    public Node(int val) {
        this.val = val;
        this.next = null;
        this.random = null;
    }
}

public class Solution138 {
    public Node copyRandomList(Node head) {
        if (head == null) return null;
        HashMap<Node, Node> cache = new HashMap<>();
        Node p1 = head;
        Node h = new Node(head.val), p2 = h;
        cache.put(head, h);
        while (p1 != null) {
            //copy next
            if (cache.containsKey(p1.next)) {
                p2.next = cache.get(p1.next);
            } else {
                if (p1.next != null) {
                    p2.next = new Node(p1.next.val);
                    cache.put(p1.next, p2.next);
                }
            }
            //copy random
            if (cache.containsKey(p1.random)) {
                p2.random = cache.get(p1.random);
            } else {
                if (p1.random != null) {
                    p2.random = new Node(p1.random.val);
                    cache.put(p1.random, p2.random);
                }
            }
            //p
            p1 = p1.next;
            p2 = p2.next;
        }
        return h;
    }
}
