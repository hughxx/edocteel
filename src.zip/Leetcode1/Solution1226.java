package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/15
 **/
public class Solution1226 {
    class DiningPhilosophers {

        public DiningPhilosophers() {

        }

        // call the run() method of any runnable to execute its code
        public void wantsToEat(int philosopher,
                               Runnable pickLeftFork,
                               Runnable pickRightFork,
                               Runnable eat,
                               Runnable putLeftFork,
                               Runnable putRightFork) throws InterruptedException {
            if (philosopher % 2 == 0) {
                pickLeftFork.run();
                pickRightFork.run();
                eat.run();
                putRightFork.run();
                putLeftFork.run();
            } else {
                pickRightFork.run();
                pickLeftFork.run();
                eat.run();
                putLeftFork.run();
                putRightFork.run();
            }
        }
    }
}
