package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/28
 **/
public class SolutionJZ03 {
    public int findRepeatNumber(int[] nums) {
        int res = 0;
        for (int i = 0; i < nums.length; i++) {
            if (nums[nums[i]] == 0) res = i;
            if (nums[Math.abs(nums[i])] < 0) return Math.abs(nums[i]);
            nums[Math.abs(nums[i])] *= -1;
        }
        return res;
    }
}
