package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/17
 **/
public class Solution714 {

}
