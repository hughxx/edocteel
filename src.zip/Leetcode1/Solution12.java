package Leetcode1;

/**
 * @author : hu
 * @since : 2023/4/2
 **/
public class Solution12 {
    char[][] romans = new char[][]{{'I', 'V'}, {'X', 'L'}, {'C', 'D'}, {'M'}};
    StringBuilder sb = new StringBuilder();

    public String intToRoman(int num) {

        int level = 0;
        while (num != 0) {
            invert(level, num % 10);
            num = num / 10;
            level++;
        }
        return sb.reverse().toString();
    }

    private void invert(int level, int num) {
        if (num < 4) {
            for (int i = 0; i < num; i++) {
                sb.append(romans[level][0]);
            }
        }
        if (num == 4) {
            sb.append(romans[level][1]);
            sb.append(romans[level][0]);
        }
        if (num > 4 && num < 9) {
            for (int i = 0; i < num - 5; i++) {
                sb.append(romans[level][0]);
            }
            sb.append(romans[level][1]);
        }
        if (num == 9) {
            sb.append(romans[level + 1][0]);
            sb.append(romans[level][0]);
        }
    }
}
