package Leetcode1;

import java.util.Arrays;
import java.util.LinkedList;

/**
 * @author : hu
 * @since : 2023/3/10
 **/
public class Solution56 {
    public int[][] merge(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> {
            return a[0] - b[0];
        });

        LinkedList<int[]> list = new LinkedList<>();
        list.add(intervals[0]);
        for (int i = 1; i < intervals.length; i++) {
            int[] last = list.getLast();
            int[] cur = intervals[i];
            if (cur[0] > last[1]) {
                last[1] = Math.max(cur[1], last[1]);
            } else {
                list.add(cur);
            }
        }

        int n = list.size();
        int[][] res = new int[n][2];
        for (int i = 0; i < n; i++) {
            res[i] = list.get(i);
        }
        return res;
    }
}
