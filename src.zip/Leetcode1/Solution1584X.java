package Leetcode1;

import java.util.*;

/**
 * @author : hu
 * @since : 2023/3/10
 **/
public class Solution1584X {
    public int minCostConnectPoints(int[][] points) {
        int n = points.length;
        List<int[]>[] graph = buildGraph(n, points);
        boolean[] visited = new boolean[n];

        PriorityQueue<int[]> pq = new PriorityQueue<>((a, b) -> a[2] - b[2]);
        visited[0] = true;
        for (int[] edge: graph[0]) {
            pq.offer(edge);
        }

        int res = 0;
        while (!pq.isEmpty()) {
            int[] edge = pq.poll();
            if (visited[edge[1]]) continue;
            visited[edge[1]] = true;
            res += edge[2];
            for (int[] neighbor : graph[edge[1]]) {
                pq.add(neighbor);
            }
        }
        return res;
    }

    List<int[]>[] buildGraph(int n, int[][] points) {
        List<int[]>[] graph = new LinkedList[n];
        for (int i = 0; i < n; i++) {
            graph[i] = new LinkedList<>();
        }
        // 生成所有边及权重
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                int xi = points[i][0], yi = points[i][1];
                int xj = points[j][0], yj = points[j][1];
                int weight = Math.abs(xi - xj) + Math.abs(yi - yj);
                // 用 points 中的索引表示坐标点
                graph[i].add(new int[]{i, j, weight});
                graph[j].add(new int[]{j, i, weight});
            }
        }
        return graph;
    }
}
