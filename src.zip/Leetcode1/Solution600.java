package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/20
 **/
public class Solution600 {
    public int findIntegers(int n) {
        int x = 1, bit = 0;
        while (x <= n) {
            x *= 2;
            bit++;
        }
        return bit;
    }

    public static void main(String[] args) {
        System.out.println(new Solution600().findIntegers(1));
    }
}
