package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/25
 **/
public class Solution875 {
    public int minEatingSpeed(int[] piles, int h) {
        int left = 1, right = 1;
        for (int pile : piles) right = Math.max(right, pile);
        right++;

        while (left < right) {
            int mid = left + (right - left) / 2;
            System.out.println("left:" + left + " right:" + right + " f:" + f(piles, mid));
            if (h < f(piles, mid)) {
                left = mid + 1;
            } else if (h > f(piles, mid)) {
                right = mid;
            } else {
                right = mid;
            }
        }

//        while (left <= right) {
//            int mid = left + (right - left) / 2;
//            System.out.println("left:" + left + " right:" + right + " f:" + f(piles, mid));
//            if (h < f(piles, mid)) {
//                left = mid + 1;
//            } else if (h > f(piles, mid)) {
//                right = mid - 1;
//            } else {
//                right = mid - 1;
//            }
//        }

        return left;

    }

    private int f(int[] piles, int k) {
        int h = 0;
        for (int pile : piles) {
            h += pile / k;
            if (pile % k != 0) h++;
        }
        return h;
    }

    public static void main(String[] args) {

//        new Solution875().minEatingSpeed(new int[]{805306368, 805306368, 805306368}, 1000000000);
        System.out.println(new Solution875().f(new int[]{805306368, 805306368, 805306368}, 1));
    }
}
