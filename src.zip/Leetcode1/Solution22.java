package Leetcode1;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/4
 **/
public class Solution22 {
    List<String> res = new ArrayList<>();

    public List<String> generateParenthesis(int n) {
        backtrack(n, 0, 0, new StringBuilder());
        return res;
    }

    void backtrack(int n, int left, int right, StringBuilder sb) {
        if (left == n && right == n) {
            res.add(sb.toString());
            return;
        }
        if (left != n) {
            sb.append('(');
            backtrack(n, left + 1, right, sb);
            sb.deleteCharAt(sb.length() - 1);
        }
        if (left > right) {
            sb.append(')');
            backtrack(n, left, right + 1, sb);
            sb.deleteCharAt(sb.length() - 1);
        }
    }
}
