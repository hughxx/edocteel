package Leetcode1;

/**
 * @author : hu
 * @since : 2023/4/17
 **/
public class Solution154 {
    public int findMin(int[] nums) {
        int left = 0, right = nums.length - 1;
        while(left <= right) {
            int mid = left + (right - left) / 2;
            if (nums[mid] > nums[right]) {
                left = mid + 1;
            } else if(nums[mid] < nums[right]){
                right = mid;
            } else {
                right--;
            }
        }
        return nums[left];
    }

    public static void main(String[] args) {
        int min = new Solution154().findMin(new int[]{2, 1, 1});
        System.out.println(min);
    }
}
