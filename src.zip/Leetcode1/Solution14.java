package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/3
 **/
public class Solution14 {
    public String longestCommonPrefix(String[] strs) {

        int minStrLen = Integer.MAX_VALUE;
        for (String s : strs) {
            minStrLen = Math.min(minStrLen, s.length());
        }

        int left = 0, right = minStrLen - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (inCommonPrefix(strs, mid)) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return strs[0].substring(0, left);
    }

    private boolean inCommonPrefix(String[] strs, int end) {
        String str0 = strs[0];
        for (int i = 1; i < strs.length; i++) {
            for (int j = 0; j <= end; j++) {
                if (strs[i].charAt(j) != str0.charAt(j)) {
                    return false;
                }
            }
        }
        return true;
    }
}
