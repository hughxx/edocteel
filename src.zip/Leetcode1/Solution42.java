package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/2
 **/
public class Solution42 {
    public int trap(int[] height) {
        int n = height.length;

        int leftMax = height[0];
        int[] left = new int[n];
        for (int i = 1; i < n - 1; i++) {
            left[i] = Math.max(height[i], leftMax);
            leftMax = left[i];
        }

        int rightMax = height[n-1];
        int[] right = new int[n];
        for (int i = n - 2; i > 0; i--) {
            right[i] = Math.max(height[i], rightMax);
            rightMax = right[i];
        }

        int res = 0;
        for (int i = 1; i < n - 1; i++) {
            res += Math.min(left[i], right[i]) - height[i];
        }
        return res;
    }
}
