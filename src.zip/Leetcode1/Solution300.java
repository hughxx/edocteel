package Leetcode1;

import java.util.Arrays;

/**
 * @author : hu
 * @since : 2023/3/1
 **/
public class Solution300 {
    public int lengthOfLIS(int[] nums) {
        int n = nums.length;
        int[] dp = new int[n];
        Arrays.fill(dp, 1);//
        for (int i = 1; i < n; i++) {
            //int res = Integer.MIN_VALUE;//
            for (int j = 0; j < i; j++) {
                if (nums[j] < nums[i]) {
                    dp[i] = Math.max(dp[i], dp[j] + 1);
                }
            }
        }

        //下面一整块
        int res = 0;
        for (int i = 0; i < n; i++) {
            res= Math.max(dp[i], res);
        }
        return res;
    }
}
