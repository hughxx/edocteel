package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/3
 **/
public class Solution142 {
    public int findPeakElement(int[] nums) {
        int n = nums.length;
        int left = 0, right = n - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (compare(nums, mid, mid + 1) > 0 && compare(nums, mid, mid - 1) > 0) {
                return mid;
            }
            if (compare(nums, mid, mid + 1) < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }

    private int[] get(int[] nums, int index) {
        if (index == -1 || index == nums.length) {
            return new int[]{0, 0};
        }
        return new int[]{1, nums[index]};
    }

    private int compare(int[] nums, int index1, int index2) {
        int[] num1 = get(nums, index1);
        int[] num2 = get(nums, index2);
        if (num1[0] != num2[0]) {
            return num1[0] < num2[0] ? -1 : 1;
        }
        if (num1[1] == num2[1]) {
            return 0;
        }
        return num1[1] < num2[1] ? -1 : 1;
    }
}
