package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/28
 **/
public class SolutionJZ33 {
    public boolean verifyPostorder(int[] postorder) {
        return false;
    }

}
