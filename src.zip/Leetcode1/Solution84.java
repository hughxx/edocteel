package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/20
 **/
public class Solution84 {
    public int largestRectangleArea(int[] heights) {
        return -1;
    }

    public static void main(String[] args) {
        System.out.println(1 << 10);
    }
}
