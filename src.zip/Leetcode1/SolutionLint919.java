package Leetcode1;

import java.util.Collections;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/27
 **/
public class SolutionLint919 {
    public int minMeetingRooms(List<Interval> intervals) {
        //这版有问题，是错的，好久之前写的
        // Write your code here
        Collections.sort(intervals, (a, b) -> {
            return a.end - b.end;
        });
        int lastEnd = 0, result = 1;
        for (int i = 1; i < intervals.size(); i++) {
            result++;
            if (intervals.get(i).start >= intervals.get(lastEnd).end) {
                result--;
                lastEnd = i;
            }
        }
        return result;
    }

}
