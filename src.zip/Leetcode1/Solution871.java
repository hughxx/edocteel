package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/30
 **/
public class Solution871 {
    public int minRefuelStops(int target, int startFuel, int[][] stations) {
        return -1;
    }

    public static void main(String[] args) {
//        new Solution871().minRefuelStops(1000, 299, new int[][]{{13, 21}, {26, 115}, {100, 47}, {225, 99}, {299, 141},
//                {444, 198}, {608, 190}, {636, 157}, {647, 255}, {841, 123}});
    }
}
