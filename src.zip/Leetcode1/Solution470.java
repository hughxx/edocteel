package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/5
 **/

class SolBase {
    public int rand7() {
        return -1;
    }
}

public class Solution470 extends SolBase {
//    public int rand10() {
//        int row, col, idx;
//        do {
//            row = rand7();
//            col = rand7();
//            idx = (row - 1) * 7 + col;
//        } while (idx > 40);
//        return (idx - 1) % 10 + 1;
//    }

    public int rand10() {
        int row, col ,idx;

        while (true) {
            row = rand7();
            col = rand7();
            idx = (row - 1) * 7 + col;
            if (idx <= 40) {
                return 1 + (idx - 1) % 10;
            }

            row = idx - 40;
            col = rand7();
            idx = (row - 1) * 7 + col;
            if (idx <= 60) {
                return 1 + (idx - 1) % 10;
            }

            row = idx - 60;
            col = rand7();
            idx = (row - 1) * 7 + col;
            if (idx <= 20) {
                return 1 + (idx - 1) % 10;
            }
        }

    }
}




