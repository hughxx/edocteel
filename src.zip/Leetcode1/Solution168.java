package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/18
 **/
public class Solution168 {
    public String convertToTitle(int columnNumber) {
        StringBuilder sb = new StringBuilder();
        while (columnNumber > 0) {
            sb.append(getChar((columnNumber - 1) % 26));
            columnNumber = (columnNumber - 1) / 26;
        }
        return sb.reverse().toString();
    }

    private char getChar(int i) {
        return (char) (i + 'A');
    }
}
