package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/17
 **/
public class SolutionJZ21 {
    public int[] exchange(int[] nums) {
        int i = 0, j = 0;
        while (j < nums.length) {
            if (nums[j] % 2 == 1) {
                int temp = nums[i];
                nums[j] = nums[i];
                nums[i] = temp;
                i++;
            }
            j++;
        }
        return nums;
    }
}
