package Leetcode1;

import java.util.LinkedList;

/**
 * @author : hu
 * @since : 2023/3/5
 **/
public class Solution234 {
    public boolean isPalindrome(ListNode head) {
        LinkedList<ListNode> list = new LinkedList<>();

        ListNode p = head;
        while (p != null) {
            list.add(p);
            p = p.next;
        }

        p = head;
        while (p != null) {
            if (p.val != list.removeLast().val) return false;
            p = p.next;
        }

        return true;
    }
}
