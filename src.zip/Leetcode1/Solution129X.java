package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/9
 **/
public class Solution129X {
    int res;

    public int sumNumbers(TreeNode root) {
        traverse(root, 0);
        return res;
    }

    void traverse(TreeNode root, int sum) {
        if (root == null) return;

        sum += root.val;
        if (root.left == null && root.right == null) {
            res += sum;
        } else {
            traverse(root.left, sum);
            traverse(root.right, sum);
        }
    }
}
