package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/3
 **/
public class Solution153 {
    public int findMin(int[] nums) {
        int n = nums.length;
        int left = 0, right = n - 1;
        int min = Integer.MAX_VALUE;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            min = Math.min(mid, min);
            if (left == right) break;
            if (nums[mid + 1] <= nums[right]) {
                min = Math.min(min, nums[mid + 1]);
                right = mid - 1;
            } else {
                min = Math.min(min, nums[left]);
                left = mid + 1;
            }
        }
        return min;
    }
}
