package Leetcode1;

/**
 * @author : hu
 * @since : 2023/4/11
 **/
public class SolutionMS1003 {
    public int search(int[] arr, int target) {
        if (arr[0] == target) {
            return 0;
        }
        int left = 0;
        int right = arr.length - 1;
        while (left <= right) {
            int mid = (left + right) >>> 1;
            if (arr[mid] == target) {
                while (mid > 1 && arr[mid - 1] == arr[mid]) {
                    mid--;
                }
                return mid;
            } else if (arr[mid] > arr[left]) {
                if (arr[left] <= target && target < arr[mid]) {
                    right = mid - 1;
                } else {
                    left = mid + 1;
                }
            } else if (arr[mid] < arr[left]) {
                if (arr[mid] < target && target <= arr[right]) {
                    left = mid + 1;
                } else {
                    right = mid - 1;
                }
            } else {
                left++;
            }
        }
        return -1;
    }


    public static void main(String[] args) {
        int n = new SolutionMS1003().search(new int[]{2, 2, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2}, 2);
        System.out.println(n);
    }
}
