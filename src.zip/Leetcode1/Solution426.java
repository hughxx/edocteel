package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/30
 **/
public class Solution426 {
    TreeNode head;
    TreeNode p;

    public TreeNode treeToDoublyList(TreeNode root) {
        // Write your code here.
        if (root == null) return null;
        traverse(root);
        p.right = head;
        head.left = p;
        return head;
    }

    private void traverse(TreeNode root) {
        System.out.println(root.val);
        if (root.left == null && root.right == null) {
            if (head == null) {
                head = root;
                p = head;
            } else {
                p.right = root;
                root.left = p;
                p = p.right;
            }
            return;
        }

        if (root.left != null) traverse(root.left);
        if (head == null) {
            head = root;
            p = head;

        } else {
            p.right = root;
            root.left = p;
            p = p.right;
        }
        if (root.right != null) traverse(root.right);
    }
}
