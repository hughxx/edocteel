package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/4
 **/
public class Solution2 {
    public ListNode addTwoNumbers(ListNode l1, ListNode l2) {
        ListNode dummy = new ListNode(-1);
        ListNode p1 = l1, p2 = l2, p3 = dummy;

        int add = 0;
        while (p1 != null || p2 != null || add != 0) {
            int x = p1 == null ? 0 : p1.val;
            int y = p2 == null ? 0 : p2.val;
            int sum = x + y + add;
            p3.next = new ListNode(sum % 10);
            add = sum / 10;
            if (p1 != null) p1 = p1.next;
            if (p2 != null) p2 = p2.next;
            p3 = p3.next;
        }

        return dummy.next;
    }
}
