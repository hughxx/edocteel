package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/6
 **/
public class Solution48 {
    public void rotate(int[][] matrix) {
        int m = matrix.length, n = matrix[0].length;
        for (int i = 1; i < m; i++) {
            for (int j = 0; j < i; j++) {
                mirror(matrix, i, j);
            }
        }
        for (int[] ints : matrix) {
            reverse(ints);
        }
    }

    private void mirror(int[][] matrix, int i, int j) {
        int tmp = matrix[i][j];
        matrix[i][j] = matrix[j][i];
        matrix[j][i] = tmp;
    }

    private void reverse(int[] nums) {
        int i = 0, j = nums.length - 1;
        while (i <= j) {
            swap(nums, i, j);
            i++;
            j--;
        }
    }

    private void swap(int[] nums, int i, int j) {
        int tmp = nums[i];
        nums[i] = nums[j];
        nums[j] = tmp;
    }
}
