package Leetcode1;

import java.util.Stack;

/**
 * @author : hu
 * @since : 2023/3/4
 **/
public class Solution155 {
    class MinStack {

        Stack<Integer> stack = new Stack();
        Stack<Integer> history = new Stack();

        public MinStack() {

        }

        public void push(int val) {
            //maintain min
            stack.push(val);
            int min = val;
            if (!history.isEmpty()) {
                min = history.peek();
            }
            if (val < min) {
                history.push(val);
            } else {
                history.push(min);
            }
        }

        public void pop() {
            //maintain min
            stack.pop();
            history.pop();
        }

        public int top() {
            return stack.peek();
        }

        public int getMin() {
            return history.peek();
        }
    }
}
