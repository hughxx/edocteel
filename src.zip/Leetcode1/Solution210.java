package Leetcode1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * @author : hu
 * @since : 2023/3/10
 **/
public class Solution210 {
    public int[] findOrder(int numCourses, int[][] prerequisites) {
        int[] indegree = new int[numCourses];
        List<Integer>[] graph = new List[numCourses];
        for (int i = 0; i < numCourses; i++) {
            graph[i] = new ArrayList<>();
        }
        for (int[] pre : prerequisites) {
            int u = pre[0];
            int v = pre[1];
            graph[v].add(u);
            indegree[u]++;
        }

        Queue<Integer> q = new LinkedList<>();
        int count = 0;
        int[] res = new int[numCourses];
        for (int i = 0; i < numCourses; i++) {
            if (indegree[i] == 0) {
                q.offer(i);
                res[count] = i;
                count++;
            }
        }
        while (!q.isEmpty()) {
            int cur = q.poll();
            for (int neighbor : graph[cur]) {
                indegree[neighbor]--;
                if (indegree[neighbor] == 0) {
                    q.offer(neighbor);
                    res[count] = neighbor;
                    count++;
                }
            }
        }
        return count == numCourses ? res : new int[]{};
    }
}
