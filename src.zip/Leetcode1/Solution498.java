package Leetcode1;

import java.util.LinkedList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/15
 **/
public class Solution498 {
    public int[] findDiagonalOrder(int[][] mat) {
        int m = mat.length, n = mat[0].length;
        List<Integer> list = new LinkedList<>();
        int i = 0, j = 0, sign = 1;
        while (list.size() < m * n) {
            list.add(mat[i][j]);
            i = i - sign;
            j = j + sign;

            if (j >= n) {
                i += 2;
                j--;
                sign *= -1;
            } else if (i < 0) {
                i++;
                sign *= -1;
            } else if (i >= m) {
                j += 2;
                i--;
                sign *= -1;
            } else if (j < 0) {
                j++;
                sign *= -1;
            }
        }

        int[] res = new int[m * n];
        for (int k = 0; k < list.size(); k++) {
            res[k] = list.get(k);
        }
        return res;
    }

    public static void main(String[] args) {
        new Solution498().findDiagonalOrder(new int[][]{{6,9,7}});
    }
}
