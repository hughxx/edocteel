package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/14
 **/
public class Solution209 {
    public int minSubArrayLen(int target, int[] nums) {
        int left = 0, right = 0;
        int sum = 0, res = Integer.MAX_VALUE;
        while (right < nums.length) {
            sum += nums[right];
            right++;

            while (sum >= target) {
                res = Math.min(right - left, res);
                sum -= nums[left];
                left++;
            }
        }
        return res == Integer.MAX_VALUE ? 0 : res;
    }


}
