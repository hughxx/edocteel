package Leetcode1;

import java.util.HashMap;

/**
 * @author : hu
 * @since : 2023/3/5
 **/
public class Solution169 {
    public int majorityElement(int[] nums) {
        HashMap<Integer, Integer> count = new HashMap<>();
        for (int i = 0; i < nums.length; i++) {
            count.put(nums[i], count.getOrDefault(nums[i], 0) + 1);
        }
        int res = 0, max = 0;
        for (int i = 0; i < nums.length; i++) {
            if (count.get(nums[i]) > max) {
                res = nums[i];
                max = count.get(nums[i]);
            }
        }
        return res;
    }
}
