package Leetcode1;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/4
 **/
public class Solution78 {
    private List<List<Integer>> res = new ArrayList<>();

    public List<List<Integer>> subsets(int[] nums) {
        backtrack(nums, 0, new ArrayList<>());
        return res;
    }

    private void backtrack(int[] nums, int start, List<Integer> track) {
        res.add(new ArrayList<>(track));

        for (int i = start; i < nums.length; i++) {
            track.add(nums[i]);
            backtrack(nums, i + 1, track);//start + 1 -> i + 1
            track.remove(track.size() - 1);
        }
    }
}
