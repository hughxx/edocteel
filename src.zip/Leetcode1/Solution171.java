package Leetcode1;

/**
 * @author : hu
 * @since : 2023/4/2
 **/
public class Solution171 {
    public int titleToNumber(String columnTitle) {
        int res = 0;
        for (int i = 0; i < columnTitle.length(); i++) {
            int c = columnTitle.charAt(i) - 'A' + 1;
            res = res * 26 + c;
        }
        return res;
    }
}
