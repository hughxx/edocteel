package Leetcode1;

import java.util.LinkedList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/16
 **/
public class Solution145 {
    List<Integer> res = new LinkedList<>();

    public List<Integer> postorderTraversal(TreeNode root) {
        traverse(root);
        return res;
    }

    private void traverse(TreeNode root) {
        if (root == null) return;

        traverse(root.left);
        traverse(root.right);
        res.add(root.val);
    }
}
