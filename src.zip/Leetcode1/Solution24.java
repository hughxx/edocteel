package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/3
 **/
public class Solution24 {
    public ListNode swapPairs(ListNode head) {
        if (head == null) return null;
        if (head.next == null) return head;
        ListNode newHead = head.next;
        ListNode tmp = head.next.next;
        head.next.next = head;
        head.next = swapPairs(tmp);
        return newHead;
    }
}
