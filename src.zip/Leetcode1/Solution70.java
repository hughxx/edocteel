package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/2
 **/
public class Solution70 {
    public int climbStairs(int n) {
        int dp_1 = 0, dp_2 = 1;
        for (int i = 1; i <= n; i++) {
            int tmp = dp_1 + dp_2;
            dp_1 = dp_2;
            dp_2 = tmp;
        }
        return dp_2;
    }
}
