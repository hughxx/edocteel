package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/16
 **/
public class Solution123 {
//    public int maxProfit(int[] prices) {
//        int n = prices.length;
//        int[][][] dp = new int[n][2][3];
//
//        for (int i = 0; i < n; i++) {
//            dp[i][1][0] = Integer.MIN_VALUE;
//        }
//        dp[0][1][1] = -prices[0];
//        dp[0][1][2] = -prices[0];
//
//        for (int i = 1; i < n; i++) {
//            for (int k = 1; k < 3; k++) {
//                dp[i][0][k] = Math.max(dp[i - 1][0][k], dp[i-1][1][k] + prices[i]);
//                dp[i][1][k] = Math.max(dp[i-1][0][k-1] - prices[i], dp[i-1][1][k]);
//            }
//        }
//
//        return dp[n-1][0][2];
//    }

    int maxProfit_k_2(int[] prices) {
        // base case
        int dp_i10 = 0, dp_i11 = Integer.MIN_VALUE;
        int dp_i20 = 0, dp_i21 = Integer.MIN_VALUE;
        for (int price : prices) {
            dp_i20 = Math.max(dp_i20, dp_i21 + price);
            dp_i21 = Math.max(dp_i21, dp_i10 - price);
            dp_i10 = Math.max(dp_i10, dp_i11 + price);
            dp_i11 = Math.max(dp_i11, -price);
        }
        return dp_i20;
    }
}
