package Leetcode1;

import java.util.LinkedHashMap;

/**
 * @author : hu
 * @since : 2023/3/13
 **/
public class Solution146 {
    class LRUCache {

        LinkedHashMap<Integer, Integer> linkedHashMap = new LinkedHashMap<>();
        int capacity;

        public LRUCache(int capacity) {
            this.capacity = capacity;
        }

        public int get(int key) {
            if (!linkedHashMap.containsKey(key)) return -1;
            makeRecently(key);
            return linkedHashMap.get(key);
        }

        public void put(int key, int value) {
            if (linkedHashMap.containsKey(key)) {
                linkedHashMap.put(key, value);
                makeRecently(key);
                return;
            }
            if (linkedHashMap.size() == capacity) {
                int oldKey = linkedHashMap.keySet().iterator().next();
                linkedHashMap.remove(oldKey);
            }
            linkedHashMap.put(key, value);
        }

        private void makeRecently(int key) {
            int val = linkedHashMap.get(key);
            linkedHashMap.remove(key);
            linkedHashMap.put(key, val);
        }
    }
}
