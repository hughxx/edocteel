package Leetcode1;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/6
 **/
public class Solution39 {
    List<List<Integer>> res = new ArrayList<>();

    public List<List<Integer>> combinationSum(int[] candidates, int target) {
        backtrack(candidates, target, 0, 0, new ArrayList<>());
        return res;
    }

    private void backtrack(int[] nums, int target, int start, int sum, List<Integer> track) {
        if (sum == target) {
            res.add(new ArrayList<>(track));
        }
        if (sum > target) {
            return;
        }

        for (int i = start; i < nums.length; i++) {
            sum += nums[i];
            track.add(nums[i]);
            backtrack(nums, target, i, sum, track);
            sum -= nums[i];
            track.remove(track.size() - 1);
        }
    }
}
