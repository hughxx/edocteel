package Leetcode1;

import java.util.Collections;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/27
 **/
class Interval {
    int start, end;

    Interval(int start, int end) {
        this.start = start;
        this.end = end;
    }
}

public class SolutionLint920 {
    public boolean canAttendMeetings(List<Interval> intervals) {
        if (intervals.size() == 0) return false;
        // Write your code here
        Collections.sort(intervals, (a, b) -> {
            return a.end - b.end;
        });
        int lastEnd = 0, result = 1;
        for (int i = 1; i < intervals.size(); i++) {
            if (intervals.get(i).start >= intervals.get(lastEnd).end) {
                result++;
                lastEnd = i;
            }
        }
        return result == intervals.size();
    }
}
