package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/5
 **/
public class Solution543 {
    int res = 0;

    public int diameterOfBinaryTree(TreeNode root) {
        depth(root);
        return res;
    }

    private int depth(TreeNode root) {
        if (root == null) return 0;
        int left = depth(root.left);
        int right = depth(root.right);
        res = Math.max(res, left + right);
        return Math.max(left, right) + 1;
    }
}
