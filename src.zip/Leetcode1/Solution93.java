package Leetcode1;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/4
 **/
public class Solution93 {
    List<String> res = new ArrayList<>();

    public List<String> restoreIpAddresses(String s) {
        backtrack(s, 0, 0, new StringBuilder());
        return res;
    }

    private void backtrack(String s, int start, int n, StringBuilder sb) {
        if (n < 4 && start >= s.length()) return;
        if (n == 4 && start != s.length()) return;
        if (n == 4) {
            res.add(sb.substring(0, sb.length() - 1));//..
        }

        for (int i = 0; i < 3; i++) {
            int num = isValid(s, start, start + i);
            if (num != -1) {
                int pre = sb.length();
                sb.append(num);
                sb.append('.');
                backtrack(s, start + i + 1, n + 1, sb);
                int cur = sb.length();
                for (int j = 0; j < cur - pre; j++) {
                    sb.deleteCharAt(sb.length() - 1);
                }
            }
        }
    }

    private int isValid(String s, int start, int end) {
        if (end >= s.length()) return -1;//..
        int num = 0;
        for (int i = start; i <= end; i++) {
            num = 10 * num + (s.charAt(i) - '0');
        }
        if (num > 255) return -1;
        if (num == 0 && end - start != 0) return -1;
        if (num > 0 && s.charAt(start) == '0') return -1;
        return num;
    }

    public static void main(String[] args) {
        new Solution93().restoreIpAddresses("12");
    }
}
