package Leetcode1;

import java.util.HashMap;

/**
 * @author : hu
 * @since : 2023/3/2
 **/
public class Solution76 {
    public String minWindow(String s, String t) {
        HashMap<Character, Integer> need = new HashMap<>();
        HashMap<Character, Integer> window = new HashMap<>();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            need.put(c, need.getOrDefault(c, 0) + 1);
        }

        int left = 0, right = 0;
        int count = 0;
        int start = 0, length = Integer.MAX_VALUE;
        while (right < s.length()) {
            char c = s.charAt(right);
            if (need.containsKey(c)) {
                window.put(c, window.getOrDefault(c, 0) + 1);
                if (window.get(c).equals(need.get(c))) count++;
            }
            right++;

            while (count == need.size()) {
                if (right - left < length) {
                    start = left;
                    length = right - left;
                }

                char d = s.charAt(left);
                if (need.containsKey(d)) {
                    window.put(d, window.get(d) - 1);
                    if (window.get(d) < need.get(d)) count--;
                }
                left++;
            }
        }
        return length == Integer.MAX_VALUE ? "" :s.substring(start, start + length);
    }
}
