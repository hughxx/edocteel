package Leetcode1;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Stack;

/**
 * @author : hu
 * @since : 2023/4/8
 **/
public class Solution2454 {
    public int[] secondGreaterElement(int[] nums) {
        Stack<Integer> stack1 = new Stack<>();
        Stack<Integer> stack2 = new Stack<>();
        int[] res = new int[nums.length];
        Arrays.fill(res, -1);
        for (int i = 0; i < nums.length; i++) {
            while (!stack2.isEmpty() && nums[stack2.peek()] < nums[i]) {
                res[stack2.pop()] = nums[i];
            }
            LinkedList<Integer> list = new LinkedList<>();
            while (!stack1.isEmpty() && nums[stack1.peek()] < nums[i]) {
                list.add(stack1.pop());
            }
            while (!list.isEmpty()) {
                stack2.add(list.removeLast());
            }
            stack1.add(i);
        }
        return res;
    }
}
