package Leetcode1;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/10
 **/
public class Solution207 {
    List<Integer>[] graph;
    boolean[] visited;
    boolean[] onPath;
    boolean hasCycle;

    public boolean canFinish(int numCourses, int[][] prerequisites) {
        graph = buildGraph(numCourses, prerequisites);
        visited = new boolean[numCourses];
        onPath = new boolean[numCourses];
        for (int i = 0; i < numCourses; i++) {
            dfs(i);
        }
        return !hasCycle;
    }

    private void dfs(int i) {
        if (hasCycle) return;
        if (onPath[i]) {
            hasCycle = true;
            return;
        }
        if (visited[i]) return;
        visited[i] = true;
        onPath[i] = true;
        for (int neighbor : graph[i]) {
            dfs(neighbor);
        }
        onPath[i] = false;
    }

    private List<Integer>[] buildGraph(int numCourses, int[][] prerequisites) {
        List<Integer>[] graph = new List[numCourses];
        for (int i = 0; i < numCourses; i++) {
            graph[i] = new ArrayList<>();
        }
        for (int[] pre : prerequisites) {
            int u = pre[0];
            int v = pre[1];
            graph[v].add(u);
        }
        return graph;
    }
}
