package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/15
 **/
public class Solution402 {

    //backtrack->dp
    //贪心NB

    public String removeKdigits(String num, int k) {
        return "";
    }



}
