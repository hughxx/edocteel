package Leetcode1;

import java.util.Arrays;

/**
 * @author : hu
 * @since : 2023/3/2
 **/
public class Solution152 {
    public int maxProduct(int[] nums) {
        int n = nums.length;
        if (n == 0) return 0;

        int[] min = Arrays.copyOf(nums, n);
        int[] max = Arrays.copyOf(nums, n);

        for (int i = 1; i < n; i++) {
            min[i] = Math.min(nums[i], Math.min(min[i-1] * nums[i], max[i-1] * nums[i]));
            max[i] = Math.max(nums[i], Math.max(min[i-1] * nums[i], max[i-1] * nums[i]));
        }

        int res = Integer.MIN_VALUE;
        for (int i = 0; i < n; i++) {
            res = Math.max(res, max[i]);
        }
        return res;
    }
}
