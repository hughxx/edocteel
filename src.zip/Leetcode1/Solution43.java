package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/2
 **/
public class Solution43 {
    public String multiply(String num1, String num2) {
        int m = num1.length(), n = num2.length();

        int[] res = new int[m + n]; // m + n
        for (int j = n - 1; j >= 0; j--) { //循环顺序无所谓 >=0
            for (int i = m - 1; i >= 0; i--) {
                int product = (num1.charAt(i) - '0') * (num2.charAt(j) - '0');
                int sum = product + res[i + j + 1]; //需要一个temp变量
                res[i + j + 1] = sum % 10;
                res[i + j] += sum / 10;
            }
        }

        int i = 0;
        while (i < res.length && res[i] == 0) {
            i++;
        }

        StringBuilder sb = new StringBuilder();
        for (;i < res.length; i++) {
            sb.append(res[i]);
        }
        return sb.length() == 0 ? "" :sb.toString();
    }
}
