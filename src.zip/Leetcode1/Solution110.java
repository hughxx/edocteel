package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/5
 **/
public class Solution110 {
    boolean res = true;

    public boolean isBalanced(TreeNode root) {
        depth(root);
        return res;
    }

    private int depth(TreeNode root) {
        if (!res) return -1;
        if (root == null) return 0;
        int left = depth(root.left);
        int right = depth(root.right);
        if (Math.abs(left - right) > 1) res = false;
        return Math.max(left, right) + 1;
    }
}
