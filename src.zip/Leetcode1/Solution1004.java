package Leetcode1;

/**
 * @author : hu
 * @since : 2023/4/8
 **/
public class Solution1004 {

}
