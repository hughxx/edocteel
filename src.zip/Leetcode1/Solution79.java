package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/15
 **/
public class Solution79 {
    StringBuilder sb = new StringBuilder();
    boolean[][] visited;
    boolean exist;

    public boolean exist(char[][] board, String word) {
        int m = board.length, n = board[0].length;
        visited = new boolean[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                backtrack(board, word, i, j);
            }
        }
        return exist;
    }

    public void backtrack(char[][] board, String word, int i, int j) {
        if (exist) return;

        if (sb.length() == word.length()) {
            exist = sb.toString().equals(word);
            return;
        }

        int m = board.length, n = board[0].length;
        if (i < 0 || i >= m || j < 0 || j >= n) return;

        if (visited[i][j]) return;
        visited[i][j] = true;
        sb.append(board[i][j]);
        backtrack(board, word, i - 1, j);
        backtrack(board, word, i + 1, j);
        backtrack(board, word, i, j - 1);
        backtrack(board, word, i, j + 1);
        sb.deleteCharAt(sb.length() - 1);
        visited[i][j] = false;
    }
}
