package Leetcode1;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/5
 **/
public class Solution113 {
    List<List<Integer>> res = new ArrayList<>();

    public List<List<Integer>> pathSum(TreeNode root, int targetSum) {
        traverse(root, targetSum, new ArrayList<>());
        return res;
    }

    private void traverse(TreeNode root, int targetSum, List<Integer> track) {
        if (root == null) return;

        track.add(root.val);
        if (root.left == null && root.right == null && targetSum == root.val) {
            res.add(new ArrayList<>(track));
        }
        traverse(root.left, targetSum - root.val, track);
        traverse(root.right, targetSum - root.val, track);
        track.remove(track.size() - 1);
    }
}
