package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/5
 **/
public class Solution129 {
    int res;

    public int sumNumbers(TreeNode root) {
        sumNumbers(root, 0);
        return res;
    }

    private void sumNumbers(TreeNode root, int sum) {
        if (root == null) return;
        if (root.left == null && root.right == null) {
            res += 10 * sum + root.val;
            return;
        }
        sumNumbers(root.left, 10 * sum + root.val);
        sumNumbers(root.right, 10 * sum + root.val);
    }
}
