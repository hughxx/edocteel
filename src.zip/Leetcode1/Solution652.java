package Leetcode1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/27
 **/
public class Solution652 {
    List<TreeNode> res = new ArrayList<>();
    HashMap<String, Integer> memo = new HashMap<>();

    public List<TreeNode> findDuplicateSubtrees(TreeNode root) {
        traverse(root);
        return res;
    }

    private String traverse(TreeNode root) {
        if (root == null) return "#";
        String left = traverse(root.left);
        String right = traverse(root.right);
        String myself = left + ',' + right + ',' + root.val;
        int freq = memo.getOrDefault(myself, 0);
        if (freq == 1) {
            res.add(root);
        }
        memo.put(myself, freq + 1);
        return myself;
    }
}
