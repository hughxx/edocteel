package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/17
 **/
public class SolutionJZ04 {
    public boolean findNumberIn2DArray(int[][] matrix, int target) {
        int m = matrix.length, n = matrix[0].length;
        int i = 0, j = n - 1;
        while (i < m && j >= 0) {
            if (matrix[i][j] == target) return true;
            if (matrix[i][j] > target) {
                i++;
            } else {
                j--;
            }
        }
        return false;
    }
}
