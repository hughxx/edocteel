package Leetcode1;

import java.util.Arrays;

/**
 * @author : hu
 * @since : 2023/3/21
 **/
public class SolutionMS45 {
    public String minNumber(int[] nums) {
        Integer[] arr = new Integer[nums.length];
        for (int i = 0; i < nums.length; i++) {
            arr[i] = nums[i];
        }
        Arrays.sort(arr, (x, y) -> {
            long sx = 10;
            while (sx <= x) {
                sx *= 10;
            }

            long sy = 10;
            while (sy <= y) {
                sy *= 10;
            }
            return (int) (x * sy + y - (y * sx + x));
        });
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            sb.append(arr[i]);
        }
        return sb.toString();
    }
}
