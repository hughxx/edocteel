package Leetcode1;

/**
 * @author : hu
 * @since : 2023/4/9
 **/
public class Solution525 {

}
