package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/18
 **/
public class Solution678 {
    int[][][] memo;

    public boolean checkValidString(String s) {
        int n = s.length();
        memo = new int[n][n][n];
        return check(s, 0, 0, 0);
    }

    private boolean check(String s, int i, int left, int right) {
        if (i == s.length()) {
            return left == right;
        }

        if (memo[i][left][right] != 0) {
            return memo[i][left][right] == 1;
        }

        char c = s.charAt(i);
        if (c == '(') {
            boolean res = check(s, i + 1, left + 1, right);
            memo[i][left][right] = res ? 1 : -1;
            return res;
        } else if (c == ')') {
            if (left <= right) {
                memo[i][left][right] = -1;
                return false;
            }
            boolean res = check(s, i + 1, left, right + 1);
            memo[i][left][right] = res ? 1 : -1;
            return res;
        } else {
            if (left <= right) {
                boolean res = check(s, i + 1, left + 1, right) || check(s, i + 1, left, right);
                memo[i][left][right] = res ? 1 : -1;
                return res;
            }
            boolean res = check(s, i + 1, left, right + 1) || check(s, i + 1, left + 1, right) ||check(s, i + 1, left, right);
            memo[i][left][right] = res ? 1 : -1;
            return res;
        }
    }
}
