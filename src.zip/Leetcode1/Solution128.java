package Leetcode1;

import java.util.HashSet;
import java.util.Set;

/**
 * @author : hu
 * @since : 2023/3/3
 **/
public class Solution128 {
    public int longestConsecutive(int[] nums) {
        Set<Integer> memo = new HashSet<>();
        for (int i = 0; i < nums.length; i++) {
            memo.add(nums[i]);
        }
        int res = 0;
        for (int i = 0; i < nums.length; i++) {
            if (!memo.contains(nums[i] - 1)) {
                int len = 0;
                int num = nums[i];
                while (memo.contains(num)) {
                    len++;
                    num++;
                }
                res = Math.max(res, len);
            }
        }
        return res;
    }
}
