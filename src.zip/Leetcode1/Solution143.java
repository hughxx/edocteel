package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/1
 **/
public class Solution143 {
    public void reorderList(ListNode head) {
        if (head == null) return;
        ListNode mid = middleList(head);
        ListNode tmp = mid.next;
        mid.next = null;
        ListNode p2 = reverseList(tmp);
        ListNode p1 = head;
        mergeList(p1, p2);
    }

    private ListNode middleList(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast.next != null && fast.next.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        return slow;
    }

    private ListNode reverseList(ListNode head) {
        ListNode p = head;
        ListNode pre = null;
        while (p != null){
            ListNode next = p.next;
            p.next = pre;
            pre = p;
            p = next;
        }
        return pre;
    }

    private void mergeList(ListNode p1, ListNode p2) {
        while (p2 != null) {
            ListNode tmp1 = p1.next;
            p1.next = p2;
            ListNode tmp2 = p2.next;
            p2.next = tmp1;
            p1 = tmp1;
            p2 = tmp2;
        }
    }
}
