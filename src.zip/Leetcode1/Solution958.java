package Leetcode1;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @author : hu
 * @since : 2023/3/15
 **/
public class Solution958 {
    public boolean isCompleteTree(TreeNode root) {
        if (root == null) return true;
        Queue<TreeNode> q = new LinkedList<>();
        q.offer(root);

        int need = 1;
        while (!q.isEmpty()) {
            int sz = q.size();
            if (sz != need) break;
            for (int i = 0; i < sz; i++) {
                TreeNode cur = q.poll();
                if (cur.left != null) q.offer(cur.left);
                if (cur.right != null) q.offer(cur.right);
            }
            need *= 2;
        }
        while (!q.isEmpty()) {
            for (TreeNode cur : q) {
                if (cur.left != null) return false;
                if (cur.right != null) return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);
        root.right.left = new TreeNode(6);
        new Solution958().isCompleteTree(root);
    }
}
