package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/21
 **/
public class Solution670 {
    public int maximumSwap(int num) {
        char[] c = String.valueOf(num).toCharArray();
        int i = 0, j = 1, max = -1;
        while (j < c.length) {
            if (c[j] > c[i]) {
                max = j;
                for (int k = j + 1; k < c.length; k++) {
                    if (c[k] > c[max]) {
                        max = k;
                    }
                }
                break;
            }
            i++;
            j++;
        }
        if (max == -1) return num;
        char temp = c[i];
        c[i] = c[max];
        c[max] = temp;
        return Integer.parseInt(new String(c));
    }
}
