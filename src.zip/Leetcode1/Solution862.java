package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/28
 **/
public class Solution862 {
    public int shortestSubarray(int[] nums, int k) {
        int n = nums.length;
        int left = 0, right = 0, window = 0;
        int res = Integer.MAX_VALUE;
        while (right < n) {
            int r = nums[right];
            window += r;
            right++;

            while (window >= k) {
                res = Math.min(res, right - left);
                window -= nums[left];
                left++;
            }
        }
        return res;
    }
}
