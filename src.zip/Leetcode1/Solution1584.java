package Leetcode1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/10
 **/
public class Solution1584 {
    public int minCostConnectPoints(int[][] points) {
        int n = points.length;
        List<int[]> edges = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                int[] x = points[i];
                int[] y = points[j];
                int d = Math.abs(x[0] - y[0]) + Math.abs(x[1] - y[1]);
                edges.add(new int[]{i, j, d});
            }
        }
        Collections.sort(edges, (a, b) -> a[2] - b[2]);

        UF uf = new UF(n);
        int res = 0;
        for (int[] edge : edges) {
            if (uf.isConnected(edge[0], edge[1])) continue;
            uf.connect(edge[0], edge[1]);
            res += edge[2];
        }
        return res;
    }

    class UF {
        int count;
        int[] parent;

        UF(int n) {
            count = n;
            parent = new int[n];
            for (int i = 0; i < n; i++) {
                parent[i] = i;
            }
        }

        boolean isConnected(int p, int q) {
            int rootP = find(p);
            int rootQ = find(q);
            return rootP == rootQ;
        }

        void connect(int p, int q) {
            int rootP = find(p);
            int rootQ = find(q);
            if (rootP == rootQ) return;
            parent[rootP] = rootQ;
            count--;
        }

        int count() {
            return count;
        }

        int find(int p) {
            if (parent[p] != p) {
                parent[p] = find(parent[p]);
            }
            return parent[p];
        }
    }
}
