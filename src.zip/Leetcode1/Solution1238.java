package Leetcode1;

/**
 * @author : hu
 * @since : 2023/2/23
 **/
public class Solution1238 {
//    public List<Integer> circularPermutation(int n, int start) {
//
//    }
}
