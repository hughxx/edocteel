package Leetcode1;

import java.util.Random;

/**
 * @author : hu
 * @since : 2023/3/2
 **/
public class Solution215 {
    public int findKthLargest(int[] nums, int k) {
        shuffle(nums);
        int left = 0, right = nums.length - 1;
        k = nums.length - k;
        while (left <= right) {
            int p = partition(nums, left, right);
            if (p < k) {
                left = p + 1;
            } else if (p > k) {
                right = p - 1;
            } else {
                return nums[p];
            }
        }
        return -1;
    }

    private int partition(int[] nums, int lo, int hi) {
        int pivot = nums[lo];
        int left = lo, right = hi;
        while (left <= right) {
            if (nums[left] > pivot) {
                swap(nums, left, right);
                right--;
                left--;
            }
            left++;
        }
        swap(nums, lo, right);
        return right;
    }

    private void shuffle(int[] nums) {
        int n = nums.length;
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            int r = random.nextInt(n - i) + i;
            swap(nums, r, i);
        }
    }

    private void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
}
