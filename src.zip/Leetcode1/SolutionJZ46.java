package Leetcode1;

/**
 * @author : hu
 * @since : 2023/4/2
 **/
public class SolutionJZ46 {
    public int translateNum(int num) {
        String s = String.valueOf(num);
        int n = s.length();
        int[] dp = new int[n];

        for (int i = 0; i < n; i++) {
            if (i == 0) {
                dp[i] = s.charAt(i) - '0' == 0 ? 0 : 1;
                continue;
            }
            if (s.charAt(i) != '0') {
                dp[i] += dp[i - 1];
            }
            if ((s.charAt(i - 1) - '0') * 10 + (s.charAt(i) - '0') <= 26 && s.charAt(i - 1) != '0') {
                dp[i] = i == 1 ? dp[i] + 1 : dp[i] + dp[i - 2];
            }
        }
        return dp[n - 1];
    }
}
