package Leetcode1;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;

/**
 * @author : hu
 * @since : 2023/3/19
 **/
public class Solution71 {
    public String simplifyPath(String path) {
        LinkedList<String> stack = new LinkedList<>();
        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (c == '/') continue;
            if (c == '.' && i + 1 < path.length() && path.charAt(i + 1) == '/') {
                i++;
            } else if (c == '.' && i + 2 < path.length() && path.charAt(i + 2) == '/'){
                i+=2;
                if (!stack.isEmpty()) stack.removeLast();
            } else if (i == path.length() - 1 && c == '.') {
                i+=1;
            } else if (i == path.length() - 2 && c == '.' && path.charAt(i + 1) == '.') {
                i+=2;
                if (!stack.isEmpty()) stack.removeLast();
            } else {
                StringBuilder sb = new StringBuilder();
                while (i < path.length() && path.charAt(i) != '/') {
                    sb.append(path.charAt(i));
                    i++;
                }
                stack.addLast(sb.toString());
            }
        }
        if(stack.size() == 0) return "/";
        StringBuilder res = new StringBuilder();
        while (!stack.isEmpty()) {
            res.append("/");
            res.append(stack.removeFirst());
        }
        return res.toString();
    }

    public String simplifyPath2(String path) {
        String[] names = path.split("/");
        Deque<String> stack = new ArrayDeque<String>();
        for (String name : names) {
            if ("..".equals(name)) {
                if (!stack.isEmpty()) {
                    stack.pollLast();
                }
            } else if (!name.equals(".")) {
                stack.offerLast(name);
            }
        }
        StringBuffer ans = new StringBuffer();
        if (stack.isEmpty()) {
            ans.append('/');
        } else {
            while (!stack.isEmpty()) {
                ans.append('/');
                ans.append(stack.pollFirst());
            }
        }
        return ans.toString();
    }

    public static void main(String[] args) {
        new Solution71().simplifyPath2("/home/");
    }

}
