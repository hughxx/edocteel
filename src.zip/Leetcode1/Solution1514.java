package Leetcode1;

import javafx.util.Pair;

import java.util.*;

/**
 * @author : hu
 * @since : 2023/3/10
 **/
public class Solution1514 {
    public double maxProbability(int n, int[][] edges, double[] succProb, int start, int end) {
        List<Pair<Integer, Double>>[] graph = buildGraph(n, edges, succProb);
        Queue<Pair<Integer, Double>> q = new LinkedList<>();
        double[] distTo = new double[n];
        Arrays.fill(distTo, 0);
        q.offer(new Pair<>(start, 1.0));
        while (!q.isEmpty()) {
            Pair<Integer, Double> cur = q.poll();
            int i = cur.getKey();
            double d = cur.getValue();
            if (d < distTo[i]) continue;
            for (Pair<Integer, Double> neighbor : graph[i]) {
                double curDistTo = d * neighbor.getValue();
                if (curDistTo > distTo[neighbor.getKey()]) {
                    distTo[neighbor.getKey()] = curDistTo;
                    q.offer(new Pair<>(neighbor.getKey(), curDistTo));
                }
            }
        }
        return distTo[end];
    }

    private List<Pair<Integer, Double>>[] buildGraph(int n, int[][] edges, double[] succProb) {
        List<Pair<Integer, Double>>[] graph = new List[n];
        for (int i = 0; i < n; i++) {
            graph[i] = new ArrayList<>();
        }
        for (int i = 0; i < edges.length; i++) {
            int u = edges[i][0];
            int v = edges[i][1];
            graph[u].add(new Pair<>(v, succProb[i]));
            graph[v].add(new Pair<>(u, succProb[i]));
        }
        return graph;
    }
}
