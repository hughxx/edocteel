package Leetcode1;


/**
 * @author : hu
 * @since : 2023/4/4
 **/
public class Solution99 {

    public static void main(String[] args) {


    }


}
