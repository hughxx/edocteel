package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/4
 **/
public class Solution148 {
    public ListNode sortList(ListNode head) {
        return sort(head, null);
    }

    private ListNode sort(ListNode start, ListNode end) {
        //base case: [start, start.next) [start, null) [null, null)
        if (start == null) return start;
        if (start.next == end) {
            start.next = null;//...
            return start;
        }

        ListNode slow = start, fast = start;
        while (fast.next != end && fast.next.next != end) {
            slow = slow.next;
            fast = fast.next.next;
        }
        ListNode mid = slow.next; //...
        ListNode left = sort(start, mid);
        ListNode right = sort(mid, end);
        return merge(left, right);
    }

    private ListNode merge(ListNode head1, ListNode head2) {
        ListNode dummy = new ListNode(-1), p = dummy;
        ListNode p1 = head1, p2 = head2;
        while (p1 != null && p2 != null) {
            if (p1.val < p2.val) {
                p.next = p1;
                p1 = p1.next;
            } else {
                p.next = p2;
                p2 = p2.next;
            }
            p = p.next;
        }
        if (p1 == null) {
            p.next = p2;
        } else {
            p.next = p1;
        }
        return dummy.next;
    }
}
