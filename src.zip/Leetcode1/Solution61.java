package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/15
 **/
public class Solution61 {
    public ListNode rotateRight(ListNode head, int k) {
        if (head == null) return null;

        ListNode fast = head;
        for (int i = 0; i < k; i++) {
            fast = fast.next;
            if (fast == null) fast = head;
        }
        ListNode slow = head;
        while (fast.next != null) {
            fast = fast.next;
            slow = slow.next;
        }

        ListNode newHead = slow.next;
        if (newHead == null) newHead = head;
        fast.next = head;
        slow.next = null;
        return newHead;
    }
}
