package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/27
 **/
public class Solution2402 {
    public int mostBooked(int n, int[][] meetings) {

        return -1;
    }

    public static void main(String[] args) {

    }
}
