package Leetcode1;

import java.util.LinkedList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/3/15
 **/
public class SolutionJZ54 {
    List<Integer> midOrder = new LinkedList<>();

    public int kthLargest(TreeNode root, int k) {
        traverse(root);
        return midOrder.get(midOrder.size() - k);
    }

    public void traverse(TreeNode root) {
        if (root == null) return;

        traverse(root.left);
        midOrder.add(root.val);
        traverse(root.right);
    }

}
