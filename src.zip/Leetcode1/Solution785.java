package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/10
 **/
public class Solution785 {
    boolean[] visited;
    boolean[] color;
    boolean isBipartite;

    public boolean isBipartite(int[][] graph) {
        visited = new boolean[graph.length];
        color = new boolean[graph.length];
        for (int i = 0; i < graph.length; i++) {
            if (!visited[i]) {
                traverse(graph, i);
            }
        }
        return isBipartite;
    }

    private void traverse(int[][] graph, int i) {
        if (!isBipartite) return;
        for (int neighbor: graph[i]) {
            if (visited[neighbor] ) {
                if (color[i] == color[neighbor]) {
                    isBipartite = false;
                    return;
                }
            } else {
                visited[neighbor] = true;
                color[neighbor] = !color[i];
                traverse(graph, neighbor);
            }

        }
    }
}
