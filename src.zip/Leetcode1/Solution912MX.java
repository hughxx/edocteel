package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/9
 **/
public class Solution912MX {
    int[] temp;

    public int[] sortArray(int[] nums) {
        temp = new int[nums.length];
        sort(nums, 0, nums.length - 1);
        return nums;
    }

    private void sort(int[] nums, int i, int j) {
        if (i >= j) return;
        int mid = i + (j - i) / 2;
        sort(nums, i, mid);
        sort(nums, mid + 1, j);
        merge(nums, i, mid, j);
    }

    private void merge(int[] nums, int lo, int mid, int hi) {
        for (int k = lo; k <= hi; k++) {
            temp[k] = nums[k];
        }
        int i = lo, j = mid + 1;
        for (int k = lo; k <= hi; k++) {
            if (i > mid) {
                nums[k] = temp[j++];
            } else if (j > hi) {
                nums[k] = temp[i++];
            } else if (temp[i] < temp[j]) {
                nums[k] = temp[i++];
            } else {
                nums[k] = temp[j++];
            }
        }
    }
}
