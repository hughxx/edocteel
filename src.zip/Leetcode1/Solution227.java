package Leetcode1;

import java.util.Stack;

/**
 * @author : hu
 * @since : 2023/3/3
 **/
public class Solution227 {
    public int calculate(String s) {
        return calculate(s, 0);
    }

    private int calculate(String s, int start) {
        Stack<Integer> stack = new Stack<>();
        char sign = '+';
        int num = 0;
        for (int i = start; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(') num = calculate(s, i + 1);
            if (Character.isDigit(c)) {
                num = 10 * num + (c - '0');
            }
            if (!Character.isDigit(c) && c != ' ' || i == s.length() - 1) {
                switch (sign) {
                    case '+':
                        stack.push(num);
                        break;
                    case '-':
                        stack.push(-num);
                        break;
                    case '*':
                        stack.push(stack.pop()*num);
                        break;
                    case '/':
                        stack.push(stack.pop() / num);
                        break;
                }
                sign = c;
                num = 0;
            }
            if (c == ')') break;
        }

        int res = 0;
        for (int i = 0; i < stack.size(); i++) {
            res += stack.get(i);
        }
        return res;
    }
}
