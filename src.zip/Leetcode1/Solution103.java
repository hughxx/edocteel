package Leetcode1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @author : hu
 * @since : 2023/2/24
 **/
public class Solution103 {
    public List<List<Integer>> zigzagLevelOrder(TreeNode root) {
        List<List<Integer>> res = new ArrayList<>();
        if (root == null) return res;
        LinkedList<TreeNode> q = new LinkedList<>();
        q.offer(root);
        boolean r = false;
        while (!q.isEmpty()) {
            int sz = q.size();
            LinkedList<Integer> layer = new LinkedList<>();
            if (!r) {
                for (int i = 0; i < sz; i++) {
                    TreeNode cur = q.removeFirst();
                    layer.add(cur.val);
                    if (cur.left != null) q.add(cur.left);
                    if (cur.right != null) q.add(cur.right);
                }
            } else {
                for (int i = 0; i < sz; i++) {
                    TreeNode cur = q.removeLast();
                    layer.add(cur.val);
                    if (cur.right != null) q.addFirst(cur.right);
                    if (cur.left != null) q.addFirst(cur.left);
                }
            }
            r = !r;
            res.add(layer);
        }
        return res;
    }
}
