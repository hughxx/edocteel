package Leetcode1;

import java.util.Arrays;

/**
 * @author : hu
 * @since : 2023/3/25
 **/
public class Solution452 {
    public int findMinArrowShots(int[][] intervals) {
        Arrays.sort(intervals, (o1, o2) -> (o1[0] - o2[0]));

        int res = 0;
        int end = intervals[0][1];
        for(int i = 1; i < intervals.length; i++){
            if(end < intervals[i][0])
                end = intervals[i][1];
            else{
                end = Math.min(end, intervals[i][1]);
                res++;
            }
        }

        return intervals.length - res;
    }

    public static void main(String[] args) {
        new Solution452().findMinArrowShots(new int[][]{{-2147483646, -2147483645}, {2147483646, 2147483647}});
        //[[-2147483646,-2147483645],[2147483646,2147483647]]
    }
}
