package Leetcode1;

/**
 * @author : hu
 * @since : 2023/3/16
 **/
public class SolutionJZ10 {
    public int fib(int n) {
        int fib_0 = 1, fib_1 = 0;
        for(int i = 1; i <= n; i++) {
            int tmp = fib_0 + fib_1;
            fib_0 = fib_1;
            fib_1 = tmp;
        }
        return fib_1;
    }

    public static void main(String[] args) {
        System.out.println(-123%10);
    }
}
