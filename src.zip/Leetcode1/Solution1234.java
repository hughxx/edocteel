package Leetcode1;

/**
 * @author : hu
 * @since : 2023/4/9
 **/
public class Solution1234 {
    public int balancedString(String s) {
        int n = s.length();
        int[] count = new int[26];
        for (int i = 0; i < n; i++) {
            count[s.charAt(i) - 'A']++;
        }
        int m = n / 4;
        if (isValid(count, m)) return 0;

        int res = n;
//        int right = 0, left = 0;
//        while (right < n) {
//            char c = s.charAt(right);
//            count[c - 'A']--;
//            right++;
//
//            if (isValid(count, m)) {
//
//                res = Math.min(res, right - left);
//                char d = s.charAt(left);
//                count[d - 'A']++;
//                left++;
//            }
//        }
        for (int l = 0, r = 0; l < s.length(); l++) {
            while (r < s.length() && !isValid(count, m)) {
                count[(s.charAt(r)) - 'A']--;
                r++;
            }
            if (!isValid(count, m)) {
                break;
            }
            System.out.println(r-l+":"+r+","+l);
            res = Math.min(res, r - l);
            count[(s.charAt(l)) - 'A']++;
        }

        return res;
    }

    boolean isValid(int[] count, int m) {
        if (count['Q' - 'A'] > m || count['W' - 'A'] > m || count['E' - 'A'] > m || count['R' - 'A'] > m) return false;
        return true;
//        int c = count['Q' - 'A'];
//        if (count['W' - 'A'] != c) return false;
//        if (count['E' - 'A'] != c) return false;
//        if (count['R' - 'A'] != c) return false;
//        return true;
    }

    public static void main(String[] args) {
        new Solution1234().balancedString("QWEWQWEWQWER");
    }
}
