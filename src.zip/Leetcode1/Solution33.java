package Leetcode1;

/**
 * @author : hu
 * @since : 2023/2/24
 **/
public class Solution33 {
    public int search(int[] nums, int target) {
        int left = 0, right = nums.length;

        while (left < right) {
            int mid = left + (right - left) / 2;
            if (target == nums[mid]) {
                return mid;
            }
            if (nums[mid] < nums[right]) {
                if (target > nums[mid]) {
                    left = mid + 1;
                } else {
                    right = mid;
                }
            } else {
                if (target < nums[mid]) {
                    right = mid;
                } else {
                    left = mid + 1;
                }
            }
        }

        return -1;
    }
}
